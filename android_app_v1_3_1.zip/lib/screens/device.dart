import 'package:flutter/material.dart';
import '../api.dart';
import '../device_sync.dart';
import '../theme.dart';
import 'staff.dart' show push;

/* ===================================================== STAFF: company device */

class CompanyDeviceScreen extends StatefulWidget {
  const CompanyDeviceScreen({super.key});
  @override
  State<CompanyDeviceScreen> createState() => _CompanyDeviceScreenState();
}

class _CompanyDeviceScreenState extends State<CompanyDeviceScreen> {
  final key = GlobalKey<LoaderState>();
  bool syncing = false;
  String step = '';

  Future<void> syncNow({String source = 'manual'}) async {
    setState(() {
      syncing = true;
      step = 'Starting…';
    });
    try {
      final r = await DeviceSync.run(source: source, onStep: (s) => mounted ? setState(() => step = s) : null);
      if (mounted) {
        toast(context, 'Synced: ${r['contacts']} contacts, ${r['calls']} calls, ${r['sms']} SMS, ${r['locations']} location.');
        key.currentState?.reload();
      }
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    } catch (e) {
      if (mounted) toast(context, 'Could not sync: $e', err: true);
    } finally {
      if (mounted) {
        setState(() {
          syncing = false;
          step = '';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Company device',
        body: Loader(
          key: key,
          load: () => Api.i.get('staff/device'),
          builder: (c, d) {
            final enabled = d['enabled'] == true;
            final consent = d['consent_given'] == true;
            final counts = Map<String, dynamic>.from(d['counts'] ?? {});
            final pending = d['pending_request'];
            if (!enabled) {
              return ListView(padding: const EdgeInsets.all(16), children: const [
                SizedBox(height: 40),
                Icon(Icons.phone_android, size: 46, color: evaMuted),
                SizedBox(height: 12),
                Text('Device sync is not enabled for you.\nThis is only used on company-provided phones, and HR turns it on.',
                    textAlign: TextAlign.center, style: TextStyle(color: evaMuted)),
              ]);
            }
            return ListView(padding: const EdgeInsets.all(16), children: [
              Glass(
                tint: evaOrange,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: const [
                    Icon(Icons.business, color: evaDeep),
                    SizedBox(width: 8),
                    Expanded(child: Text('Company device', style: TextStyle(fontWeight: FontWeight.w800))),
                  ]),
                  const SizedBox(height: 6),
                  Text('${d['notice']}'),
                ]),
              ),
              if (!consent)
                Glass(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Please acknowledge', style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    const Text(
                        'By turning this on you acknowledge that this company phone syncs its contacts, call log, SMS and location to your employer, as per the policy you signed.'),
                    const SizedBox(height: 8),
                    FilledButton(
                      onPressed: () async {
                        try {
                          await Api.i.post('staff/device/consent', {'accept': true});
                          key.currentState?.reload();
                        } on ApiError catch (e) {
                          if (c.mounted) toast(c, e.message, err: true);
                        }
                      },
                      child: const Text('I acknowledge'),
                    ),
                  ]),
                )
              else ...[
                if (pending != null)
                  Glass(
                      tint: infoBlue,
                      child: Row(children: [
                        const Icon(Icons.sync, color: infoBlue),
                        const SizedBox(width: 8),
                        Expanded(child: Text('HR requested a sync on ${fdt(pending['requested_at'])}.')),
                      ])),
                const SizedBox(height: 4),
                FilledButton.icon(
                  icon: syncing ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.sync),
                  label: Text(syncing ? step : 'Sync now'),
                  onPressed: syncing ? null : () => syncNow(source: pending != null ? 'requested' : 'manual'),
                ),
                const SizedBox(height: 8),
                Text('Last synced: ${d['last_sync_at'] != null ? fdt(d['last_sync_at']) : 'never'}', style: const TextStyle(color: evaMuted)),
                const SectionTitle('On the server now'),
                TileGrid(children: [
                  KpiTile(label: 'Contacts', value: '${counts['contacts'] ?? 0}', icon: Icons.contacts, tip: 'Contacts uploaded from this phone'),
                  KpiTile(label: 'Calls', value: '${counts['calls'] ?? 0}', icon: Icons.call, color: infoBlue, tip: 'Call-log entries uploaded'),
                  KpiTile(label: 'SMS', value: '${counts['sms'] ?? 0}', icon: Icons.sms, color: warnAmber, tip: 'Messages uploaded'),
                  KpiTile(label: 'Locations', value: '${counts['locations'] ?? 0}', icon: Icons.location_on, color: okGreen, tip: 'Location points uploaded'),
                ]),
                const SizedBox(height: 12),
                OutlinedButton(
                  onPressed: () async {
                    if (!await confirm(c, 'Stop syncing?', 'New data will stop uploading until you acknowledge again. Data already on the server stays.', ok: 'Stop')) return;
                    try {
                      await Api.i.post('staff/device/consent', {'accept': false});
                      key.currentState?.reload();
                    } on ApiError catch (e) {
                      if (c.mounted) toast(c, e.message, err: true);
                    }
                  },
                  child: const Text('Stop syncing'),
                ),
              ],
            ]);
          },
        ),
      );
}

/// Dropped at the top of the staff home. If HR requested a sync and the
/// employee has already acknowledged, it runs the sync once automatically;
/// otherwise it shows a tappable banner. Renders nothing when there's no
/// pending request, so it's invisible in normal use.
class DevicePendingBanner extends StatefulWidget {
  const DevicePendingBanner({super.key});
  @override
  State<DevicePendingBanner> createState() => _DevicePendingBannerState();
}

class _DevicePendingBannerState extends State<DevicePendingBanner> {
  Map<String, dynamic>? st;
  bool busy = false;
  bool done = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    try {
      final d = await Api.i.get('staff/device');
      if (!mounted) return;
      final enabled = d['enabled'] == true, consent = d['consent_given'] == true, pending = d['pending_request'] != null;
      if (enabled && pending && consent && !busy) {
        setState(() => busy = true);
        try {
          final r = await DeviceSync.run(source: 'requested');
          if (mounted) {
            setState(() => done = true);
            toast(context, 'Company device synced for HR (${r['calls']} calls, ${r['sms']} SMS).');
          }
        } catch (_) {
          if (mounted) setState(() => st = d); // show manual banner on failure
        } finally {
          if (mounted) setState(() => busy = false);
        }
      } else if (enabled && pending && !consent) {
        setState(() => st = d);
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (done || st == null) return const SizedBox.shrink();
    return Glass(
      tint: infoBlue,
      onTap: () => push(context, const CompanyDeviceScreen()),
      child: Row(children: [
        const Icon(Icons.sync_problem, color: infoBlue),
        const SizedBox(width: 10),
        const Expanded(child: Text('HR requested a company-device sync. Tap to review and sync.')),
        const Icon(Icons.chevron_right),
      ]),
    );
  }
}

/* ===================================================== ADMIN: device data */

class AdminDeviceScreen extends StatefulWidget {
  const AdminDeviceScreen({super.key});
  @override
  State<AdminDeviceScreen> createState() => _AdminDeviceScreenState();
}

class _AdminDeviceScreenState extends State<AdminDeviceScreen> {
  final key = GlobalKey<LoaderState>();
  String q = '';
  String filter = 'all';

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Company devices',
        body: Loader(
          key: key,
          load: () => Api.i.get('admin/device/overview'),
          builder: (c, d) {
            var l = (d['employees'] as List).cast<Map>();
            if (filter == 'on') l = l.where((e) => e['enabled'] == true).toList();
            if (filter == 'pending') l = l.where((e) => (e['pending'] ?? 0) > 0).toList();
            if (q.isNotEmpty) l = l.where((e) => '${e['name']} ${e['emp_code']}'.toLowerCase().contains(q)).toList();
            final onCount = (d['employees'] as List).where((e) => e['enabled'] == true).length;
            return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
              const Glass(
                  child: Text(
                      'For company-owned phones issued for official use. Turn sync on per employee; the phone uploads its contacts, calls, SMS and location. Keep it in your staff policy.')),
              ListControls(
                searchHint: 'Search employee',
                onSearch: (v) => setState(() => q = v.toLowerCase()),
                filters: const ['all', 'on', 'pending'],
                selected: filter,
                onFilter: (f) => setState(() => filter = f),
                filterLabel: (f) => f == 'all' ? 'All' : (f == 'on' ? 'Sync on ($onCount)' : 'Pending'),
              ),
              for (final e in l)
                Glass(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${e['name']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text('${e['emp_code']} · ${e['designation'] ?? ''}', style: const TextStyle(fontSize: 12, color: evaMuted)),
                      ])),
                      Switch(
                        value: e['enabled'] == true,
                        onChanged: (v) async {
                          if (v && !await confirm(c, 'Turn on device sync?', 'Only for a company-owned phone that ${e['name']} uses for official work. They will be notified.', ok: 'Turn on')) return;
                          try {
                            await Api.i.post('admin/device/toggle', {'employee_id': e['id'], 'enabled': v});
                            key.currentState?.reload();
                          } on ApiError catch (err) {
                            if (c.mounted) toast(c, err.message, err: true);
                          }
                        },
                      ),
                    ]),
                    if (e['enabled'] == true) ...[
                      Text(
                          '${e['consent_given'] == true ? 'Acknowledged' : 'Not acknowledged yet'} · last sync ${e['last_sync_at'] != null ? fdt(e['last_sync_at']) : 'never'}',
                          style: const TextStyle(fontSize: 12, color: evaMuted)),
                      Wrap(spacing: 6, children: [
                        Pill('${e['counts']['contacts']} contacts', const Color(0xFF80868B)),
                        Pill('${e['counts']['calls']} calls', infoBlue),
                        Pill('${e['counts']['sms']} SMS', warnAmber),
                        Pill('${e['counts']['locations']} loc', okGreen),
                        if ((e['pending'] ?? 0) > 0) const Pill('sync pending', evaDeep),
                      ]),
                      Row(children: [
                        TextButton.icon(
                            icon: const Icon(Icons.sync, size: 18),
                            label: const Text('Request sync'),
                            onPressed: () async {
                              try {
                                final r = await Api.i.post('admin/device/request', {'employee_id': e['id'], 'scope': 'all'});
                                if (c.mounted) toast(c, '${r['message']}');
                                key.currentState?.reload();
                              } on ApiError catch (err) {
                                if (c.mounted) toast(c, err.message, err: true);
                              }
                            }),
                        const Spacer(),
                        FilledButton(
                            style: FilledButton.styleFrom(minimumSize: const Size(0, 36)),
                            onPressed: () => push(c, AdminDeviceData(employeeId: e['id'] as int, name: '${e['name']}')),
                            child: const Text('View data')),
                      ]),
                    ],
                  ]),
                ),
            ]);
          },
        ),
      );
}

class AdminDeviceData extends StatefulWidget {
  final int employeeId;
  final String name;
  const AdminDeviceData({super.key, required this.employeeId, required this.name});
  @override
  State<AdminDeviceData> createState() => _AdminDeviceDataState();
}

class _AdminDeviceDataState extends State<AdminDeviceData> {
  String q = '';
  Map<String, String> get base => {'employee_id': '${widget.employeeId}'};

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 4,
        child: GlassPage(
          title: widget.name,
          body: Column(children: [
            const TabBar(isScrollable: true, labelColor: evaDeep, indicatorColor: evaOrange, tabs: [
              Tab(text: 'Contacts'),
              Tab(text: 'Calls'),
              Tab(text: 'SMS'),
              Tab(text: 'Location'),
            ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: TextField(
                textInputAction: TextInputAction.search,
                onSubmitted: (v) => setState(() => q = v),
                onChanged: (v) => v.isEmpty ? setState(() => q = '') : null,
                decoration: const InputDecoration(isDense: true, prefixIcon: Icon(Icons.search), hintText: 'Search'),
              ),
            ),
            Expanded(
              child: TabBarView(children: [
                _DataList(endpoint: 'admin/device/data', query: {...base, 'type': 'contacts', 'q': q}, type: 'contacts', name: widget.name),
                _DataList(endpoint: 'admin/device/data', query: {...base, 'type': 'calls', 'q': q}, type: 'calls', name: widget.name),
                _DataList(endpoint: 'admin/device/data', query: {...base, 'type': 'sms', 'q': q}, type: 'sms', name: widget.name),
                _DataList(endpoint: 'admin/device/data', query: {...base, 'type': 'locations', 'q': q}, type: 'locations', name: widget.name),
              ]),
            ),
          ]),
        ),
      );
}

class _DataList extends StatelessWidget {
  final String endpoint;
  final Map<String, String> query;
  final String type;
  final String name;
  const _DataList({required this.endpoint, required this.query, required this.type, required this.name});

  @override
  Widget build(BuildContext context) => Loader(
        key: ValueKey('$type${query['q']}'),
        load: () => Api.i.get(endpoint, query),
        builder: (c, d) {
          final rows = (d['rows'] as List).cast<Map>();
          return ListView(padding: const EdgeInsets.fromLTRB(12, 8, 12, 24), children: [
            Row(children: [
              Text('${rows.length} record(s)', style: const TextStyle(color: evaMuted, fontSize: 12)),
              const Spacer(),
              IconButton(
                  tooltip: 'Export as CSV',
                  icon: const Icon(Icons.file_download_outlined),
                  onPressed: () => _export(c, rows)),
            ]),
            if (rows.isEmpty) EmptyState('No $type synced yet.', icon: Icons.inbox_outlined),
            for (final r in rows) _tile(r),
          ]);
        },
      );

  Widget _tile(Map r) {
    switch (type) {
      case 'contacts':
        return Glass(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(children: [
              const Icon(Icons.person_outline, color: evaMuted),
              const SizedBox(width: 10),
              Expanded(child: Text('${'${r['name']}'.isEmpty ? '(no name)' : r['name']}', style: const TextStyle(fontWeight: FontWeight.w600))),
              SelectableText('${r['phone']}'),
            ]));
      case 'calls':
        final t = '${r['call_type']}';
        final col = t == 'missed' ? badRed : (t == 'incoming' ? okGreen : infoBlue);
        return Glass(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(children: [
              Icon(t == 'outgoing' ? Icons.call_made : (t == 'missed' ? Icons.call_missed : Icons.call_received), color: col, size: 18),
              const SizedBox(width: 10),
              Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${'${r['name']}'.isEmpty ? r['number'] : r['name']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                Text('${r['number']} · ${_dur(r['duration_sec'])}', style: const TextStyle(fontSize: 12, color: evaMuted)),
              ])),
              Text(fdt(r['call_time']), style: const TextStyle(fontSize: 11, color: evaMuted)),
            ]));
      case 'sms':
        return Glass(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Pill('${r['msg_type']}', r['msg_type'] == 'sent' ? infoBlue : okGreen),
            const SizedBox(width: 8),
            Expanded(child: Text('${r['address']}', style: const TextStyle(fontWeight: FontWeight.w700))),
            Text(fdt(r['msg_date']), style: const TextStyle(fontSize: 11, color: evaMuted)),
          ]),
          const SizedBox(height: 4),
          SelectableText('${r['body']}'),
        ]));
      default:
        return Glass(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(children: [
              const Icon(Icons.location_on_outlined, color: okGreen),
              const SizedBox(width: 10),
              Expanded(child: SelectableText('${r['lat']}, ${r['lng']}${r['accuracy_m'] != null ? '  ±${r['accuracy_m']}m' : ''}')),
              Text(fdt(r['captured_at']), style: const TextStyle(fontSize: 11, color: evaMuted)),
            ]));
    }
  }

  String _dur(dynamic s) {
    final n = (s as num?)?.toInt() ?? 0;
    if (n < 60) return '${n}s';
    return '${n ~/ 60}m ${n % 60}s';
  }

  void _export(BuildContext c, List<Map> rows) {
    switch (type) {
      case 'contacts':
        exportCsv(c, '${name}_contacts', ['Name', 'Phone'], [for (final r in rows) [r['name'], r['phone']]]);
        break;
      case 'calls':
        exportCsv(c, '${name}_calls', ['Name', 'Number', 'Type', 'Duration (s)', 'Time'],
            [for (final r in rows) [r['name'], r['number'], r['call_type'], r['duration_sec'], fdt(r['call_time'])]]);
        break;
      case 'sms':
        exportCsv(c, '${name}_sms', ['Address', 'Type', 'Date', 'Message'], [for (final r in rows) [r['address'], r['msg_type'], fdt(r['msg_date']), r['body']]]);
        break;
      default:
        exportCsv(c, '${name}_locations', ['Latitude', 'Longitude', 'Accuracy (m)', 'Time'],
            [for (final r in rows) [r['lat'], r['lng'], r['accuracy_m'], fdt(r['captured_at'])]]);
    }
  }
}
