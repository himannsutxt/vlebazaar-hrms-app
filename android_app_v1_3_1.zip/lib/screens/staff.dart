import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import '../api.dart';
import '../theme.dart';
import 'device.dart';
import 'staff_more.dart';

void push(BuildContext c, Widget page) => Navigator.push(c, MaterialPageRoute(builder: (_) => page));

/* =============================================================== HOME */

class StaffHome extends StatefulWidget {
  final void Function(int tab)? goTab;
  const StaffHome({super.key, this.goTab});
  @override
  State<StaffHome> createState() => _StaffHomeState();
}

class _StaffHomeState extends State<StaffHome> {
  final key = GlobalKey<LoaderState>();

  @override
  Widget build(BuildContext context) => Loader(
        key: key,
        load: () => Api.i.get('staff/home'),
        builder: (c, d) {
          final t = Map<String, dynamic>.from(d['today'] ?? {});
          final m = Map<String, dynamic>.from(d['month_summary'] ?? {});
          final ann = (d['announcements'] as List?) ?? [];
          final emp = Map<String, dynamic>.from(d['employee'] ?? {});
          final hour = DateTime.now().hour;
          final greet = hour < 12 ? 'Good morning' : (hour < 17 ? 'Good afternoon' : 'Good evening');
          final canPunch = d['punch']?['allowed'] == true;
          Widget quick(IconData i, String label, String tip, Widget page) => Tooltip(
                message: tip,
                child: Glass(
                  onTap: () => push(c, page),
                  padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
                  child: Column(children: [
                    Icon(i, color: evaOrange),
                    const SizedBox(height: 6),
                    Text(label, textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  ]),
                ),
              );
          return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
            const DevicePendingBanner(),
            Row(children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: evaOrange,
                backgroundImage: emp['photo_url'] != null ? NetworkImage('${emp['photo_url']}') : null,
                child: emp['photo_url'] == null
                    ? Text(('${emp['name'] ?? '?'}').substring(0, 1), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))
                    : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('$greet, ${('${emp['name'] ?? ''}').split(' ').first}',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: evaInk)),
                  Text('${emp['designation'] ?? ''} · ${emp['emp_code'] ?? ''}', style: const TextStyle(color: evaMuted)),
                ]),
              ),
            ]),
            const SizedBox(height: 10),
            Glass(
              tint: evaOrange,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text('Today · ${fd(t['date'])}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const Spacer(),
                  StatusPill('${t['status'] ?? '-'}'),
                ]),
                const SizedBox(height: 10),
                Row(children: [
                  _timeBox('IN', t['in_time']),
                  const SizedBox(width: 10),
                  _timeBox('OUT', t['out_time']),
                ]),
                if (canPunch) ...[
                  const SizedBox(height: 12),
                  Tooltip(
                    message: 'Mark your attendance with GPS (and selfie, if your company requires it)',
                    child: FilledButton.icon(
                        icon: const Icon(Icons.fingerprint),
                        label: const Text('Punch in / out'),
                        onPressed: () async {
                          await Navigator.push(c, MaterialPageRoute(builder: (_) => const PunchScreen()));
                          key.currentState?.reload();
                        }),
                  ),
                ],
              ]),
            ),
            SectionTitle('This month', tip: 'Counted from synced biometric + app punches. Tap Attendance for day-by-day details.',
                trailing: TextButton(onPressed: () => widget.goTab?.call(1), child: const Text('Details'))),
            TileGrid(children: [
              KpiTile(label: 'Present', value: num1(m['P']), icon: Icons.check_circle_outline, color: okGreen, tip: 'Full days present this month'),
              KpiTile(label: 'Half days', value: num1(m['HD']), icon: Icons.timelapse, color: warnAmber, tip: 'Late after cut-off or fewer hours'),
              KpiTile(label: 'Absent', value: num1(m['A']), icon: Icons.cancel_outlined, color: badRed, tip: 'Working days with no attendance and no approved leave'),
              KpiTile(label: 'Leave', value: num1(toD(m['L']) + toD(m['UL'])), icon: Icons.beach_access_outlined, color: infoBlue, tip: 'Approved leave days (paid + unpaid)'),
            ]),
            if ((d['pending_leave_requests'] ?? 0) > 0 || (d['pending_location_requests'] ?? 0) > 0) const SectionTitle('Needs your attention'),
            if ((d['pending_leave_requests'] ?? 0) > 0)
              Glass(
                  onTap: () => widget.goTab?.call(2),
                  child: Row(children: [
                    const Icon(Icons.hourglass_bottom, color: infoBlue),
                    const SizedBox(width: 10),
                    Expanded(child: Text('${d['pending_leave_requests']} leave request(s) waiting for HR')),
                    const Icon(Icons.chevron_right),
                  ])),
            if ((d['pending_location_requests'] ?? 0) > 0)
              Glass(
                  onTap: () => push(c, const LocationScreen()),
                  child: Row(children: [
                    const Icon(Icons.location_on, color: evaOrange),
                    const SizedBox(width: 10),
                    Expanded(child: Text('${d['pending_location_requests']} location request(s) — tap to respond')),
                    const Icon(Icons.chevron_right),
                  ])),
            const SectionTitle('Quick actions'),
            GridView.count(
              crossAxisCount: 4,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 8,
              childAspectRatio: 0.9,
              children: [
                quick(Icons.event_available, 'Apply leave', 'Request leave for one or more days', const ApplyLeave()),
                quick(Icons.receipt_long, 'Payslips', 'Your finalized monthly payslips', const PayslipsScreen()),
                quick(Icons.currency_rupee, 'Advance', 'Ask for a salary or purchase advance', const AdvancesScreen()),
                quick(Icons.receipt, 'Expense', 'Claim money you spent for work', const AdvancesScreen(initialTab: 2)),
                quick(Icons.folder_open, 'Documents', 'Your documents and letters from HR', const DocumentsScreen()),
                quick(Icons.report_problem_outlined, 'Grievance', 'Raise a concern with HR', const GrievancesScreen()),
                quick(Icons.groups_2_outlined, 'Team leave', 'Who in your company is on leave', const TeamLeaveScreen()),
                quick(Icons.calculate_outlined, 'My salary', 'How your salary is calculated this month', const SalaryDetailsScreen()),
              ],
            ),
            if (ann.isNotEmpty) ...[
              SectionTitle('Announcements', trailing: TextButton(onPressed: () => push(c, const AnnouncementsScreen()), child: const Text('All'))),
              for (final a in ann.take(3))
                Glass(
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.campaign_outlined, color: evaOrange),
                  const SizedBox(width: 10),
                  Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${a['title'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text('${a['body'] ?? ''}', maxLines: 3, overflow: TextOverflow.ellipsis),
                  ])),
                ])),
            ],
            if (d['latest_performance'] != null) ...[
              const SectionTitle('Latest performance review'),
              Glass(
                  child: Row(children: [
                const Icon(Icons.star_rate_rounded, color: warnAmber),
                const SizedBox(width: 8),
                Text('${d['latest_performance']['rating'] ?? '-'} / 5', style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(width: 10),
                Expanded(child: Text('${d['latest_performance']['remarks'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis)),
              ])),
            ],
          ]);
        },
      );

  Widget _timeBox(String label, dynamic v) => Expanded(
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: Colors.white.withAlpha(170), borderRadius: BorderRadius.circular(14)),
          child: Column(children: [
            Text(label, style: const TextStyle(fontSize: 11, color: evaMuted, fontWeight: FontWeight.w700)),
            Text('${v ?? '--:--'}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          ]),
        ),
      );
}

/* ========================================================= ATTENDANCE */

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});
  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  int month = DateTime.now().month, year = DateTime.now().year;
  String filter = 'all';
  bool newestFirst = false;

  @override
  Widget build(BuildContext context) => Column(children: [
        MonthBar(month: month, year: year, onChanged: (m, y) => setState(() { month = m; year = y; })),
        Expanded(
          child: Loader(
            key: ValueKey('$month-$year'),
            load: () => Api.i.get('staff/attendance', {'month': '$month', 'year': '$year'}),
            builder: (c, d) {
              final all = (d['rows'] as List).cast<Map>();
              final s = Map<String, dynamic>.from(d['summary'] ?? {});
              var rows = filter == 'all' ? all.toList() : all.where((r) => r['status'] == filter || (filter == 'late' && r['is_late'] == true)).toList();
              if (newestFirst) rows = rows.reversed.toList();
              return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
                Wrap(spacing: 6, runSpacing: 6, children: [
                  for (final k in ['P', 'HD', 'A', 'L', 'UL', 'WO', 'H'])
                    if (toD(s[k]) > 0) Tooltip(message: statusLabel(k), child: Pill('$k ${num1(s[k])}', statusColor(k))),
                ]),
                ListControls(
                  filters: const ['all', 'P', 'HD', 'A', 'L', 'WO', 'late'],
                  selected: filter,
                  onFilter: (f) => setState(() => filter = f),
                  filterLabel: (f) => f == 'late' ? 'Late' : statusLabel(f),
                  sorts: const {'old': 'Date: 1st → last', 'new': 'Date: last → 1st'},
                  sort: newestFirst ? 'new' : 'old',
                  onSort: (v) => setState(() => newestFirst = v == 'new'),
                  onExport: () => exportCsv(c, 'my_attendance_$year-$month', ['Date', 'Day', 'Status', 'In', 'Out', 'Hours', 'Late', 'Why'],
                      [for (final r in all) [fd(r['date']), r['day'], statusLabel('${r['status']}'), r['in_time'], r['out_time'], r['worked_text'], r['is_late'] == true ? 'Yes' : '', r['reason']]]),
                ),
                if (rows.isEmpty) const EmptyState('No days match this filter.'),
                for (final r in rows)
                  Glass(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    onTap: ('${r['reason'] ?? ''}${r['remarks'] ?? ''}').isEmpty
                        ? null
                        : () => showDialog(
                            context: c,
                            builder: (_) => AlertDialog(
                                  title: Text(fd(r['date'])),
                                  content: Text([r['reason'], r['remarks']].where((x) => x != null && '$x'.isNotEmpty).join('\n\n')),
                                )),
                    child: Row(children: [
                      SizedBox(
                          width: 46,
                          child: Column(children: [
                            Text('${r['date']}'.substring(8), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                            Text('${r['day']}', style: const TextStyle(fontSize: 11, color: evaMuted)),
                          ])),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            StatusPill('${r['status']}'),
                            if (r['is_late'] == true) ...[const SizedBox(width: 6), const Pill('Late', warnAmber)],
                          ]),
                          const SizedBox(height: 4),
                          Text('${r['in_time'] ?? '--:--'} → ${r['out_time'] ?? '--:--'}   ${r['worked_text'] ?? ''}',
                              style: const TextStyle(color: evaMuted)),
                          if ('${r['reason'] ?? ''}'.isNotEmpty)
                            Text('${r['reason']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: evaDeep)),
                        ]),
                      ),
                    ]),
                  ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                    icon: const Icon(Icons.flag_outlined),
                    label: const Text('Something looks wrong? Tell HR'),
                    onPressed: () => push(
                        c,
                        NewGrievance(
                            cats: const ['Attendance Issue', 'Salary & Payroll', 'Other'],
                            initialCategory: 'Attendance Issue',
                            initialSubject: 'Attendance issue - ${monthLong(month)} $year'))),
              ]);
            },
          ),
        ),
      ]);
}

/* ============================================================== LEAVES */

class LeavesScreen extends StatelessWidget {
  const LeavesScreen({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Column(children: [
          const TabBar(labelColor: evaDeep, indicatorColor: evaOrange, tabs: [Tab(text: 'My leaves'), Tab(text: 'Team on leave')]),
          const Expanded(child: TabBarView(children: [MyLeaves(), TeamLeaveBody()])),
        ]),
      );
}

class MyLeaves extends StatefulWidget {
  const MyLeaves({super.key});
  @override
  State<MyLeaves> createState() => _MyLeavesState();
}

class _MyLeavesState extends State<MyLeaves> {
  final key = GlobalKey<LoaderState>();
  String filter = 'all';
  String sort = 'applied';

  @override
  Widget build(BuildContext context) => Stack(children: [
        Loader(
          key: key,
          load: () => Api.i.get('staff/leaves'),
          builder: (c, d) {
            final types = (d['leave_types'] as List).cast<Map>();
            var l = (d['leaves'] as List).cast<Map>().where((x) => filter == 'all' || x['status'] == filter).toList();
            if (sort == 'from') l.sort((a, b) => '${b['from_date']}'.compareTo('${a['from_date']}'));
            if (sort == 'days') l.sort((a, b) => toD(b['days']).compareTo(toD(a['days'])));
            return ListView(padding: const EdgeInsets.fromLTRB(12, 4, 12, 90), children: [
              if (types.isNotEmpty || d['monthly_leave_quota'] != null) ...[
                SectionTitle('Balances', tip: 'Leave you can still take. Unpaid leave may apply beyond this.'),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final t in types) Pill('${t['name']}: ${num1(t['balance'])}', infoBlue),
                  if (d['monthly_leave_quota'] != null) Pill('Monthly quota: ${d['monthly_leave_quota']}', evaDeep),
                ]),
              ],
              ListControls(
                filters: const ['all', 'pending', 'approved', 'rejected', 'cancelled'],
                selected: filter,
                onFilter: (f) => setState(() => filter = f),
                sorts: const {'applied': 'Newest request', 'from': 'Leave date', 'days': 'Most days'},
                sort: sort,
                onSort: (v) => setState(() => sort = v),
              ),
              if (l.isEmpty) const EmptyState('No leave requests here.', icon: Icons.beach_access_outlined),
              for (final x in l)
                Glass(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(
                          child: Text('${fd(x['from_date'])} → ${fd(x['to_date'])}',
                              style: const TextStyle(fontWeight: FontWeight.w700))),
                      StatusPill('${x['status']}'),
                    ]),
                    const SizedBox(height: 4),
                    Text('${num1(x['days'])} day(s)${x['is_half_day'] == true ? ' · half day' : ''}${x['leave_type'] != null ? ' · ${x['leave_type']}' : ''}${x['pay_type'] != null && x['status'] == 'approved' ? ' · ${x['pay_type']}' : ''}',
                        style: const TextStyle(color: evaMuted)),
                    if ('${x['reason'] ?? ''}'.isNotEmpty) Text('${x['reason']}'),
                    if (x['admin_remarks'] != null && '${x['admin_remarks']}'.isNotEmpty)
                      Text('HR: ${x['admin_remarks']}', style: const TextStyle(color: evaDeep)),
                    if (x['status'] == 'pending')
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          icon: const Icon(Icons.close, size: 18),
                          label: const Text('Cancel request'),
                          onPressed: () async {
                            if (!await confirm(c, 'Cancel this leave request?', '${fd(x['from_date'])} → ${fd(x['to_date'])}')) return;
                            try {
                              await Api.i.post('staff/leaves/cancel', {'leave_id': x['id']});
                              key.currentState?.reload();
                            } on ApiError catch (e) {
                              if (c.mounted) toast(c, e.message, err: true);
                            }
                          },
                        ),
                      ),
                  ]),
                ),
            ]);
          },
        ),
        Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton.extended(
                tooltip: 'Request new leave',
                backgroundColor: evaOrange,
                foregroundColor: Colors.white,
                icon: const Icon(Icons.add),
                label: const Text('Apply'),
                onPressed: () async {
                  final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const ApplyLeave()));
                  if (ok == true) key.currentState?.reload();
                })),
      ]);
}

class ApplyLeave extends StatefulWidget {
  const ApplyLeave({super.key});
  @override
  State<ApplyLeave> createState() => _ApplyLeaveState();
}

class _ApplyLeaveState extends State<ApplyLeave> {
  DateTime from = DateTime.now(), to = DateTime.now();
  bool half = false, busy = false;
  int? typeId;
  List<Map> types = [];
  final reason = TextEditingController();

  @override
  void initState() {
    super.initState();
    Api.i.get('staff/leaves').then((d) {
      if (mounted) setState(() => types = (d['leave_types'] as List).cast<Map>());
    }).catchError((_) {});
  }

  Future<void> pick(bool isFrom) async {
    final d = await showDatePicker(
        context: context,
        initialDate: isFrom ? from : to,
        firstDate: DateTime.now().subtract(const Duration(days: 60)),
        lastDate: DateTime.now().add(const Duration(days: 365)));
    if (d == null) return;
    setState(() {
      if (isFrom) {
        from = d;
        if (to.isBefore(d)) to = d;
      } else {
        to = d;
      }
    });
  }

  int get dayCount => half ? 1 : to.difference(from).inDays + 1;

  Future<void> submit() async {
    if (reason.text.trim().isEmpty) return toast(context, 'Please give a reason', err: true);
    setState(() => busy = true);
    try {
      final r = await Api.i.post('staff/leaves', {
        'from_date': isoDate(from),
        'to_date': isoDate(half ? from : to),
        'is_half_day': half,
        'reason': reason.text.trim(),
        if (typeId != null) 'leave_type_id': typeId,
      });
      if (mounted) {
        toast(context, 'Leave request sent (${num1(r['days'])} day(s)). HR has been notified.');
        Navigator.pop(context, true);
      }
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Apply for leave',
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Glass(
              child: Column(children: [
            ListTile(
                leading: const Icon(Icons.today),
                title: const Text('From'),
                trailing: Text(fd(isoDate(from)), style: const TextStyle(fontWeight: FontWeight.w700)),
                onTap: () => pick(true)),
            if (!half)
              ListTile(
                  leading: const Icon(Icons.event),
                  title: const Text('To'),
                  trailing: Text(fd(isoDate(to)), style: const TextStyle(fontWeight: FontWeight.w700)),
                  onTap: () => pick(false)),
            SwitchListTile(
                title: const Text('Half day'), subtitle: const Text('Only the From date, half a day'), value: half, onChanged: (v) => setState(() => half = v)),
          ])),
          if (types.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: DropdownButtonFormField<int?>(
                value: typeId,
                decoration: const InputDecoration(labelText: 'Leave type (optional)'),
                items: [
                  const DropdownMenuItem<int?>(value: null, child: Text('General leave')),
                  for (final t in types) DropdownMenuItem<int?>(value: t['id'] as int, child: Text('${t['name']} (balance ${num1(t['balance'])})')),
                ],
                onChanged: (v) => setState(() => typeId = v),
              ),
            ),
          const SizedBox(height: 10),
          TextField(controller: reason, maxLines: 3, decoration: const InputDecoration(labelText: 'Reason')),
          const SizedBox(height: 8),
          Text(half ? 'Half a day' : '$dayCount calendar day(s) selected — week offs/holidays inside are counted by HR rules.',
              style: const TextStyle(color: evaMuted)),
          const SizedBox(height: 14),
          FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'Sending…' : 'Submit request')),
        ]),
      );
}

/* ============================================================ PAYSLIPS */

class PayslipsScreen extends StatelessWidget {
  const PayslipsScreen({super.key});
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Payslips',
        actions: [
          IconButton(tooltip: 'Yearly salary & advance statement', icon: const Icon(Icons.summarize_outlined), onPressed: () => push(context, const StatementScreen())),
        ],
        body: Loader(
            load: () => Api.i.get('staff/payslips'),
            builder: (c, d) {
              final l = (d['payslips'] as List).cast<Map>();
              return ListView(padding: const EdgeInsets.all(16), children: [
                if (l.isEmpty) const EmptyState('No payslips yet. They appear here once HR finalizes a month.', icon: Icons.receipt_long),
                for (final p in l)
                  Glass(
                    onTap: () => push(c, PayslipDetail(month: p['month'] as int, year: p['year'] as int)),
                    child: Row(children: [
                      Container(
                        width: 48,
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        decoration: BoxDecoration(color: evaOrange.withAlpha(30), borderRadius: BorderRadius.circular(12)),
                        child: Column(children: [
                          Text(monthShort(p['month'] as int), style: const TextStyle(fontWeight: FontWeight.w800, color: evaDeep)),
                          Text('${p['year']}', style: const TextStyle(fontSize: 11, color: evaMuted)),
                        ]),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Text(inr(p['net_final']), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                      StatusPill('${p['paid_status'] ?? 'unpaid'}'),
                      const Icon(Icons.chevron_right),
                    ]),
                  ),
              ]);
            }),
      );
}

class PayslipDetail extends StatelessWidget {
  final int month, year;
  final String? endpoint;
  final Map<String, String>? extra;
  const PayslipDetail({super.key, required this.month, required this.year, this.endpoint, this.extra});
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Payslip · ${monthShort(month)} $year',
        body: Loader(
          load: () => Api.i.get(endpoint ?? 'staff/payslip', {'month': '$month', 'year': '$year', ...?extra}),
          builder: (c, d) {
            final p = Map<String, dynamic>.from(d['payslip']);
            final e = Map<String, dynamic>.from(d['employee'] ?? {'name': d['name'], 'emp_code': d['emp_code']});
            final earnings = [
              ['Basic', p['basic']], ['HRA', p['hra']], ['Conveyance', p['conveyance']], ['Medical', p['medical_allowance']],
              ['Other allowance', p['other_allowance']], ['Overtime (${num1(p['ot_hours'])} h)', p['ot_amount']],
            ].where((x) => toD(x[1]) != 0).toList();
            final deductions = [
              ['PF', p['pf_deduction']], ['ESI', p['esi_deduction']], ['Advance recovery', p['advance_deduction']], ['Other', p['other_deduction']],
            ].where((x) => toD(x[1]) != 0).toList();
            return ListView(padding: const EdgeInsets.all(16), children: [
              Glass(
                tint: evaOrange,
                child: Column(children: [
                  if (d['company'] != null) Text('${d['company']['name']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text('${e['name'] ?? ''} · ${e['emp_code'] ?? ''}', style: const TextStyle(color: evaMuted)),
                  const SizedBox(height: 8),
                  const Text('Net pay', style: TextStyle(color: evaMuted)),
                  Text(inr(p['net_final'], decimals: true), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: evaDeep)),
                  StatusPill('${p['paid_status'] ?? 'unpaid'}'),
                ]),
              ),
              const SectionTitle('Attendance', tip: 'Payable days = present + paid leave + paid week offs/holidays − deductions'),
              Glass(
                  child: Column(children: [
                KVRow('Days in month', num1(p['total_days'])),
                KVRow('Present', num1(p['present_days'])),
                KVRow('Half days', num1(p['half_days'])),
                KVRow('Week offs', num1(p['week_offs'])),
                KVRow('Holidays', num1(p['holidays'])),
                KVRow('Paid leave', num1(p['approved_leave_days'])),
                KVRow('Unpaid leave', num1(p['unpaid_leave_days'])),
                KVRow('Absent', num1(p['unauthorized_absences'])),
                KVRow('Payable days', num1(p['payable_days']), bold: true),
              ])),
              const SectionTitle('Earnings'),
              Glass(
                  child: Column(children: [
                for (final x in earnings) KVRow('${x[0]}', inr(x[1], decimals: true)),
                KVRow('Gross earning', inr(p['gross_earning'], decimals: true), bold: true),
              ])),
              if (deductions.isNotEmpty) ...[
                const SectionTitle('Deductions'),
                Glass(child: Column(children: [for (final x in deductions) KVRow('${x[0]}', inr(x[1], decimals: true))])),
              ],
              if (toD(p['manual_adjustment']) != 0) ...[
                const SectionTitle('Adjustment'),
                Glass(
                    child: Column(children: [
                  KVRow('Amount', inr(p['manual_adjustment'], decimals: true)),
                  KVRow('Reason', '${p['adjustment_reason'] ?? ''}'),
                ])),
              ],
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.file_download_outlined),
                label: const Text('Download as CSV'),
                onPressed: () => exportCsv(c, 'payslip_$year-$month', ['Item', 'Value'], [
                  ['Employee', '${e['name']} (${e['emp_code']})'],
                  ['Month', '${monthLong(month)} $year'],
                  ['Payable days', p['payable_days']],
                  for (final x in earnings) [x[0], x[1]],
                  ['Gross', p['gross_earning']],
                  for (final x in deductions) [x[0], x[1]],
                  ['Adjustment', p['manual_adjustment']],
                  ['Net pay', p['net_final']],
                ]),
              ),
            ]);
          },
        ),
      );
}

/* ============================================================= PROFILE */

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final key = GlobalKey<LoaderState>();
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'My profile',
        body: Loader(
            key: key,
            load: () => Api.i.get('staff/profile'),
            builder: (c, d) {
              final p = Map<String, dynamic>.from(d['profile']);
              final canEdit = d['can_self_edit'] == true;
              return ListView(padding: const EdgeInsets.all(16), children: [
                Center(
                  child: CircleAvatar(
                    radius: 42,
                    backgroundColor: evaOrange,
                    backgroundImage: p['photo_url'] != null ? NetworkImage('${p['photo_url']}') : null,
                    child: p['photo_url'] == null
                        ? Text('${p['name'] ?? '?'}'.substring(0, 1), style: const TextStyle(fontSize: 30, color: Colors.white))
                        : null,
                  ),
                ),
                const SizedBox(height: 8),
                Center(child: Text('${p['name'] ?? ''}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                Center(child: Text('${p['designation'] ?? ''} · ${p['emp_code'] ?? ''}', style: const TextStyle(color: evaMuted))),
                const SectionTitle('Job'),
                Glass(
                    child: Column(children: [
                  KVRow('Date of joining', fd(p['doj'])),
                  KVRow('Date of birth', fd(p['dob'])),
                  KVRow('Gender', '${p['gender'] ?? ''}'),
                  KVRow('Blood group', '${p['blood_group'] ?? ''}'),
                ])),
                SectionTitle('Contact & bank', tip: canEdit ? 'You can edit these directly.' : 'Changes go to HR for approval first.'),
                Glass(
                    child: Column(children: [
                  KVRow('Phone', '${p['phone'] ?? ''}'),
                  KVRow('Email', '${p['email'] ?? ''}'),
                  KVRow('Address', '${p['address'] ?? ''}'),
                  KVRow('Bank', '${p['bank_name'] ?? ''}'),
                  KVRow('Account no.', '${p['bank_account'] ?? ''}'),
                  KVRow('IFSC', '${p['ifsc'] ?? ''}'),
                ])),
                const SectionTitle('Family contacts'),
                Glass(
                    child: Column(children: [
                  KVRow('Father', '${p['father_name'] ?? ''} ${p['father_mobile'] ?? ''}'.trim()),
                  KVRow('Mother', '${p['mother_name'] ?? ''} ${p['mother_mobile'] ?? ''}'.trim()),
                  KVRow('Spouse mobile', '${p['spouse_mobile'] ?? ''}'),
                ])),
                const SizedBox(height: 12),
                if (canEdit)
                  FilledButton.icon(
                      icon: const Icon(Icons.edit),
                      label: const Text('Edit contact & bank details'),
                      onPressed: () async {
                        final ok = await Navigator.push<bool>(c, MaterialPageRoute(builder: (_) => EditProfile(profile: p)));
                        if (ok == true) key.currentState?.reload();
                      })
                else
                  FilledButton.icon(
                      icon: const Icon(Icons.edit_note),
                      label: const Text('Request a change'),
                      onPressed: () => push(c, const ProfileRequestsScreen())),
              ]);
            }),
      );
}

class EditProfile extends StatefulWidget {
  final Map<String, dynamic> profile;
  const EditProfile({super.key, required this.profile});
  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  late final c = {
    for (final k in ['phone', 'email', 'address', 'bank_name', 'bank_account', 'ifsc']) k: TextEditingController(text: '${widget.profile[k] ?? ''}')
  };
  bool busy = false;
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Edit details',
        body: ListView(padding: const EdgeInsets.all(16), children: [
          for (final e in {
            'phone': 'Phone',
            'email': 'Email',
            'address': 'Address',
            'bank_name': 'Bank name',
            'bank_account': 'Bank account number',
            'ifsc': 'IFSC code'
          }.entries)
            Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: TextField(controller: c[e.key], maxLines: e.key == 'address' ? 3 : 1, decoration: InputDecoration(labelText: e.value))),
          FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      setState(() => busy = true);
                      try {
                        await Api.i.post('staff/profile', {for (final e in c.entries) e.key: e.value.text.trim()});
                        if (context.mounted) {
                          toast(context, 'Saved');
                          Navigator.pop(context, true);
                        }
                      } on ApiError catch (e) {
                        if (context.mounted) toast(context, e.message, err: true);
                      } finally {
                        if (mounted) setState(() => busy = false);
                      }
                    },
              child: const Text('Save')),
        ]),
      );
}

/* =============================================================== PUNCH */

class PunchScreen extends StatefulWidget {
  const PunchScreen({super.key});
  @override
  State<PunchScreen> createState() => _PunchScreenState();
}

class _PunchScreenState extends State<PunchScreen> {
  final key = GlobalKey<LoaderState>();
  bool busy = false;
  String step = '';

  Future<void> punch(Map cfg) async {
    setState(() {
      busy = true;
      step = 'Getting your location…';
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) throw ApiError('Please turn on Location (GPS) on your phone.', 0);
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        throw ApiError('Location permission is needed to punch. Allow it in Settings → Apps → VleBazaar EMS.', 0);
      }
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
      String? selfie;
      if (cfg['selfie_required'] == true) {
        setState(() => step = 'Take a selfie…');
        final x = await ImagePicker().pickImage(source: ImageSource.camera, preferredCameraDevice: CameraDevice.front, maxWidth: 800, imageQuality: 70);
        if (x == null) throw ApiError('A selfie is required to punch.', 0);
        selfie = base64Encode(await File(x.path).readAsBytes());
      }
      setState(() => step = 'Sending…');
      final r = await Api.i.post('staff/punch', {
        'type': cfg['next_type'],
        'lat': pos.latitude,
        'lng': pos.longitude,
        'accuracy': pos.accuracy,
        if (selfie != null) 'selfie_base64': selfie,
      });
      if (mounted) toast(context, r['message']?.toString() ?? 'Punched ${cfg['next_type']}');
      key.currentState?.reload();
    } on ApiError catch (e) {
      if (!mounted) return;
      if (e.code == 'consent_required') {
        final yes = await confirm(context, 'Location consent',
            'Your location is read only at the moment you punch, or when HR sends a visible request that you can decline. You can withdraw consent any time from "Location & privacy".',
            ok: 'I agree');
        if (yes) {
          await Api.i.post('consent/location', {'accept': true});
          key.currentState?.reload();
        }
      } else {
        toast(context, e.message, err: true);
      }
    } catch (e) {
      if (mounted) toast(context, 'Could not punch: $e', err: true);
    } finally {
      if (mounted) {
        setState(() {
          busy = false;
          step = '';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Punch',
        body: Loader(
            key: key,
            load: () => Api.i.get('staff/punch'),
            builder: (c, d) {
              final today = (d['today'] as List?) ?? [];
              final nxt = '${d['next_type']}'.toUpperCase();
              return ListView(padding: const EdgeInsets.all(16), children: [
                if (d['allowed'] != true)
                  const Glass(
                      child: ListTile(
                          leading: Icon(Icons.block, color: badRed), title: Text('Punching from the app is not enabled for you. Please contact HR.'))),
                if (d['office_configured'] != true)
                  const Glass(child: ListTile(leading: Icon(Icons.info_outline), title: Text('Office location is not set up yet in Company Settings.'))),
                const SizedBox(height: 20),
                Center(
                  child: Tooltip(
                    message: 'Records your $nxt time using GPS${d['selfie_required'] == true ? ' and a selfie' : ''}',
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: busy || d['allowed'] != true ? null : () => punch(d),
                      child: Container(
                        width: 170,
                        height: 170,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                              colors: d['allowed'] == true ? [evaOrange, evaPeach] : [Colors.grey, Colors.grey.shade400]),
                          boxShadow: [BoxShadow(color: evaOrange.withAlpha(90), blurRadius: 30, spreadRadius: 2)],
                        ),
                        child: Center(
                          child: busy
                              ? const CircularProgressIndicator(color: Colors.white)
                              : Column(mainAxisSize: MainAxisSize.min, children: [
                                  const Icon(Icons.fingerprint, size: 56, color: Colors.white),
                                  Text('PUNCH $nxt', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
                                ]),
                        ),
                      ),
                    ),
                  ),
                ),
                if (step.isNotEmpty) Padding(padding: const EdgeInsets.all(10), child: Text(step, textAlign: TextAlign.center)),
                const SizedBox(height: 16),
                Text('Allowed radius ${d['radius_m']} m · GPS accuracy must be 100 m or better${d['selfie_required'] == true ? ' · selfie required' : ''}',
                    textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: evaMuted)),
                const SectionTitle("Today's punches"),
                if (today.isEmpty) const EmptyState('No app punches today.', icon: Icons.schedule),
                for (final p in today)
                  Glass(
                      child: Row(children: [
                    Icon(p['punch_type'] == 'in' ? Icons.login : Icons.logout, color: p['punch_type'] == 'in' ? okGreen : badRed),
                    const SizedBox(width: 10),
                    Text('${p['punch_type']}'.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800)),
                    const Spacer(),
                    Text(fdt(p['punched_at'])),
                  ])),
              ]);
            }),
      );
}

/* ========================================================== GRIEVANCES */

class GrievancesScreen extends StatefulWidget {
  const GrievancesScreen({super.key});
  @override
  State<GrievancesScreen> createState() => _GrievancesScreenState();
}

class _GrievancesScreenState extends State<GrievancesScreen> {
  final key = GlobalKey<LoaderState>();
  List cats = [];
  String filter = 'all';
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Grievances',
        fab: FloatingActionButton.extended(
            tooltip: 'Raise a new grievance with HR',
            backgroundColor: evaOrange,
            foregroundColor: Colors.white,
            icon: const Icon(Icons.add),
            label: const Text('Raise'),
            onPressed: () async {
              final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => NewGrievance(cats: cats.isEmpty ? ['Other'] : cats)));
              if (ok == true) key.currentState?.reload();
            }),
        body: Loader(
            key: key,
            load: () async {
              final d = await Api.i.get('staff/grievances');
              cats = d['categories'] as List;
              return d;
            },
            builder: (c, d) {
              final l = (d['grievances'] as List).cast<Map>().where((g) => filter == 'all' || g['status'] == filter).toList();
              return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 90), children: [
                ListControls(
                    filters: const ['all', 'pending', 'in_review', 'resolved', 'rejected'],
                    selected: filter,
                    onFilter: (f) => setState(() => filter = f)),
                if (l.isEmpty) const EmptyState('No grievances here. Use Raise to tell HR about a problem.', icon: Icons.sentiment_satisfied),
                for (final g in l) GrievanceCard(g: g),
              ]);
            }),
      );
}

class GrievanceCard extends StatelessWidget {
  final Map g;
  final VoidCallback? onTap;
  final bool showEmployee;
  const GrievanceCard({super.key, required this.g, this.onTap, this.showEmployee = false});
  @override
  Widget build(BuildContext context) {
    Widget step(String label, dynamic at, bool done) => Row(children: [
          Icon(done ? Icons.check_circle : Icons.radio_button_unchecked, size: 16, color: done ? okGreen : evaMuted),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontSize: 12)),
          const Spacer(),
          Text(at != null ? fdt(at) : '', style: const TextStyle(fontSize: 11, color: evaMuted)),
        ]);
    final closed = g['status'] == 'resolved' || g['status'] == 'rejected';
    return Glass(
      onTap: onTap,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text('${g['subject']}', style: const TextStyle(fontWeight: FontWeight.w800))),
          if (g['priority'] == 'urgent' || g['priority'] == 'high') ...[StatusPill('${g['priority']}'), const SizedBox(width: 6)],
          StatusPill('${g['status']}'),
        ]),
        Text('${showEmployee ? '${g['employee']} · ' : ''}${g['category']}', style: const TextStyle(color: evaMuted, fontSize: 12)),
        const SizedBox(height: 6),
        Text('${g['description']}', maxLines: onTap == null ? 20 : 3, overflow: TextOverflow.ellipsis),
        const SizedBox(height: 8),
        step('Submitted', g['submitted_at'], true),
        step('In review', g['in_review_at'], g['in_review_at'] != null || closed || g['status'] == 'in_review'),
        step(g['status'] == 'rejected' ? 'Rejected' : 'Resolved', g['resolved_at'], closed),
        if ('${g['hr_reply'] ?? ''}'.isNotEmpty)
          Container(
              margin: const EdgeInsets.only(top: 8),
              padding: const EdgeInsets.all(10),
              width: double.infinity,
              decoration: BoxDecoration(color: const Color(0xFFFFF0E6), borderRadius: BorderRadius.circular(12)),
              child: Text('HR reply: ${g['hr_reply']}')),
      ]),
    );
  }
}

class NewGrievance extends StatefulWidget {
  final List cats;
  final String? initialCategory;
  final String? initialSubject;
  const NewGrievance({super.key, required this.cats, this.initialCategory, this.initialSubject});
  @override
  State<NewGrievance> createState() => _NewGrievanceState();
}

class _NewGrievanceState extends State<NewGrievance> {
  late String cat = widget.initialCategory ?? '${widget.cats.first}';
  String prio = 'normal';
  late final sub = TextEditingController(text: widget.initialSubject ?? '');
  final desc = TextEditingController();
  bool busy = false;

  Future<void> submit() async {
    if (sub.text.trim().isEmpty || desc.text.trim().isEmpty) return toast(context, 'Subject and details are required', err: true);
    setState(() => busy = true);
    try {
      await Api.i.post('staff/grievances', {'category': cat, 'priority': prio, 'subject': sub.text.trim(), 'description': desc.text.trim()});
      if (mounted) {
        toast(context, 'Sent to HR');
        Navigator.pop(context, true);
      }
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cats = widget.cats.map((e) => '$e').toList();
    if (!cats.contains(cat)) cats.insert(0, cat);
    return GlassPage(
      title: 'Raise a grievance',
      body: ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(
            value: cat,
            decoration: const InputDecoration(labelText: 'Category'),
            items: [for (final c in cats) DropdownMenuItem(value: c, child: Text(c))],
            onChanged: (v) => setState(() => cat = v!)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
            value: prio,
            decoration: const InputDecoration(labelText: 'Priority', helperText: 'Urgent goes to the top of HR\'s list'),
            items: [for (final p in ['normal', 'high', 'urgent']) DropdownMenuItem(value: p, child: Text(statusLabel(p)))],
            onChanged: (v) => setState(() => prio = v!)),
        const SizedBox(height: 12),
        TextField(controller: sub, decoration: const InputDecoration(labelText: 'Subject')),
        const SizedBox(height: 12),
        TextField(controller: desc, maxLines: 6, decoration: const InputDecoration(labelText: 'Details', helperText: 'What happened, when, and what you would like HR to do')),
        const SizedBox(height: 16),
        FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'Sending…' : 'Submit')),
      ]),
    );
  }
}

/* ======================================================= LOCATION/PRIVACY */

class LocationScreen extends StatefulWidget {
  const LocationScreen({super.key});
  @override
  State<LocationScreen> createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  final key = GlobalKey<LoaderState>();
  Future<void> respond(Map r, bool decline) async {
    try {
      if (decline) {
        await Api.i.post('staff/location/respond', {'request_id': r['id'], 'decline': true});
      } else {
        final p = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
        await Api.i.post('staff/location/respond', {'request_id': r['id'], 'lat': p.latitude, 'lng': p.longitude, 'accuracy': p.accuracy});
      }
      key.currentState?.reload();
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    } catch (e) {
      if (mounted) toast(context, 'Could not read location: $e', err: true);
    }
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Location & privacy',
        body: Loader(
            key: key,
            load: () async {
              final p = await Api.i.get('staff/location/pending');
              final h = await Api.i.get('staff/location/history');
              return {'pending': p, 'history': h};
            },
            builder: (c, d) {
              final pend = ((d['pending']['requests'] ?? []) as List).cast<Map>();
              final hist = ((d['history']['history'] ?? []) as List).cast<Map>();
              return ListView(padding: const EdgeInsets.all(16), children: [
                const Glass(
                    child: Text(
                        'Nobody can track you secretly. HR can only send a visible request, which you may accept or decline. Every request is listed below.')),
                Row(children: [
                  Expanded(
                      child: OutlinedButton(
                          onPressed: () async {
                            await Api.i.post('consent/location', {'accept': true});
                            if (c.mounted) toast(c, 'Consent saved');
                          },
                          child: const Text('Give consent'))),
                  const SizedBox(width: 8),
                  Expanded(
                      child: OutlinedButton(
                          onPressed: () async {
                            await Api.i.post('consent/location', {'accept': false});
                            if (c.mounted) toast(c, 'Consent withdrawn');
                          },
                          child: const Text('Withdraw'))),
                ]),
                const SectionTitle('Waiting for you'),
                if (pend.isEmpty) const EmptyState('No pending requests.', icon: Icons.location_off_outlined),
                for (final r in pend)
                  Glass(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${r['requested_by'] ?? 'HR'} asked for your location', style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text(fdt(r['requested_at']), style: const TextStyle(color: evaMuted)),
                    Row(children: [
                      TextButton(onPressed: () => respond(r, false), child: const Text('Share now')),
                      TextButton(onPressed: () => respond(r, true), child: const Text('Decline')),
                    ]),
                  ])),
                const SectionTitle('History'),
                if (hist.isEmpty) const EmptyState('Nobody has asked for your location.'),
                for (final r in hist)
                  Glass(
                      child: Row(children: [
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${r['requested_by'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text(fdt(r['requested_at']), style: const TextStyle(color: evaMuted, fontSize: 12)),
                    ])),
                    StatusPill('${r['status']}'),
                  ])),
              ]);
            }),
      );
}
