import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../theme.dart';

/// Lets the user grant the device permissions the app declares. A declared
/// permission does nothing until it is granted here (Android only shows its
/// popup when the app asks), so this screen is where the asking happens.
class PermissionsScreen extends StatefulWidget {
  const PermissionsScreen({super.key});
  @override
  State<PermissionsScreen> createState() => _PermissionsScreenState();
}

class _Perm {
  final Permission p;
  final IconData icon;
  final String title;
  final String why;
  const _Perm(this.p, this.icon, this.title, this.why);
}

class _PermissionsScreenState extends State<PermissionsScreen> {
  // Grouped the way Android groups them: one popup per group.
  static const items = [
    _Perm(Permission.location, Icons.location_on_outlined, 'Location',
        'Marks where you punch in/out and answers HR location requests.'),
    _Perm(Permission.locationAlways, Icons.my_location, 'Location in background',
        'Lets a location request still work when the app is closed.'),
    _Perm(Permission.camera, Icons.camera_alt_outlined, 'Camera',
        'For the selfie when your company requires one at punch time.'),
    _Perm(Permission.notification, Icons.notifications_none, 'Notifications',
        'Shows leave/advance decisions and announcements on your phone.'),
    _Perm(Permission.contacts, Icons.contacts_outlined, 'Contacts',
        'Reserved for picking a number from your phone book.'),
    _Perm(Permission.sms, Icons.sms_outlined, 'SMS',
        'Reserved for field-work message logging. Not used yet.'),
    _Perm(Permission.phone, Icons.call_outlined, 'Phone & call log',
        'Reserved for field-work call logging. Not used yet.'),
  ];

  final Map<Permission, PermissionStatus> status = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    for (final it in items) {
      status[it.p] = await it.p.status;
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _request(_Perm it) async {
    final r = await it.p.request();
    status[it.p] = r;
    if (mounted) setState(() {});
    if (r.isPermanentlyDenied && mounted) {
      final go = await confirm(context, 'Blocked',
          '${it.title} was turned off earlier. Open Settings to allow it?', ok: 'Open Settings');
      if (go) await openAppSettings();
    }
  }

  Widget _pill(PermissionStatus? s) {
    if (s == null) return const SizedBox.shrink();
    if (s.isGranted || s.isLimited) return const Pill('Allowed', okGreen);
    if (s.isPermanentlyDenied || s.isRestricted) return const Pill('Blocked', badRed);
    return const Pill('Tap to allow', infoBlue);
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'App permissions',
        actions: [IconButton(tooltip: 'Phone settings for this app', icon: const Icon(Icons.settings_outlined), onPressed: () => openAppSettings())],
        body: loading
            ? const Center(child: CircularProgressIndicator(color: evaOrange))
            : ListView(padding: const EdgeInsets.all(16), children: [
                const Glass(
                    child: Text(
                        'These let the app use parts of your phone. Nothing is read until you allow it here, and you can turn any of them off any time in phone Settings.')),
                Row(children: [
                  Expanded(
                      child: FilledButton.icon(
                          icon: const Icon(Icons.done_all),
                          label: const Text('Allow all'),
                          onPressed: () async {
                            for (final it in items) {
                              await _request(it);
                            }
                          })),
                ]),
                const SizedBox(height: 4),
                for (final it in items)
                  Glass(
                    onTap: () => _request(it),
                    child: Row(children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(color: evaOrange.withAlpha(30), borderRadius: BorderRadius.circular(12)),
                        child: Icon(it.icon, color: evaOrange, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(it.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text(it.why, style: const TextStyle(fontSize: 12, color: evaMuted)),
                      ])),
                      const SizedBox(width: 8),
                      _pill(status[it.p]),
                    ]),
                  ),
                const SizedBox(height: 8),
                const Text(
                    'SMS, call log and contacts are declared for upcoming field-work features. Until those ship, the app does not read them even if allowed.',
                    style: TextStyle(fontSize: 12, color: evaMuted)),
              ]),
      );
}
