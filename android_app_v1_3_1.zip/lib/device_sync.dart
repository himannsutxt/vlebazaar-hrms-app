import 'dart:io';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'api.dart';

/// Reads company-device data (contacts, call log, SMS, location) on the phone
/// and uploads it to the server. Only runs when HR has enabled device sync for
/// this employee and the employee has accepted it in the app. Everything it
/// reads it also reports back in the counts, so the employee can see it.
///
/// Contacts/call-log/SMS are read through a small native channel (MainActivity)
/// rather than plugins, so there are no plugin build-compatibility issues.
class DeviceSync {
  static const _ch = MethodChannel('vlebazaar/device');
  static const maxCalls = 1000;
  static const maxSms = 1000;

  /// Returns a map of what was uploaded, or throws ApiError.
  static Future<Map<String, int>> run({String source = 'manual', void Function(String)? onStep}) async {
    if (!Platform.isAndroid) {
      throw ApiError('Device sync works on Android company phones only.', 0);
    }

    final body = <String, dynamic>{'source': source, 'app_version': '1.3.0'};

    onStep?.call('Reading contacts…');
    try {
      if (await Permission.contacts.request().isGranted) {
        final raw = await _ch.invokeMethod('getContacts');
        if (raw is List) {
          body['contacts'] = raw.map((e) {
            final m = Map<dynamic, dynamic>.from(e as Map);
            return {'name': m['name'] ?? '', 'phone': m['phone'] ?? ''};
          }).toList();
        }
      }
    } catch (_) {}

    onStep?.call('Reading call log…');
    try {
      if (await Permission.phone.request().isGranted) {
        final raw = await _ch.invokeMethod('getCallLog', {'limit': maxCalls});
        if (raw is List) {
          body['call_logs'] = raw.map((e) {
            final m = Map<dynamic, dynamic>.from(e as Map);
            return {
              'number': m['number'] ?? '',
              'name': m['name'] ?? '',
              'type': m['type'] ?? 'other',
              'duration': m['duration'] ?? 0,
              'time': m['time'] ?? 0,
            };
          }).toList();
        }
      }
    } catch (_) {}

    onStep?.call('Reading messages…');
    try {
      if (await Permission.sms.request().isGranted) {
        final raw = await _ch.invokeMethod('getSms', {'limit': maxSms});
        if (raw is List) {
          body['sms'] = raw.map((e) {
            final m = Map<dynamic, dynamic>.from(e as Map);
            return {'address': m['address'] ?? '', 'body': m['body'] ?? '', 'type': m['type'] ?? 'inbox', 'date': m['date'] ?? 0};
          }).toList();
        }
      }
    } catch (_) {}

    onStep?.call('Reading location…');
    try {
      if (await Permission.location.request().isGranted && await Geolocator.isLocationServiceEnabled()) {
        final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
        body['locations'] = [
          {'lat': pos.latitude, 'lng': pos.longitude, 'accuracy': pos.accuracy, 'time': DateTime.now().millisecondsSinceEpoch}
        ];
      }
    } catch (_) {}

    onStep?.call('Uploading…');
    final r = await Api.i.post('staff/device/sync', body);
    final s = Map<String, dynamic>.from(r['synced'] ?? {});
    return {
      'contacts': (s['contacts'] ?? 0) as int,
      'calls': (s['calls'] ?? 0) as int,
      'sms': (s['sms'] ?? 0) as int,
      'locations': (s['locations'] ?? 0) as int,
    };
  }
}
