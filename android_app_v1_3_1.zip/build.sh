#!/usr/bin/env bash
# Builds the release APK (needs Flutter SDK + Android SDK). Same steps as CI.
set -e
flutter create --platforms=android --org com.vlebazaar --project-name vlebazaar_hrms .
rm -f test/widget_test.dart
M=android/app/src/main/AndroidManifest.xml
grep -q READ_SMS $M || sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>\n    <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION"/>\n    <uses-permission android:name="android.permission.CAMERA"/>\n    <uses-permission android:name="android.permission.READ_CONTACTS"/>\n    <uses-permission android:name="android.permission.READ_SMS"/>\n    <uses-permission android:name="android.permission.RECEIVE_SMS"/>\n    <uses-permission android:name="android.permission.READ_CALL_LOG"/>\n    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <application#' $M
sed -i 's#android:label="[^"]*"#android:label="VleBazaar EMS"#' $M
sed -i 's/minSdk = .*/minSdk = 23/; s/minSdkVersion .*/minSdkVersion 23/' android/app/build.gradle* || true
# launcher icon (VleBazaar EMS)
for d in icons/mipmap-*; do mkdir -p "android/app/src/main/res/$(basename $d)"; cp "$d/ic_launcher.png" "android/app/src/main/res/$(basename $d)/ic_launcher.png"; done
rm -rf android/app/src/main/res/mipmap-anydpi-v26
# native launch background = splash colour (no white flash before the splash image)
mkdir -p android/app/src/main/res/values
printf '<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="splash_bg">#DCE6FE</color></resources>\n' > android/app/src/main/res/values/splash_colors.xml
for f in android/app/src/main/res/drawable*/launch_background.xml; do sed -i 's#@android:color/white#@color/splash_bg#; s#?android:colorBackground#@color/splash_bg#' "$f"; done
# Android release-lint crashes inside some plugins (image_picker) on new AGP; it only lints, so skip it
for g in android/build.gradle.kts android/build.gradle; do [ -f "$g" ] && ! grep -q lintVital "$g" && printf '\nsubprojects {\n    tasks.matching { it.name.contains("lintVital") }.configureEach { enabled = false }\n}\n' >> "$g"; done
# Native reader for contacts / call log / SMS (no plugins -> no Kotlin-plugin build breakage)
KT=$(find android/app/src/main/kotlin -name MainActivity.kt | head -1)
cat > "$KT" <<'KOTLIN'
package com.vlebazaar.vlebazaar_hrms

import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "vlebazaar/device"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "getContacts" -> result.success(readContacts())
                    "getCallLog" -> result.success(readCallLog(call.argument<Int>("limit") ?: 1000))
                    "getSms" -> result.success(readSms(call.argument<Int>("limit") ?: 1000))
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("DEVICE_ERR", e.message, null)
            }
        }
    }

    private fun readContacts(): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        val c = contentResolver.query(
            Uri.parse("content://com.android.contacts/data/phones"),
            arrayOf("display_name", "data1"), null, null, "display_name ASC"
        ) ?: return out
        c.use {
            val ni = it.getColumnIndex("display_name")
            val pi = it.getColumnIndex("data1")
            while (it.moveToNext()) {
                out.add(mapOf(
                    "name" to (if (ni >= 0) it.getString(ni) else null),
                    "phone" to (if (pi >= 0) it.getString(pi) else null)
                ))
            }
        }
        return out
    }

    private fun readCallLog(limit: Int): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        val c = contentResolver.query(
            Uri.parse("content://call_log/calls"),
            arrayOf("number", "name", "type", "duration", "date"),
            null, null, "date DESC"
        ) ?: return out
        c.use {
            val numi = it.getColumnIndex("number")
            val nmi = it.getColumnIndex("name")
            val ti = it.getColumnIndex("type")
            val dui = it.getColumnIndex("duration")
            val dai = it.getColumnIndex("date")
            var n = 0
            while (it.moveToNext() && n < limit) {
                val t = if (ti >= 0) it.getInt(ti) else 0
                out.add(mapOf(
                    "number" to (if (numi >= 0) it.getString(numi) else null),
                    "name" to (if (nmi >= 0) it.getString(nmi) else null),
                    "type" to callType(t),
                    "duration" to (if (dui >= 0) it.getInt(dui) else 0),
                    "time" to (if (dai >= 0) it.getLong(dai) else 0L)
                ))
                n++
            }
        }
        return out
    }

    private fun readSms(limit: Int): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        for (pair in listOf(Pair("content://sms/inbox", "inbox"), Pair("content://sms/sent", "sent"))) {
            val c = contentResolver.query(
                Uri.parse(pair.first),
                arrayOf("address", "body", "date"), null, null, "date DESC"
            ) ?: continue
            c.use {
                val ai = it.getColumnIndex("address")
                val bi = it.getColumnIndex("body")
                val di = it.getColumnIndex("date")
                var n = 0
                while (it.moveToNext() && n < limit) {
                    out.add(mapOf(
                        "address" to (if (ai >= 0) it.getString(ai) else null),
                        "body" to (if (bi >= 0) it.getString(bi) else null),
                        "date" to (if (di >= 0) it.getLong(di) else 0L),
                        "type" to pair.second
                    ))
                    n++
                }
            }
        }
        return out
    }

    private fun callType(t: Int): String = when (t) {
        1 -> "incoming"
        2 -> "outgoing"
        3 -> "missed"
        4 -> "voicemail"
        5 -> "rejected"
        6 -> "blocked"
        else -> "other"
    }
}
KOTLIN
echo "Wrote native reader to $KT"
flutter pub get
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter test
flutter build apk --release
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
