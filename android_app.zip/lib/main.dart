import 'package:flutter/material.dart';
import 'api.dart';
import 'screens/login.dart';
import 'screens/shell.dart';
import 'theme.dart';

final navKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.i.load();
  Api.i.onUnauthorized = () => navKey.currentState?.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  runApp(const HrmsApp());
}

class HrmsApp extends StatelessWidget {
  const HrmsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'VLEBAZAAR HRMS',
        navigatorKey: navKey,
        debugShowCheckedModeBanner: false,
        theme: evaTheme(),
        home: Api.i.token == null ? const LoginScreen() : const Shell(),
      );
}
