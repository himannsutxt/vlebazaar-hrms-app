import 'package:flutter/material.dart';

const evaOrange = Color(0xFFF0660D);
const evaPeach = Color(0xFFE0926B);
const evaPage = Color(0xFFFFF5F5);
const evaDeep = Color(0xFF9A3B12);
const evaBorder = Color(0xFFF1DCD3);

ThemeData evaTheme() => ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: evaOrange, primary: evaOrange),
      scaffoldBackgroundColor: evaPage,
      appBarTheme: const AppBarTheme(
          backgroundColor: evaOrange, foregroundColor: Colors.white, elevation: 0),
      cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: const EdgeInsets.symmetric(vertical: 6),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16), side: const BorderSide(color: evaBorder))),
      filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
              backgroundColor: evaOrange,
              minimumSize: const Size.fromHeight(48),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))),
      inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: evaBorder))),
      navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Colors.white, indicatorColor: Color(0xFFFFE0CC)),
    );

Color statusColor(String s) {
  switch (s) {
    case 'P':
    case 'approved':
    case 'resolved':
      return const Color(0xFF1E8E3E);
    case 'A':
    case 'rejected':
    case 'UL':
      return const Color(0xFFD93025);
    case 'HD':
    case 'in_review':
      return const Color(0xFFE8A200);
    case 'L':
    case 'pending':
      return const Color(0xFF1A73E8);
    default:
      return const Color(0xFF80868B);
  }
}

class Pill extends StatelessWidget {
  final String text;
  final Color color;
  const Pill(this.text, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12)),
      );
}

void toast(BuildContext c, String m, {bool err = false}) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(
        content: Text(m), backgroundColor: err ? const Color(0xFFD93025) : evaDeep));

/// "2026-11-15" -> "15-Nov-2026" (same as the website's d-M-Y).
String fd(String? d) {
  if (d == null || d.length < 10) return d ?? '–';
  const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  final mm = int.tryParse(d.substring(5, 7)) ?? 1;
  return '${d.substring(8, 10)}-${m[mm - 1]}-${d.substring(0, 4)}';
}

/// Loads data, shows spinner/error/retry, supports pull-to-refresh.
class Loader extends StatefulWidget {
  final Future<Map<String, dynamic>> Function() load;
  final Widget Function(BuildContext, Map<String, dynamic>) builder;
  const Loader({super.key, required this.load, required this.builder});
  @override
  State<Loader> createState() => LoaderState();
}

class LoaderState extends State<Loader> {
  late Future<Map<String, dynamic>> f = widget.load();
  void reload() => setState(() => f = widget.load());
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator(color: evaOrange));
          }
          if (s.hasError) {
            return Center(
                child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('${s.error}', textAlign: TextAlign.center),
                const SizedBox(height: 12),
                FilledButton(onPressed: reload, child: const Text('Retry'))
              ]),
            ));
          }
          return RefreshIndicator(
              color: evaOrange,
              onRefresh: () async {
                reload();
                await f;
              },
              child: widget.builder(c, s.data!));
        },
      );
}
