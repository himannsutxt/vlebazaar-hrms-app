import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';
import 'staff.dart' show scaffoldPage, KV;

class AdminHome extends StatelessWidget {
  const AdminHome({super.key});
  @override
  Widget build(BuildContext context) => Loader(load: () => Api.i.get('admin/home'), builder: (c, d) {
        final t = Map<String, dynamic>.from(d['today_counts'] ?? {});
        final p = Map<String, dynamic>.from(d['pending'] ?? {});
        Widget kpi(String l, dynamic v, Color col) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
              Text('$v', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: col)), Text(l, style: const TextStyle(fontSize: 12))]))));
        return ListView(padding: const EdgeInsets.all(16), children: [
          Text(fd(d['date']), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: evaDeep)),
          Row(children: [kpi('Employees', d['active_employees'], evaOrange), kpi('Present', d['present_today'], statusColor('P')), kpi('On leave', d['on_leave_today'], statusColor('L'))]),
          const Text('Today', style: TextStyle(fontWeight: FontWeight.w700)),
          Wrap(spacing: 8, children: [for (final e in t.entries) Chip(label: Text('${e.key}: ${e.value}'))]),
          const SizedBox(height: 8),
          const Text('Waiting for you', style: TextStyle(fontWeight: FontWeight.w700)),
          Row(children: [kpi('Leaves', p['leaves'] ?? 0, evaDeep), kpi('Grievances', p['grievances'] ?? 0, evaDeep), kpi('Advances', p['advances'] ?? 0, evaDeep)]),
        ]);
      });
}

class AdminTeam extends StatelessWidget {
  const AdminTeam({super.key});
  @override
  Widget build(BuildContext context) => Loader(load: () => Api.i.get('admin/team'), builder: (c, d) {
        final l = (d['team'] as List).cast<Map>();
        return ListView(padding: const EdgeInsets.all(16), children: [
          for (final e in l) Card(child: ListTile(
            title: Text('${e['name']}'), subtitle: Text('${e['emp_code']}   ${e['in_time'] ?? '--:--'} → ${e['out_time'] ?? '--:--'}'),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [if (e['is_late'] == true) const Pill('Late', Color(0xFFE8A200)), const SizedBox(width: 6), Pill('${e['status']}', statusColor('${e['status']}'))]))),
        ]);
      });
}

class AdminApprovals extends StatefulWidget {
  const AdminApprovals({super.key});
  @override
  State<AdminApprovals> createState() => _AdminApprovalsState();
}

class _AdminApprovalsState extends State<AdminApprovals> {
  final key = GlobalKey<LoaderState>();
  Future<void> decide(Map l, String decision) async {
    final remarks = TextEditingController();
    String pay = 'paid';
    final ok = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (_, set) => AlertDialog(
          title: Text('${decision == 'approved' ? 'Approve' : 'Reject'} ${l['employee']}?'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            if (decision == 'approved') DropdownButtonFormField<String>(value: pay, items: const [DropdownMenuItem(value: 'paid', child: Text('Paid leave')), DropdownMenuItem(value: 'unpaid', child: Text('Unpaid leave'))], onChanged: (v) => set(() => pay = v!)),
            TextField(controller: remarks, decoration: const InputDecoration(labelText: 'Remarks (optional)')),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Confirm'))])));
    if (ok != true) return;
    try {
      await Api.i.post('admin/leaves/decide', {'leave_id': l['id'], 'decision': decision, if (decision == 'approved') 'pay_type': pay, 'remarks': remarks.text});
      key.currentState?.reload();
    } on ApiError catch (e) { if (mounted) toast(context, e.message, err: true); }
  }

  @override
  Widget build(BuildContext context) => Loader(key: key, load: () => Api.i.get('admin/approvals'), builder: (c, d) {
        final l = (d['leaves'] as List).cast<Map>();
        return ListView(padding: const EdgeInsets.all(16), children: [
          if (l.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No pending leave requests 🎉'))),
          for (final x in l) Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${x['employee']} (${x['emp_code']})', style: const TextStyle(fontWeight: FontWeight.w700)),
            Text('${fd(x['from_date'])} → ${fd(x['to_date'])}  •  ${x['days']} day(s)'),
            Text('${x['reason'] ?? ''}'),
            Row(children: [
              TextButton(onPressed: () => decide(x, 'rejected'), child: const Text('Reject', style: TextStyle(color: Colors.red))),
              const Spacer(),
              FilledButton(style: FilledButton.styleFrom(minimumSize: const Size(110, 40)), onPressed: () => decide(x, 'approved'), child: const Text('Approve')),
            ]),
          ]))),
          if ((d['grievances_pending'] ?? 0) > 0) Card(child: ListTile(
              leading: const Icon(Icons.report_problem_outlined, color: evaOrange), title: Text('${d['grievances_pending']} grievance(s) need a reply'),
              trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const AdminGrievances())))),
        ]);
      });
}

class AdminGrievances extends StatefulWidget {
  const AdminGrievances({super.key});
  @override
  State<AdminGrievances> createState() => _AdminGrievancesState();
}

class _AdminGrievancesState extends State<AdminGrievances> {
  String status = 'all';
  final key = GlobalKey<LoaderState>();

  Future<void> reply(Map g) async {
    final remarks = TextEditingController(text: '${g['hr_reply'] ?? ''}');
    String st = g['status'] == 'pending' ? 'in_review' : '${g['status']}';
    final ok = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (_, set) => AlertDialog(
          title: Text('${g['subject']}'),
          content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${g['employee']} • ${g['category']}'), const SizedBox(height: 6), Text('${g['description']}'), const SizedBox(height: 10),
            DropdownButtonFormField<String>(value: st, items: const [for (final s in ['pending', 'in_review', 'resolved', 'rejected']) DropdownMenuItem(value: s, child: Text(s))], onChanged: (v) => set(() => st = v!)),
            TextField(controller: remarks, maxLines: 3, decoration: const InputDecoration(labelText: 'Reply to employee')),
          ])),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save'))])));
    if (ok != true) return;
    try {
      await Api.i.post('admin/grievances/update', {'grievance_id': g['id'], 'status': st, 'remarks': remarks.text});
      key.currentState?.reload();
    } on ApiError catch (e) { if (mounted) toast(context, e.message, err: true); }
  }

  @override
  Widget build(BuildContext context) => scaffoldPage('Grievances', Column(children: [
        SizedBox(height: 52, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.all(8), children: [
          for (final s in ['all', 'pending', 'in_review', 'resolved', 'rejected']) Padding(padding: const EdgeInsets.only(right: 6), child: ChoiceChip(
              label: Text(s), selected: status == s, onSelected: (_) => setState(() => status = s))),
        ])),
        Expanded(child: Loader(key: ValueKey(status), load: () => Api.i.get('admin/grievances', {'status': status}), builder: (c, d) {
          final l = (d['grievances'] as List).cast<Map>();
          if (l.isEmpty) return ListView(children: const [Padding(padding: EdgeInsets.all(40), child: Center(child: Text('Nothing here')))]);
          return ListView(padding: const EdgeInsets.symmetric(horizontal: 16), children: [
            for (final g in l) Card(child: ListTile(
              title: Text('${g['subject']}'), subtitle: Text('${g['employee']} • ${g['category']}${g['priority'] == 'urgent' ? ' • URGENT' : ''}'),
              trailing: Pill('${g['status']}', statusColor('${g['status']}')), onTap: () => reply(g))),
          ]);
        })),
      ]));
}

class AdminPayroll extends StatelessWidget {
  const AdminPayroll({super.key});
  @override
  Widget build(BuildContext context) => scaffoldPage('Payroll', Loader(load: () => Api.i.get('admin/payroll'), builder: (c, d) {
        final l = ((d['payroll'] ?? d['rows'] ?? []) as List).cast<Map>();
        if (l.isEmpty) return ListView(children: const [Padding(padding: EdgeInsets.all(40), child: Center(child: Text('No payroll for this month yet')))]);
        return ListView(padding: const EdgeInsets.all(16), children: [
          for (final p in l) Card(child: ListTile(title: Text('${p['name'] ?? p['employee'] ?? ''}'), subtitle: Text('${p['emp_code'] ?? ''}'),
              trailing: Text('₹${p['net_final'] ?? p['net_pay'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w700)))),
        ]);
      }));
}

class AdminEmployees extends StatefulWidget {
  const AdminEmployees({super.key});
  @override
  State<AdminEmployees> createState() => _AdminEmployeesState();
}

class _AdminEmployeesState extends State<AdminEmployees> {
  String q = '';
  @override
  Widget build(BuildContext context) => scaffoldPage('Employees', Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search name or code'), onSubmitted: (v) => setState(() => q = v))),
        Expanded(child: Loader(key: ValueKey(q), load: () => Api.i.get('admin/employees', {'q': q}), builder: (c, d) {
          final l = (d['employees'] as List).cast<Map>();
          return ListView(padding: const EdgeInsets.symmetric(horizontal: 16), children: [
            for (final e in l) Card(child: ListTile(title: Text('${e['name']}'), subtitle: Text('${e['emp_code']} • ${e['designation'] ?? ''}'),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => EmployeeDetail(id: '${e['id']}'))))),
          ]);
        })),
      ]));
}

class EmployeeDetail extends StatelessWidget {
  final String id;
  const EmployeeDetail({super.key, required this.id});
  @override
  Widget build(BuildContext context) => scaffoldPage('Employee', Loader(load: () => Api.i.get('admin/employee', {'id': id}), builder: (c, d) => ListView(padding: const EdgeInsets.all(16), children: [KV(d)])));
}
