import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';
import 'admin.dart';
import 'login.dart';
import 'staff.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final admin = Api.i.isAdmin;
    final pages = admin
        ? <Widget>[const AdminHome(), const AdminTeam(), const AdminApprovals(), const MoreScreen()]
        : <Widget>[const StaffHome(), const AttendanceScreen(), const LeavesScreen(), const MoreScreen()];
    final dests = admin
        ? const [
            NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.groups_outlined), label: 'Team'),
            NavigationDestination(icon: Icon(Icons.approval_outlined), label: 'Approvals'),
            NavigationDestination(icon: Icon(Icons.menu), label: 'More'),
          ]
        : const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Attendance'),
            NavigationDestination(icon: Icon(Icons.beach_access_outlined), label: 'Leaves'),
            NavigationDestination(icon: Icon(Icons.menu), label: 'More'),
          ];
    return Scaffold(
      appBar: AppBar(title: Text(Api.i.user?['company_name'] ?? 'VLEBAZAAR HRMS')),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, destinations: dests, onDestinationSelected: (i) => setState(() => tab = i)),
    );
  }
}

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final admin = Api.i.isAdmin;
    Widget tile(IconData i, String t, Widget page) => Card(
        child: ListTile(leading: Icon(i, color: evaOrange), title: Text(t), trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page))));
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: evaOrange, child: Icon(Icons.person, color: Colors.white)),
        title: Text(Api.i.user?['full_name'] ?? ''),
        subtitle: Text('${Api.i.user?['designation'] ?? Api.i.user?['role']}'))),
      if (!admin) ...[
        tile(Icons.fingerprint, 'Punch in / out', const PunchScreen()),
        tile(Icons.receipt_long_outlined, 'Payslips', const PayslipsScreen()),
        tile(Icons.report_problem_outlined, 'Grievances', const GrievancesScreen()),
        tile(Icons.badge_outlined, 'My profile', const ProfileScreen()),
        tile(Icons.privacy_tip_outlined, 'Location requests & privacy', const LocationScreen()),
      ] else ...[
        tile(Icons.report_problem_outlined, 'Grievances', const AdminGrievances()),
        tile(Icons.payments_outlined, 'Payroll', const AdminPayroll()),
        tile(Icons.people_alt_outlined, 'Employees', const AdminEmployees()),
      ],
      const SizedBox(height: 12),
      OutlinedButton.icon(
        icon: const Icon(Icons.logout), label: const Text('Sign out'),
        onPressed: () async {
          await Api.i.logout();
          if (context.mounted) {
            Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
          }
        }),
    ]);
  }
}
