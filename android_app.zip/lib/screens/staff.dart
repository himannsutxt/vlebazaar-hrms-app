import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import '../api.dart';
import '../theme.dart';

Widget scaffoldPage(String title, Widget body, {Widget? fab}) =>
    Scaffold(appBar: AppBar(title: Text(title)), body: body, floatingActionButton: fab);

class StaffHome extends StatelessWidget {
  const StaffHome({super.key});
  @override
  Widget build(BuildContext context) => Loader(
        load: () => Api.i.get('staff/home'),
        builder: (c, d) {
          final t = d['today'] ?? {};
          final m = Map<String, dynamic>.from(d['month_summary'] ?? {});
          final ann = (d['announcements'] as List?) ?? [];
          return ListView(padding: const EdgeInsets.all(16), children: [
            Text('Hello, ${d['employee']?['name'] ?? ''}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: evaDeep)),
            Text(fd(t['date'])),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
              Pill('${t['status'] ?? '-'}', statusColor('${t['status']}')),
              const Spacer(),
              Text('IN ${t['in_time'] ?? '--:--'}   OUT ${t['out_time'] ?? '--:--'}', style: const TextStyle(fontWeight: FontWeight.w600)),
            ]))),
            if (d['punch']?['allowed'] == true)
              FilledButton.icon(icon: const Icon(Icons.fingerprint), label: const Text('Punch in / out'),
                  onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const PunchScreen()))),
            const SizedBox(height: 8),
            const Text('This month', style: TextStyle(fontWeight: FontWeight.w700)),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final e in m.entries) Chip(label: Text('${e.key}: ${e.value}'), side: BorderSide(color: statusColor(e.key))),
            ]),
            if ((d['pending_leave_requests'] ?? 0) > 0)
              Card(child: ListTile(leading: const Icon(Icons.hourglass_bottom, color: evaOrange), title: Text('${d['pending_leave_requests']} leave request(s) pending'))),
            if ((d['pending_location_requests'] ?? 0) > 0)
              Card(child: ListTile(
                  leading: const Icon(Icons.location_on, color: evaOrange),
                  title: Text('${d['pending_location_requests']} location request(s) waiting'),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const LocationScreen())))),
            for (final a in ann)
              Card(child: ListTile(leading: const Icon(Icons.campaign_outlined, color: evaOrange),
                  title: Text('${a['title'] ?? ''}'), subtitle: Text('${a['body'] ?? a['message'] ?? ''}'))),
          ]);
        },
      );
}

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});
  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  late int month = DateTime.now().month, year = DateTime.now().year;
  final key = GlobalKey<LoaderState>();
  void shift(int d) {
    var m = month + d, y = year;
    if (m < 1) { m = 12; y--; }
    if (m > 12) { m = 1; y++; }
    setState(() { month = m; year = y; });
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => shift(-1)),
          Text('${fd('$year-${month.toString().padLeft(2, '0')}-01').substring(3)}', style: const TextStyle(fontWeight: FontWeight.w700)),
          IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => shift(1)),
        ]),
        Expanded(child: Loader(
          key: ValueKey('$month-$year'),
          load: () => Api.i.get('staff/attendance', {'month': '$month', 'year': '$year'}),
          builder: (c, d) {
            final rows = (d['rows'] as List).cast<Map>();
            return ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 16), itemCount: rows.length, itemBuilder: (_, i) {
              final r = rows[i];
              return Card(child: ListTile(
                leading: SizedBox(width: 44, child: Text('${r['date'].toString().substring(8)}\n${r['day']}', textAlign: TextAlign.center)),
                title: Row(children: [Pill('${r['status']}', statusColor('${r['status']}')), if (r['is_late'] == true) ...[const SizedBox(width: 6), const Pill('Late', Color(0xFFE8A200))]]),
                subtitle: Text('${r['in_time'] ?? '--:--'} → ${r['out_time'] ?? '--:--'}   ${r['worked_text'] ?? ''}'),
              ));
            });
          },
        )),
      ]);
}

class LeavesScreen extends StatelessWidget {
  const LeavesScreen({super.key});
  @override
  Widget build(BuildContext context) => LeavesBody();
}

class LeavesBody extends StatefulWidget {
  @override
  State<LeavesBody> createState() => _LeavesBodyState();
}

class _LeavesBodyState extends State<LeavesBody> {
  final key = GlobalKey<LoaderState>();
  @override
  Widget build(BuildContext context) => Stack(children: [
        Loader(key: key, load: () => Api.i.get('staff/leaves'), builder: (c, d) {
          final l = (d['leaves'] as List).cast<Map>();
          if (l.isEmpty) return ListView(children: const [Padding(padding: EdgeInsets.all(40), child: Center(child: Text('No leave requests yet')))]);
          return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), children: [
            for (final x in l) Card(child: ListTile(
              title: Text('${fd(x['from_date'])} → ${fd(x['to_date'])}  (${x['days']}d)'),
              subtitle: Text('${x['reason'] ?? ''}${x['admin_remarks'] != null ? '\nHR: ${x['admin_remarks']}' : ''}'),
              trailing: Pill('${x['status']}', statusColor('${x['status']}')),
              onLongPress: x['status'] == 'pending' ? () async {
                try { await Api.i.post('staff/leaves/cancel', {'leave_id': x['id']}); key.currentState?.reload(); } on ApiError catch (e) { if (c.mounted) toast(c, e.message, err: true); }
              } : null)),
            const Center(child: Padding(padding: EdgeInsets.all(8), child: Text('Long-press a pending request to cancel it', style: TextStyle(fontSize: 12)))),
          ]);
        }),
        Positioned(right: 16, bottom: 16, child: FloatingActionButton.extended(
          backgroundColor: evaOrange, foregroundColor: Colors.white,
          icon: const Icon(Icons.add), label: const Text('Apply'),
          onPressed: () async {
            final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const ApplyLeave()));
            if (ok == true) key.currentState?.reload();
          })),
      ]);
}

class ApplyLeave extends StatefulWidget {
  const ApplyLeave({super.key});
  @override
  State<ApplyLeave> createState() => _ApplyLeaveState();
}

class _ApplyLeaveState extends State<ApplyLeave> {
  DateTime from = DateTime.now(), to = DateTime.now();
  bool half = false, busy = false;
  final reason = TextEditingController();
  String iso(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  Future<void> pick(bool isFrom) async {
    final d = await showDatePicker(context: context, initialDate: isFrom ? from : to, firstDate: DateTime.now().subtract(const Duration(days: 60)), lastDate: DateTime.now().add(const Duration(days: 365)));
    if (d == null) return;
    setState(() { if (isFrom) { from = d; if (to.isBefore(d)) to = d; } else { to = d; } });
  }

  Future<void> submit() async {
    if (reason.text.trim().isEmpty) return toast(context, 'Please give a reason', err: true);
    setState(() => busy = true);
    try {
      await Api.i.post('staff/leaves', {'from_date': iso(from), 'to_date': iso(to), 'is_half_day': half, 'reason': reason.text.trim()});
      if (mounted) { toast(context, 'Leave request sent'); Navigator.pop(context, true); }
    } on ApiError catch (e) { if (mounted) toast(context, e.message, err: true); }
    finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => scaffoldPage('Apply for leave', ListView(padding: const EdgeInsets.all(16), children: [
        ListTile(title: const Text('From'), trailing: Text(fd(iso(from))), onTap: () => pick(true)),
        ListTile(title: const Text('To'), trailing: Text(fd(iso(to))), onTap: () => pick(false)),
        SwitchListTile(title: const Text('Half day'), value: half, onChanged: (v) => setState(() => half = v)),
        TextField(controller: reason, maxLines: 3, decoration: const InputDecoration(labelText: 'Reason')),
        const SizedBox(height: 16),
        FilledButton(onPressed: busy ? null : submit, child: const Text('Submit')),
      ]));
}

class PayslipsScreen extends StatelessWidget {
  const PayslipsScreen({super.key});
  @override
  Widget build(BuildContext context) => scaffoldPage('Payslips', Loader(load: () => Api.i.get('staff/payslips'), builder: (c, d) {
        final l = (d['payslips'] as List).cast<Map>();
        if (l.isEmpty) return ListView(children: const [Padding(padding: EdgeInsets.all(40), child: Center(child: Text('No payslips yet')))]);
        return ListView(padding: const EdgeInsets.all(16), children: [
          for (final p in l) Card(child: ListTile(
            title: Text('${p['month_name'] ?? p['month']}/${p['year']}'),
            trailing: Text('₹${p['net_final'] ?? p['net_pay'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w700)),
            onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => PayslipDetail(month: '${p['month']}', year: '${p['year']}'))))),
        ]);
      }));
}

class PayslipDetail extends StatelessWidget {
  final String month, year;
  const PayslipDetail({super.key, required this.month, required this.year});
  @override
  Widget build(BuildContext context) => scaffoldPage('Payslip $month/$year', Loader(
        load: () => Api.i.get('staff/payslip', {'month': month, 'year': year}),
        builder: (c, d) => ListView(padding: const EdgeInsets.all(16), children: [KV(d['payslip'] ?? d)])));
}

/// Renders any JSON map as a readable key/value card (nested maps/lists too).
class KV extends StatelessWidget {
  final dynamic data;
  const KV(this.data, {super.key});
  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    void walk(dynamic v, String prefix) {
      if (v is Map) {
        v.forEach((k, x) { if (k != 'ok') walk(x, prefix.isEmpty ? '$k' : '$prefix › $k'); });
      } else if (v is List) {
        for (var i = 0; i < v.length; i++) { walk(v[i], '$prefix #${i + 1}'); }
      } else if (v != null && '$v'.isNotEmpty) {
        rows.add(Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: 5, child: Text(prefix.replaceAll('_', ' '), style: const TextStyle(color: Colors.black54))),
          Expanded(flex: 4, child: Text('$v', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w600))),
        ])));
      }
    }
    walk(data, '');
    return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: rows)));
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => scaffoldPage('My profile', Loader(
        load: () => Api.i.get('staff/profile'),
        builder: (c, d) => ListView(padding: const EdgeInsets.all(16), children: [
          KV(d['profile']),
          if (d['can_self_edit'] != true) const Padding(padding: EdgeInsets.all(8), child: Text('To change details, contact HR.', style: TextStyle(fontSize: 12))),
        ])));
}

class PunchScreen extends StatefulWidget {
  const PunchScreen({super.key});
  @override
  State<PunchScreen> createState() => _PunchScreenState();
}

class _PunchScreenState extends State<PunchScreen> {
  final key = GlobalKey<LoaderState>();
  bool busy = false;

  Future<void> punch(Map cfg) async {
    setState(() => busy = true);
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        throw ApiError('Location permission is needed to punch.', 0);
      }
      final pos = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.best));
      String? selfie;
      if (cfg['selfie_required'] == true) {
        final x = await ImagePicker().pickImage(source: ImageSource.camera, preferredCameraDevice: CameraDevice.front, maxWidth: 800, imageQuality: 70);
        if (x == null) throw ApiError('Selfie is required to punch.', 0);
        selfie = base64Encode(await File(x.path).readAsBytes());
      }
      final r = await Api.i.post('staff/punch', {'type': cfg['next_type'], 'lat': pos.latitude, 'lng': pos.longitude, 'accuracy': pos.accuracy, if (selfie != null) 'selfie_base64': selfie});
      if (mounted) toast(context, r['message']?.toString() ?? 'Punched ${cfg['next_type']}');
      key.currentState?.reload();
    } on ApiError catch (e) {
      if (!mounted) return;
      if (e.code == 'consent_required') {
        final yes = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
          title: const Text('Location consent'),
          content: const Text('Your location is read only at the moment you punch, or when HR sends a visible request. You can withdraw consent any time.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('No')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('I agree'))]));
        if (yes == true) { await Api.i.post('consent/location', {'accept': true}); key.currentState?.reload(); }
      } else {
        toast(context, e.message, err: true);
      }
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => scaffoldPage('Punch', Loader(key: key, load: () => Api.i.get('staff/punch'), builder: (c, d) {
        final today = (d['today'] as List?) ?? [];
        final nxt = '${d['next_type']}'.toUpperCase();
        return ListView(padding: const EdgeInsets.all(16), children: [
          if (d['allowed'] != true) const Card(child: ListTile(leading: Icon(Icons.block, color: Colors.red), title: Text('Punching from the app is not enabled for you. Contact HR.'))),
          if (d['office_configured'] != true) const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('Office location is not set up yet.'))),
          FilledButton.icon(
            icon: const Icon(Icons.fingerprint), label: Text('Punch $nxt'),
            onPressed: busy || d['allowed'] != true ? null : () => punch(d)),
          const SizedBox(height: 12),
          const Text("Today's punches", style: TextStyle(fontWeight: FontWeight.w700)),
          if (today.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('None yet')),
          for (final p in today) Card(child: ListTile(title: Text('${p['type'] ?? p['punch_type'] ?? ''}'.toUpperCase()), subtitle: Text('${p['time'] ?? p['punched_at'] ?? ''}'))),
          Text('Allowed radius: ${d['radius_m']} m • GPS accuracy must be 100 m or better', style: const TextStyle(fontSize: 12)),
        ]);
      }));
}

class GrievancesScreen extends StatefulWidget {
  const GrievancesScreen({super.key});
  @override
  State<GrievancesScreen> createState() => _GrievancesScreenState();
}

class _GrievancesScreenState extends State<GrievancesScreen> {
  final key = GlobalKey<LoaderState>();
  List cats = [];
  @override
  Widget build(BuildContext context) => scaffoldPage('Grievances', Loader(key: key, load: () async {
        final d = await Api.i.get('staff/grievances');
        cats = d['categories'] as List;
        return d;
      }, builder: (c, d) {
        final l = (d['grievances'] as List).cast<Map>();
        if (l.isEmpty) return ListView(children: const [Padding(padding: EdgeInsets.all(40), child: Center(child: Text('No grievances raised')))]);
        return ListView(padding: const EdgeInsets.all(16), children: [
          for (final g in l) Card(child: ExpansionTile(
            title: Text('${g['subject']}'),
            subtitle: Text('${g['category']} • ${fd((g['submitted_at'] ?? '').toString().split(' ').first)}'),
            trailing: Pill('${g['status']}', statusColor('${g['status']}')),
            childrenPadding: const EdgeInsets.all(14),
            expandedAlignment: Alignment.centerLeft,
            children: [
              Text('${g['description']}'),
              const SizedBox(height: 8),
              Text('Submitted: ${g['submitted_at'] ?? '–'}'),
              if (g['in_review_at'] != null) Text('In review: ${g['in_review_at']}'),
              if (g['resolved_at'] != null) Text('Closed: ${g['resolved_at']}'),
              if ((g['hr_reply'] ?? '').toString().isNotEmpty) Container(
                margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(10), width: double.infinity,
                decoration: BoxDecoration(color: const Color(0xFFFFF0E6), borderRadius: BorderRadius.circular(10)),
                child: Text('HR reply: ${g['hr_reply']}')),
            ])),
        ]);
      }), fab: FloatingActionButton.extended(
        backgroundColor: evaOrange, foregroundColor: Colors.white,
        icon: const Icon(Icons.add), label: const Text('Raise'),
        onPressed: () async {
          final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => NewGrievance(cats: cats.isEmpty ? ['Other'] : cats)));
          if (ok == true) key.currentState?.reload();
        }));
}

class NewGrievance extends StatefulWidget {
  final List cats;
  const NewGrievance({super.key, required this.cats});
  @override
  State<NewGrievance> createState() => _NewGrievanceState();
}

class _NewGrievanceState extends State<NewGrievance> {
  late String cat = '${widget.cats.first}';
  String prio = 'normal';
  final sub = TextEditingController(), desc = TextEditingController();
  bool busy = false;
  Future<void> submit() async {
    if (sub.text.trim().isEmpty || desc.text.trim().isEmpty) return toast(context, 'Subject and details are required', err: true);
    setState(() => busy = true);
    try {
      await Api.i.post('staff/grievances', {'category': cat, 'priority': prio, 'subject': sub.text.trim(), 'description': desc.text.trim()});
      if (mounted) { toast(context, 'Sent to HR'); Navigator.pop(context, true); }
    } on ApiError catch (e) { if (mounted) toast(context, e.message, err: true); }
    finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => scaffoldPage('Raise a grievance', ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(value: cat, decoration: const InputDecoration(labelText: 'Category'),
            items: [for (final c in widget.cats) DropdownMenuItem(value: '$c', child: Text('$c'))], onChanged: (v) => setState(() => cat = v!)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: prio, decoration: const InputDecoration(labelText: 'Priority'),
            items: const [for (final p in ['normal', 'high', 'urgent']) DropdownMenuItem(value: p, child: Text(p))], onChanged: (v) => setState(() => prio = v!)),
        const SizedBox(height: 12),
        TextField(controller: sub, decoration: const InputDecoration(labelText: 'Subject')),
        const SizedBox(height: 12),
        TextField(controller: desc, maxLines: 6, decoration: const InputDecoration(labelText: 'Details')),
        const SizedBox(height: 16),
        FilledButton(onPressed: busy ? null : submit, child: const Text('Submit')),
      ]));
}

class LocationScreen extends StatefulWidget {
  const LocationScreen({super.key});
  @override
  State<LocationScreen> createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  final key = GlobalKey<LoaderState>();
  Future<void> respond(Map r, bool decline) async {
    try {
      if (decline) {
        await Api.i.post('staff/location/respond', {'request_id': r['id'] ?? r['request_id'], 'decline': true});
      } else {
        final p = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.best));
        await Api.i.post('staff/location/respond', {'request_id': r['id'] ?? r['request_id'], 'lat': p.latitude, 'lng': p.longitude, 'accuracy': p.accuracy});
      }
      key.currentState?.reload();
    } on ApiError catch (e) { if (mounted) toast(context, e.message, err: true); }
  }

  @override
  Widget build(BuildContext context) => scaffoldPage('Location & privacy', Loader(key: key, load: () async {
        final p = await Api.i.get('staff/location/pending');
        final h = await Api.i.get('staff/location/history');
        return {'pending': p, 'history': h};
      }, builder: (c, d) {
        final pend = ((d['pending']['requests'] ?? d['pending']['pending'] ?? []) as List).cast<Map>();
        final hist = ((d['history']['history'] ?? d['history']['requests'] ?? []) as List).cast<Map>();
        return ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Nobody can track you secretly. HR can only send a visible request that you may accept or decline.'),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () async { await Api.i.post('consent/location', {'accept': true}); if (c.mounted) toast(c, 'Consent saved'); }, child: const Text('Give consent'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(onPressed: () async { await Api.i.post('consent/location', {'accept': false}); if (c.mounted) toast(c, 'Consent withdrawn'); }, child: const Text('Withdraw'))),
          ]),
          const SizedBox(height: 12),
          const Text('Pending requests', style: TextStyle(fontWeight: FontWeight.w700)),
          if (pend.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('None')),
          for (final r in pend) Card(child: ListTile(title: Text('${r['requested_by'] ?? r['admin'] ?? 'HR'} asked for your location'), subtitle: Row(children: [
            TextButton(onPressed: () => respond(r, false), child: const Text('Share now')),
            TextButton(onPressed: () => respond(r, true), child: const Text('Decline')),
          ]))),
          const SizedBox(height: 12),
          const Text('History', style: TextStyle(fontWeight: FontWeight.w700)),
          for (final r in hist) Card(child: ListTile(title: Text('${r['requested_by'] ?? r['admin'] ?? ''}'), subtitle: Text('${r['status'] ?? ''} • ${r['created_at'] ?? r['requested_at'] ?? ''}'))),
        ]);
      }));
}
