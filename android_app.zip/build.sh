#!/usr/bin/env bash
# Local build (needs Flutter SDK + Android SDK). Same steps as the CI workflow.
set -e
flutter create --platforms=android --org com.vlebazaar --project-name vlebazaar_hrms .
M=android/app/src/main/AndroidManifest.xml
sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>\n    <uses-permission android:name="android.permission.CAMERA"/>\n    <application#' $M
sed -i 's#android:label="[^"]*"#android:label="VLEBAZAAR HRMS"#' $M
sed -i 's/minSdk = .*/minSdk = 23/; s/minSdkVersion .*/minSdkVersion 23/' android/app/build.gradle* || true
flutter pub get
flutter analyze --no-fatal-infos
flutter build apk --release
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
