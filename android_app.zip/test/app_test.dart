import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vlebazaar_hrms/theme.dart';
import 'package:vlebazaar_hrms/api.dart';
import 'package:vlebazaar_hrms/screens/staff.dart' show KV;

void main() {
  test('fd formats like the website (d-M-Y)', () {
    expect(fd('2026-11-15'), '15-Nov-2026');
    expect(fd(null), '–');
    expect(fd('x'), 'x');
  });
  test('status colours are distinct for P and A', () {
    expect(statusColor('P'), isNot(statusColor('A')));
  });
  test('ApiError carries message', () {
    expect(ApiError('boom', 500).toString(), 'boom');
  });
  testWidgets('KV renders nested data and hides empty/ok', (t) async {
    await t.pumpWidget(const MaterialApp(home: Scaffold(body: KV({'ok': true, 'a': {'b_c': 5}, 'e': ''}))));
    expect(find.text('a › b c'), findsOneWidget);
    expect(find.text('5'), findsOneWidget);
    expect(find.text('ok'), findsNothing);
  });
}
