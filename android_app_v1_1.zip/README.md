# VLEBAZAAR HRMS — Android app (Flutter)

Staff: home, attendance, leaves (apply/cancel), punch in/out (GPS + selfie + consent), payslips,
grievances (raise + HR reply timeline), profile, location-request transparency screen.
Admin: dashboard, team today, leave approvals, grievance replies, payroll, employees.

Talks only to the PHP API in `../api` (see `../API.md`). Default server: `https://texvns.com/ems/api/index.php`
(changeable on the login screen → *Server settings*).

## Build
* GitHub: push this folder to a repo → Actions → **Build Android APK** → download the artifact.
* Local: install Flutter + Android SDK, run `./build.sh`.

## Not included yet
Firebase push (add `google-services.json` + `firebase_messaging`; server side is ready), biometric unlock, offline cache.
