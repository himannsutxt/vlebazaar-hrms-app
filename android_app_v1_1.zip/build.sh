#!/usr/bin/env bash
# Builds the release APK (needs Flutter SDK + Android SDK). Same steps as CI.
set -e
flutter create --platforms=android --org com.vlebazaar --project-name vlebazaar_hrms .
rm -f test/widget_test.dart
M=android/app/src/main/AndroidManifest.xml
grep -q ACCESS_FINE_LOCATION $M || sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>\n    <uses-permission android:name="android.permission.CAMERA"/>\n    <application#' $M
sed -i 's#android:label="[^"]*"#android:label="VleBazaar EMS"#' $M
sed -i 's/minSdk = .*/minSdk = 23/; s/minSdkVersion .*/minSdkVersion 23/' android/app/build.gradle* || true
# launcher icon (VleBazaar EMS)
for d in icons/mipmap-*; do mkdir -p "android/app/src/main/res/$(basename $d)"; cp "$d/ic_launcher.png" "android/app/src/main/res/$(basename $d)/ic_launcher.png"; done
rm -rf android/app/src/main/res/mipmap-anydpi-v26
# native launch background = splash colour (no white flash before the splash image)
mkdir -p android/app/src/main/res/values
printf '<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="splash_bg">#DCE6FE</color></resources>\n' > android/app/src/main/res/values/splash_colors.xml
for f in android/app/src/main/res/drawable*/launch_background.xml; do sed -i 's#@android:color/white#@color/splash_bg#; s#?android:colorBackground#@color/splash_bg#' "$f"; done
# Android release-lint crashes inside some plugins (image_picker) on new AGP; it only lints, so skip it
for g in android/build.gradle.kts android/build.gradle; do [ -f "$g" ] && ! grep -q lintVital "$g" && printf '\nsubprojects {\n    tasks.matching { it.name.contains("lintVital") }.configureEach { enabled = false }\n}\n' >> "$g"; done
flutter pub get
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter test
flutter build apk --release
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
