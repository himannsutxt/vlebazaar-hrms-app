import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';

/* ------------------------------------------------------------------ colours */

const evaOrange = Color(0xFFF0660D);
const evaPeach = Color(0xFFE0926B);
const evaPage = Color(0xFFFFF5F5);
const evaDeep = Color(0xFF9A3B12);
const evaBorder = Color(0xFFF1DCD3);
const evaInk = Color(0xFF2B1B14);
const evaMuted = Color(0xFF7A6259);
const okGreen = Color(0xFF1E8E3E);
const badRed = Color(0xFFD93025);
const warnAmber = Color(0xFFE8A200);
const infoBlue = Color(0xFF1A73E8);

ThemeData evaTheme() => ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: evaOrange, primary: evaOrange),
      scaffoldBackgroundColor: Colors.transparent,
      appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          foregroundColor: evaInk,
          elevation: 0,
          scrolledUnderElevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: evaInk)),
      cardTheme: CardThemeData(
          color: Colors.white.withAlpha(170),
          elevation: 0,
          margin: const EdgeInsets.symmetric(vertical: 5),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18), side: BorderSide(color: Colors.white.withAlpha(200)))),
      filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
              backgroundColor: evaOrange,
              minimumSize: const Size.fromHeight(48),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
      outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
              foregroundColor: evaDeep,
              side: const BorderSide(color: evaBorder),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
      inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white.withAlpha(200),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: evaBorder)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: evaBorder))),
      chipTheme: ChipThemeData(
          backgroundColor: Colors.white.withAlpha(170),
          selectedColor: const Color(0xFFFFDCC8),
          side: const BorderSide(color: evaBorder),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white.withAlpha(215),
          indicatorColor: const Color(0xFFFFDCC8),
          labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
      tooltipTheme: const TooltipThemeData(waitDuration: Duration(milliseconds: 300)),
    );

/* ------------------------------------------------------------ glass pieces */

/// Soft blurred "room" behind every screen — the website's Dashboard C look.
class GlassBackground extends StatelessWidget {
  final Widget child;
  const GlassBackground({super.key, required this.child});

  Widget _blob(Color c, double size) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: c),
      );

  @override
  Widget build(BuildContext context) => Stack(children: [
        Positioned.fill(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFFFFF4EC), Color(0xFFFDE6DA), Color(0xFFEFEAFB)],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: ImageFiltered(
            imageFilter: ui.ImageFilter.blur(sigmaX: 60, sigmaY: 60),
            child: Stack(children: [
              Positioned(top: -60, left: -40, child: _blob(const Color(0xFFFFB27A), 260)),
              Positioned(top: 220, right: -80, child: _blob(const Color(0xFFF7C6E0), 240)),
              Positioned(bottom: -40, left: 30, child: _blob(const Color(0xFFC9D6FF), 260)),
            ]),
          ),
        ),
        Positioned.fill(child: child),
      ]);
}

/// Frosted card.
class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final VoidCallback? onTap;
  final Color? tint;
  const Glass({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.radius = 20, this.onTap, this.tint});

  @override
  Widget build(BuildContext context) {
    final box = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: (tint ?? Colors.white).withAlpha(tint == null ? 150 : 60),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: Colors.white.withAlpha(210)),
          ),
          child: child,
        ),
      ),
    );
    if (onTap == null) return Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: box);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(radius),
        child: InkWell(borderRadius: BorderRadius.circular(radius), onTap: onTap, child: box),
      ),
    );
  }
}

/// Standard page: glass background + transparent app bar.
class GlassPage extends StatelessWidget {
  final String title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? fab;
  final Widget? bottom;
  const GlassPage({super.key, required this.title, required this.body, this.actions, this.fab, this.bottom});

  @override
  Widget build(BuildContext context) => GlassBackground(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(title: Text(title), actions: actions),
          body: body,
          floatingActionButton: fab,
          bottomNavigationBar: bottom,
        ),
      );
}

class KpiTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final String tip;
  final VoidCallback? onTap;
  const KpiTile({super.key, required this.label, required this.value, required this.icon, this.color = evaOrange, required this.tip, this.onTap});

  @override
  Widget build(BuildContext context) => Tooltip(
        message: tip,
        child: Glass(
          onTap: onTap,
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: color.withAlpha(36), borderRadius: BorderRadius.circular(10)),
                child: Icon(icon, size: 18, color: color),
              ),
              const Spacer(),
              if (onTap != null) Icon(Icons.chevron_right, size: 18, color: evaMuted.withAlpha(160)),
            ]),
            const SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color)),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: evaMuted)),
          ]),
        ),
      );
}

/// 2-column (3 on wide screens) grid of tiles that sizes itself.
class TileGrid extends StatelessWidget {
  final List<Widget> children;
  const TileGrid({super.key, required this.children});
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (c, box) {
        final cols = box.maxWidth > 700 ? 4 : (box.maxWidth > 460 ? 3 : 2);
        final w = (box.maxWidth - (cols - 1) * 10) / cols;
        return Wrap(spacing: 10, children: [for (final ch in children) SizedBox(width: w, child: ch)]);
      });
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  final String? tip;
  const SectionTitle(this.text, {super.key, this.trailing, this.tip});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 14, 2, 4),
        child: Row(children: [
          Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: evaInk)),
          if (tip != null) ...[const SizedBox(width: 4), InfoTip(tip!)],
          const Spacer(),
          if (trailing != null) trailing!,
        ]),
      );
}

class InfoTip extends StatelessWidget {
  final String message;
  const InfoTip(this.message, {super.key});
  @override
  Widget build(BuildContext context) => Tooltip(
        message: message,
        triggerMode: TooltipTriggerMode.tap,
        showDuration: const Duration(seconds: 4),
        child: const Icon(Icons.info_outline, size: 16, color: evaMuted),
      );
}

class Pill extends StatelessWidget {
  final String text;
  final Color color;
  const Pill(this.text, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(color: color.withAlpha(32), borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12)),
      );
}

class StatusPill extends StatelessWidget {
  final String status;
  const StatusPill(this.status, {super.key});
  @override
  Widget build(BuildContext context) => Pill(statusLabel(status), statusColor(status));
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String text;
  const EmptyState(this.text, {super.key, this.icon = Icons.inbox_outlined});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
        child: Column(children: [
          Icon(icon, size: 44, color: evaMuted.withAlpha(140)),
          const SizedBox(height: 10),
          Text(text, textAlign: TextAlign.center, style: const TextStyle(color: evaMuted)),
        ]),
      );
}

/// Label / value row used in detail cards.
class KVRow extends StatelessWidget {
  final String k;
  final String? v;
  final bool bold;
  const KVRow(this.k, this.v, {super.key, this.bold = false});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: 5, child: Text(k, style: const TextStyle(color: evaMuted))),
          Expanded(
              flex: 6,
              child: SelectableText((v == null || v!.isEmpty) ? '–' : v!,
                  textAlign: TextAlign.right, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w600, color: evaInk))),
        ]),
      );
}

/// Simple vertical bar chart (no package): values with labels underneath.
class MiniBars extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final Color color;
  final double height;
  final String Function(double)? valueText;
  const MiniBars({super.key, required this.values, required this.labels, this.color = evaOrange, this.height = 110, this.valueText});
  @override
  Widget build(BuildContext context) {
    final mx = values.isEmpty ? 1.0 : values.reduce((a, b) => a > b ? a : b);
    final top = mx <= 0 ? 1.0 : mx;
    return SizedBox(
      height: height + 34,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        for (var i = 0; i < values.length; i++)
          Expanded(
            child: Tooltip(
              message: '${labels[i]}: ${valueText != null ? valueText!(values[i]) : values[i].toStringAsFixed(0)}',
              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                if (values.length <= 8)
                  Text(valueText != null ? valueText!(values[i]) : values[i].toStringAsFixed(0),
                      style: const TextStyle(fontSize: 9, color: evaMuted), maxLines: 1),
                Container(
                  height: (values[i] / top * height).clamp(2, height).toDouble(),
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [color, color.withAlpha(140)]),
                  ),
                ),
                const SizedBox(height: 4),
                Text(labels[i], style: const TextStyle(fontSize: 9, color: evaMuted), maxLines: 1, overflow: TextOverflow.clip),
              ]),
            ),
          ),
      ]),
    );
  }
}

/// Search box + filter chips + sort menu, used on every list.
class ListControls extends StatelessWidget {
  final String? searchHint;
  final ValueChanged<String>? onSearch;
  final List<String> filters;
  final String? selected;
  final ValueChanged<String>? onFilter;
  final Map<String, String> sorts;
  final String? sort;
  final ValueChanged<String>? onSort;
  final VoidCallback? onExport;
  final String Function(String)? filterLabel;
  const ListControls({
    super.key,
    this.searchHint,
    this.onSearch,
    this.filters = const [],
    this.selected,
    this.onFilter,
    this.sorts = const {},
    this.sort,
    this.onSort,
    this.onExport,
    this.filterLabel,
  });

  @override
  Widget build(BuildContext context) => Column(children: [
        if (onSearch != null || sorts.isNotEmpty || onExport != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 2),
            child: Row(children: [
              if (onSearch != null)
                Expanded(
                  child: Tooltip(
                    message: 'Type and press search to filter the list',
                    child: TextField(
                      textInputAction: TextInputAction.search,
                      onSubmitted: onSearch,
                      onChanged: (v) {
                        if (v.isEmpty) onSearch!('');
                      },
                      decoration: InputDecoration(
                          isDense: true, prefixIcon: const Icon(Icons.search), hintText: searchHint ?? 'Search'),
                    ),
                  ),
                )
              else
                const Spacer(),
              if (sorts.isNotEmpty)
                PopupMenuButton<String>(
                  tooltip: 'Sort the list',
                  icon: const Icon(Icons.sort),
                  initialValue: sort,
                  onSelected: onSort,
                  itemBuilder: (_) => [for (final e in sorts.entries) PopupMenuItem(value: e.key, child: Text(e.value))],
                ),
              if (onExport != null)
                IconButton(tooltip: 'Export this list as a CSV file (opens in Excel/Sheets)', icon: const Icon(Icons.file_download_outlined), onPressed: onExport),
            ]),
          ),
        if (filters.isNotEmpty)
          SizedBox(
            height: 48,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), children: [
              for (final f in filters)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(
                    label: Text(filterLabel != null ? filterLabel!(f) : statusLabel(f)),
                    selected: selected == f,
                    onSelected: (_) => onFilter?.call(f),
                    tooltip: 'Show ${filterLabel != null ? filterLabel!(f) : statusLabel(f)}',
                  ),
                ),
            ]),
          ),
      ]);
}

/* ----------------------------------------------------------- formatting */

String statusLabel(String s) {
  const m = {
    'P': 'Present', 'A': 'Absent', 'HD': 'Half day', 'WO': 'Week off', 'H': 'Holiday', 'L': 'Leave', 'UL': 'Unpaid leave',
    'PENDING': 'Upcoming', 'pending': 'Pending', 'approved': 'Approved', 'rejected': 'Rejected', 'cancelled': 'Cancelled',
    'in_review': 'In review', 'resolved': 'Resolved', 'closed': 'Closed', 'paid': 'Paid', 'unpaid': 'Unpaid', 'issued': 'Issued',
    'in_progress': 'In progress', 'all': 'All', 'finalized': 'Finalized', 'draft': 'Draft', 'assigned': 'Assigned', 'in_repair': 'In repair',
    'active': 'Active', 'inactive': 'Inactive', 'urgent': 'Urgent', 'high': 'High', 'normal': 'Normal',
  };
  return m[s] ?? (s.isEmpty ? '–' : s[0].toUpperCase() + s.substring(1).replaceAll('_', ' '));
}

Color statusColor(String s) {
  switch (s) {
    case 'P': case 'approved': case 'resolved': case 'paid': case 'issued': case 'active': case 'assigned':
      return okGreen;
    case 'A': case 'rejected': case 'UL': case 'urgent': case 'unpaid':
      return badRed;
    case 'HD': case 'in_review': case 'in_progress': case 'high': case 'in_repair':
      return warnAmber;
    case 'L': case 'pending':
      return infoBlue;
    default:
      return const Color(0xFF80868B);
  }
}

void toast(BuildContext c, String m, {bool err = false}) => ScaffoldMessenger.of(c)
    .showSnackBar(SnackBar(content: Text(m), backgroundColor: err ? badRed : evaDeep, behavior: SnackBarBehavior.floating));

const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
String monthShort(int m) => _months[(m - 1).clamp(0, 11)];
const _monthsLong = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
String monthLong(int m) => _monthsLong[(m - 1).clamp(0, 11)];

/// "2026-11-15" -> "15-Nov-2026" (the website's d-M-Y).
String fd(dynamic d) {
  final s = d?.toString() ?? '';
  if (s.length < 10) return s.isEmpty ? '–' : s;
  final mm = int.tryParse(s.substring(5, 7)) ?? 1;
  return '${s.substring(8, 10)}-${monthShort(mm)}-${s.substring(0, 4)}';
}

/// "2026-11-15 14:05:00" -> "15-Nov-2026 02:05 PM"
String fdt(dynamic d) {
  final s = d?.toString() ?? '';
  if (s.length < 16) return fd(s);
  var h = int.tryParse(s.substring(11, 13)) ?? 0;
  final mi = s.substring(14, 16);
  final ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12 == 0 ? 12 : h % 12;
  return '${fd(s)} ${h.toString().padLeft(2, '0')}:$mi $ap';
}

double toD(dynamic v) => v is num ? v.toDouble() : (double.tryParse('${v ?? ''}') ?? 0);

/// ₹ with Indian digit grouping: 1234567.5 -> ₹12,34,567.50 (decimals only when needed).
String inr(dynamic v, {bool decimals = false}) {
  if (v == null) return '–';
  final n = toD(v);
  final neg = n < 0;
  final fixed = n.abs().toStringAsFixed(2);
  final parts = fixed.split('.');
  var w = parts[0];
  var out = '';
  if (w.length > 3) {
    out = ',${w.substring(w.length - 3)}';
    w = w.substring(0, w.length - 3);
    while (w.length > 2) {
      out = ',${w.substring(w.length - 2)}$out';
      w = w.substring(0, w.length - 2);
    }
    out = w + out;
  } else {
    out = w;
  }
  final dec = (decimals || parts[1] != '00') ? '.${parts[1]}' : '';
  return '${neg ? '-' : ''}₹$out$dec';
}

String num1(dynamic v) {
  final d = toD(v);
  return d == d.roundToDouble() ? d.toStringAsFixed(0) : d.toStringAsFixed(1);
}

String isoDate(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/* ------------------------------------------------------- files: csv / open */

String _csvCell(dynamic v) {
  var s = v?.toString() ?? '';
  // formula-injection safe (same rule as the website's csv_put)
  if (s.isNotEmpty && '=+-@\t\r'.contains(s[0])) s = "'$s";
  if (s.contains(',') || s.contains('"') || s.contains('\n')) s = '"${s.replaceAll('"', '""')}"';
  return s;
}

Future<void> exportCsv(BuildContext context, String name, List<String> header, List<List<dynamic>> rows) async {
  try {
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/${name.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_')}.csv');
    final b = StringBuffer('﻿');
    b.writeln(header.map(_csvCell).join(','));
    for (final r in rows) {
      b.writeln(r.map(_csvCell).join(','));
    }
    await f.writeAsString(b.toString());
    final res = await OpenFilex.open(f.path, type: 'text/csv');
    if (res.type != ResultType.done && context.mounted) {
      toast(context, 'Saved ${f.path.split('/').last}. Install Excel or Google Sheets to open CSV files.');
    }
  } catch (e) {
    if (context.mounted) toast(context, 'Could not create the file: $e', err: true);
  }
}

Future<void> openBytes(BuildContext context, List<int> bytes, String fileName) async {
  try {
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/${fileName.replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_')}');
    await f.writeAsBytes(bytes, flush: true);
    final res = await OpenFilex.open(f.path);
    if (res.type != ResultType.done && context.mounted) {
      toast(context, 'No app on this phone can open this file type.', err: true);
    }
  } catch (e) {
    if (context.mounted) toast(context, 'Could not open the file: $e', err: true);
  }
}

/* ----------------------------------------------------------- data loader */

/// Loads data, shows spinner/error/retry, supports pull-to-refresh.
class Loader extends StatefulWidget {
  final Future<Map<String, dynamic>> Function() load;
  final Widget Function(BuildContext, Map<String, dynamic>) builder;
  const Loader({super.key, required this.load, required this.builder});
  @override
  State<Loader> createState() => LoaderState();
}

class LoaderState extends State<Loader> {
  late Future<Map<String, dynamic>> f = widget.load();
  void reload() => setState(() => f = widget.load());

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator(color: evaOrange));
          }
          if (s.hasError) {
            final msg = '${s.error}';
            final serverOld = msg.contains('Unknown endpoint');
            return ListView(padding: const EdgeInsets.all(24), children: [
              const SizedBox(height: 60),
              Icon(serverOld ? Icons.system_update_alt : Icons.cloud_off, size: 46, color: evaMuted),
              const SizedBox(height: 12),
              Text(
                serverOld
                    ? 'This feature needs the latest server update.\nAsk your admin to upload the newest HRMS files to the website.'
                    : msg,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: reload, child: const Text('Retry')),
            ]);
          }
          return RefreshIndicator(
            color: evaOrange,
            onRefresh: () async {
              reload();
              try {
                await f;
              } catch (_) {}
            },
            child: widget.builder(c, s.data!),
          );
        },
      );
}

/// Month / year picker row used by attendance, payroll, reports, team leave.
class MonthBar extends StatelessWidget {
  final int month;
  final int year;
  final void Function(int month, int year) onChanged;
  const MonthBar({super.key, required this.month, required this.year, required this.onChanged});
  void _shift(int d) {
    var m = month + d, y = year;
    if (m < 1) {
      m = 12;
      y--;
    }
    if (m > 12) {
      m = 1;
      y++;
    }
    onChanged(m, y);
  }

  @override
  Widget build(BuildContext context) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(tooltip: 'Previous month', icon: const Icon(Icons.chevron_left), onPressed: () => _shift(-1)),
        Text('${monthLong(month)} $year', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        IconButton(tooltip: 'Next month', icon: const Icon(Icons.chevron_right), onPressed: () => _shift(1)),
      ]);
}

/// Bottom sheet with a text field; returns the text or null when cancelled.
Future<String?> askText(BuildContext context, String title, {String hint = '', String initial = '', bool required = false, String ok = 'Save'}) async {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, maxLines: 3, minLines: 1, decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        TextButton(
            onPressed: () {
              if (required && c.text.trim().isEmpty) return;
              Navigator.pop(context, c.text.trim());
            },
            child: Text(ok)),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext context, String title, String body, {String ok = 'Yes'}) async =>
    (await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(title: Text(title), content: Text(body), actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: Text(ok)),
      ]),
    )) ??
    false;
