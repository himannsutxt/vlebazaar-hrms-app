import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';
import 'staff.dart';

/* =================================================== MONEY (tab body) */

class MoneyHub extends StatelessWidget {
  const MoneyHub({super.key});
  @override
  Widget build(BuildContext context) => Loader(
        load: () async {
          final a = await Api.i.get('staff/advances');
          Map<String, dynamic> p = {'payslips': []};
          try {
            p = await Api.i.get('staff/payslips');
          } catch (_) {}
          return {'adv': a, 'pay': p};
        },
        builder: (c, d) {
          final slips = (d['pay']['payslips'] as List).cast<Map>();
          final adv = d['adv'];
          final last = slips.isNotEmpty ? slips.first : null;
          final pendingAdv = [...(adv['salary_advances'] as List), ...(adv['purchase_advances'] as List)].where((x) => x['status'] == 'pending').length;
          final pendingExp = (adv['expenses'] as List).where((x) => x['status'] == 'pending' || x['status'] == 'approved').length;
          Widget row(IconData i, String t, String sub, String tip, Widget page) => Tooltip(
                message: tip,
                child: Glass(
                  onTap: () => push(c, page),
                  child: Row(children: [
                    Icon(i, color: evaOrange),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(t, style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text(sub, style: const TextStyle(color: evaMuted, fontSize: 12)),
                    ])),
                    const Icon(Icons.chevron_right),
                  ]),
                ),
              );
          return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
            TileGrid(children: [
              KpiTile(
                  label: last != null ? 'Net pay · ${monthShort(last['month'] as int)} ${last['year']}' : 'No payslip yet',
                  value: last != null ? inr(last['net_final']) : '–',
                  icon: Icons.account_balance_wallet_outlined,
                  color: okGreen,
                  tip: 'Your latest finalized payslip',
                  onTap: last == null ? null : () => push(c, PayslipDetail(month: last['month'] as int, year: last['year'] as int))),
              KpiTile(
                  label: 'Advance outstanding',
                  value: inr(adv['outstanding']),
                  icon: Icons.trending_down,
                  color: toD(adv['outstanding']) > 0 ? badRed : okGreen,
                  tip: 'Salary advance still to be recovered from your pay',
                  onTap: () => push(c, const AdvancesScreen())),
            ]),
            const SectionTitle('Salary'),
            row(Icons.receipt_long, 'Payslips', '${slips.length} finalized month(s)', 'Open a month to see the full breakup', const PayslipsScreen()),
            row(Icons.calculate_outlined, 'How my salary is calculated', 'This month, day by day', 'Live estimate from your attendance and shift rules',
                const SalaryDetailsScreen()),
            row(Icons.summarize_outlined, 'Yearly statement', 'Net pay and advance recovered per month', 'Salary and advance statement for a year',
                const StatementScreen()),
            const SectionTitle('Advances & expenses'),
            row(Icons.currency_rupee, 'Salary advance', pendingAdv > 0 ? '$pendingAdv request(s) pending' : 'Request money against salary',
                'Recovered from your monthly pay in instalments', const AdvancesScreen()),
            row(Icons.shopping_cart_outlined, 'Purchase advance', 'Money to buy something for work', 'Submit bills after purchase; HR verifies it',
                const AdvancesScreen(initialTab: 1)),
            row(Icons.receipt, 'Expense claims', pendingExp > 0 ? '$pendingExp claim(s) in progress' : 'Claim money you already spent',
                'HR approves, then pays you back', const AdvancesScreen(initialTab: 2)),
          ]);
        },
      );
}

/* ============================================ ADVANCES & EXPENSES */

class AdvancesScreen extends StatefulWidget {
  final int initialTab;
  const AdvancesScreen({super.key, this.initialTab = 0});
  @override
  State<AdvancesScreen> createState() => _AdvancesScreenState();
}

class _AdvancesScreenState extends State<AdvancesScreen> {
  final key = GlobalKey<LoaderState>();
  String filter = 'all';

  Future<void> newRequest(int tab) async {
    final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => AdvanceForm(kind: tab)));
    if (ok == true) key.currentState?.reload();
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 3,
        initialIndex: widget.initialTab,
        child: Builder(builder: (ctx) {
          return GlassPage(
            title: 'Advances & expenses',
            fab: FloatingActionButton.extended(
              tooltip: 'Create a new request of the selected type',
              backgroundColor: evaOrange,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add),
              label: const Text('New'),
              onPressed: () => newRequest(DefaultTabController.of(ctx).index),
            ),
            body: Column(children: [
              const TabBar(labelColor: evaDeep, indicatorColor: evaOrange, tabs: [Tab(text: 'Salary'), Tab(text: 'Purchase'), Tab(text: 'Expenses')]),
              ListControls(
                  filters: const ['all', 'pending', 'approved', 'rejected', 'closed', 'paid'],
                  selected: filter,
                  onFilter: (f) => setState(() => filter = f)),
              Expanded(
                child: Loader(
                  key: key,
                  load: () => Api.i.get('staff/advances'),
                  builder: (c, d) {
                    List<Map> f(List l) => l.cast<Map>().where((x) => filter == 'all' || x['status'] == filter).toList();
                    return TabBarView(children: [
                      _list(c, f(d['salary_advances']), 'salary', d),
                      _list(c, f(d['purchase_advances']), 'purchase', d),
                      _list(c, f(d['expenses']), 'expense', d),
                    ]);
                  },
                ),
              ),
            ]),
          );
        }),
      );

  Widget _list(BuildContext c, List<Map> l, String kind, Map d) => ListView(padding: const EdgeInsets.fromLTRB(12, 4, 12, 90), children: [
        if (kind == 'salary' && toD(d['outstanding']) > 0)
          Glass(
              tint: badRed,
              child: Row(children: [
                const Icon(Icons.info_outline, color: badRed),
                const SizedBox(width: 8),
                Expanded(child: Text('Outstanding: ${inr(d['outstanding'])} — recovered from your salary each month.')),
              ])),
        if (l.isEmpty)
          EmptyState(kind == 'expense' ? 'No expense claims here.' : 'No $kind advances here.', icon: Icons.currency_rupee),
        for (final x in l)
          Glass(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(
                    child: Text(kind == 'expense' ? inr(x['amount'], decimals: true) : inr(x['requested_amount'], decimals: true),
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                StatusPill('${x['status']}'),
              ]),
              if (kind == 'purchase' && x['item_description'] != null) Text('${x['item_description']}', style: const TextStyle(fontWeight: FontWeight.w600)),
              if ('${x['reason'] ?? ''}'.isNotEmpty) Text('${x['reason']}', style: const TextStyle(color: evaMuted)),
              const SizedBox(height: 4),
              if (kind != 'expense' && x['approved_amount'] != null) KVRow('Approved', inr(x['approved_amount'], decimals: true)),
              if (kind == 'salary' && x['monthly_deduction'] != null) KVRow('Monthly deduction', inr(x['monthly_deduction'], decimals: true)),
              if (kind == 'salary' && x['outstanding_balance'] != null) KVRow('Still to recover', inr(x['outstanding_balance'], decimals: true)),
              if (kind == 'purchase' && x['refund_amount'] != null) KVRow('Refund to company', inr(x['refund_amount'], decimals: true)),
              if (x['disbursed_at'] != null) KVRow('Paid to you', '${fdt(x['disbursed_at'])}${x['utr_number'] != null && '${x['utr_number']}'.isNotEmpty ? ' · UTR ${x['utr_number']}' : ''}'),
              if (kind == 'expense' && x['paid_at'] != null) KVRow('Paid', '${fdt(x['paid_at'])} · ${x['payment_mode'] ?? ''}'),
              if ('${x['admin_remarks'] ?? ''}'.isNotEmpty) Text('HR: ${x['admin_remarks']}', style: const TextStyle(color: evaDeep)),
              Text('Requested ${fdt(x['requested_at'] ?? x['submitted_at'])}', style: const TextStyle(fontSize: 11, color: evaMuted)),
            ]),
          ),
      ]);
}

class AdvanceForm extends StatefulWidget {
  final int kind; // 0 salary, 1 purchase, 2 expense
  const AdvanceForm({super.key, required this.kind});
  @override
  State<AdvanceForm> createState() => _AdvanceFormState();
}

class _AdvanceFormState extends State<AdvanceForm> {
  final amount = TextEditingController(), reason = TextEditingController(), item = TextEditingController();
  bool busy = false;

  Future<void> submit() async {
    final a = double.tryParse(amount.text.trim());
    if (a == null || a <= 0) return toast(context, 'Enter a valid amount', err: true);
    if (reason.text.trim().isEmpty) return toast(context, 'Please give a reason', err: true);
    if (widget.kind == 1 && item.text.trim().isEmpty) return toast(context, 'What needs to be purchased?', err: true);
    setState(() => busy = true);
    try {
      if (widget.kind == 2) {
        await Api.i.post('staff/expenses', {'amount': a, 'reason': reason.text.trim()});
      } else {
        await Api.i.post('staff/advances', {
          'type': widget.kind == 1 ? 'purchase' : 'salary',
          'amount': a,
          'reason': reason.text.trim(),
          if (widget.kind == 1) 'item_description': item.text.trim(),
        });
      }
      if (mounted) {
        toast(context, 'Submitted. HR has been notified.');
        Navigator.pop(context, true);
      }
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = ['Request salary advance', 'Request purchase advance', 'Submit expense claim'][widget.kind];
    final help = [
      'HR decides the approved amount and how much is deducted from each month\'s salary.',
      'Money to buy something for the company. After buying, HR verifies the bill and any balance is refunded.',
      'For money you already spent from your own pocket for company work. Keep the bill ready.',
    ][widget.kind];
    return GlassPage(
      title: title,
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Glass(child: Text(help)),
        const SizedBox(height: 10),
        TextField(
            controller: amount,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Amount (₹)', prefixIcon: Icon(Icons.currency_rupee))),
        const SizedBox(height: 10),
        if (widget.kind == 1) ...[
          TextField(controller: item, decoration: const InputDecoration(labelText: 'What needs to be purchased?')),
          const SizedBox(height: 10),
        ],
        TextField(controller: reason, maxLines: 3, decoration: const InputDecoration(labelText: 'Reason / details')),
        const SizedBox(height: 16),
        FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'Sending…' : 'Submit')),
      ]),
    );
  }
}

/* ============================================================ STATEMENT */

class StatementScreen extends StatefulWidget {
  const StatementScreen({super.key});
  @override
  State<StatementScreen> createState() => _StatementScreenState();
}

class _StatementScreenState extends State<StatementScreen> {
  int year = DateTime.now().year;
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Salary statement',
        body: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(tooltip: 'Previous year', icon: const Icon(Icons.chevron_left), onPressed: () => setState(() => year--)),
            Text('$year', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            IconButton(
                tooltip: 'Next year',
                icon: const Icon(Icons.chevron_right),
                onPressed: year >= DateTime.now().year ? null : () => setState(() => year++)),
          ]),
          Expanded(
            child: Loader(
              key: ValueKey(year),
              load: () => Api.i.get('staff/statement', {'year': '$year'}),
              builder: (c, d) {
                final rows = (d['rows'] as List).cast<Map>();
                return ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
                  TileGrid(children: [
                    KpiTile(label: 'Net pay $year', value: inr(d['total_net']), icon: Icons.savings_outlined, color: okGreen, tip: 'Total net pay of finalized months'),
                    KpiTile(label: 'Advance recovered', value: inr(d['total_advance_deducted']), icon: Icons.south_west, color: badRed, tip: 'Advance deducted from salary this year'),
                    KpiTile(label: 'Outstanding now', value: inr(d['outstanding_advance']), icon: Icons.pending_actions, color: evaDeep, tip: 'Advance balance still to recover'),
                  ]),
                  if (rows.isNotEmpty) ...[
                    const SectionTitle('Net pay by month'),
                    Glass(
                        child: MiniBars(
                            values: [for (final r in rows) toD(r['net_final'])],
                            labels: [for (final r in rows) monthShort(r['month'] as int)],
                            color: okGreen,
                            valueText: (v) => '${(v / 1000).toStringAsFixed(1)}k')),
                  ],
                  SectionTitle('Months',
                      trailing: rows.isEmpty
                          ? null
                          : IconButton(
                              tooltip: 'Export as CSV',
                              icon: const Icon(Icons.file_download_outlined),
                              onPressed: () => exportCsv(c, 'salary_statement_$year', ['Month', 'Payable days', 'Gross', 'Advance deducted', 'Net pay', 'Paid'], [
                                    for (final r in rows) [monthLong(r['month'] as int), r['payable_days'], r['gross_earning'], r['advance_deduction'], r['net_final'], r['paid_status']]
                                  ]))),
                  if (rows.isEmpty) const EmptyState('No finalized payroll for this year.'),
                  for (final r in rows)
                    Glass(
                      onTap: () => push(c, PayslipDetail(month: r['month'] as int, year: year)),
                      child: Row(children: [
                        SizedBox(width: 44, child: Text(monthShort(r['month'] as int), style: const TextStyle(fontWeight: FontWeight.w800))),
                        Expanded(
                            child: Text('${num1(r['payable_days'])} days · gross ${inr(r['gross_earning'])}${toD(r['advance_deduction']) > 0 ? ' · adv −${inr(r['advance_deduction'])}' : ''}',
                                style: const TextStyle(fontSize: 12, color: evaMuted))),
                        Text(inr(r['net_final']), style: const TextStyle(fontWeight: FontWeight.w800)),
                      ]),
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

/* ====================================================== SALARY DETAILS */

class SalaryDetailsScreen extends StatefulWidget {
  const SalaryDetailsScreen({super.key});
  @override
  State<SalaryDetailsScreen> createState() => _SalaryDetailsScreenState();
}

class _SalaryDetailsScreenState extends State<SalaryDetailsScreen> {
  int month = DateTime.now().month, year = DateTime.now().year;
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'How my salary is calculated',
        body: Column(children: [
          MonthBar(month: month, year: year, onChanged: (m, y) => setState(() { month = m; year = y; })),
          Expanded(
            child: Loader(
              key: ValueKey('$month-$year'),
              load: () => Api.i.get('staff/salary_details', {'month': '$month', 'year': '$year'}),
              builder: (c, d) {
                final e = Map<String, dynamic>.from(d['estimate'] ?? {});
                final s = d['saved'];
                final sh = d['shift'];
                return ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
                  Glass(tint: infoBlue, child: Text('${d['note']}')),
                  const SectionTitle('My rules', tip: 'Set by HR on the website'),
                  Glass(
                      child: Column(children: [
                    KVRow('Shift', sh == null ? 'Not set — ask HR' : '${sh['name']} ${sh['start']}–${sh['end']}'),
                    if (sh != null) KVRow('Come in by', '${sh['come_in_by']}', bold: true),
                    KVRow('Grace', '${d['grace_minutes']} min'),
                    KVRow('Week offs', d['week_off_quota'] == null ? 'Fixed weekly off' : '${d['week_off_quota']} per month'),
                  ])),
                  Glass(child: Text('${d['late_text']}', style: const TextStyle(fontSize: 12))),
                  const SectionTitle('This month so far'),
                  TileGrid(children: [
                    KpiTile(label: 'Payable days', value: num1(e['payable_days']), icon: Icons.event_available, color: okGreen, tip: 'Days you will be paid for'),
                    KpiTile(label: 'Estimated gross', value: inr(e['gross_earning']), icon: Icons.currency_rupee, color: evaDeep, tip: 'Before PF/ESI/advance deductions'),
                    KpiTile(label: 'Present', value: num1(e['present_days']), icon: Icons.check, color: okGreen, tip: 'Full days present'),
                    KpiTile(label: 'Half days', value: num1(e['half_days']), icon: Icons.timelapse, color: warnAmber, tip: 'Late after cut-off or short hours'),
                    KpiTile(label: 'Absent', value: num1(e['absent']), icon: Icons.close, color: badRed, tip: 'Unapproved absences'),
                    KpiTile(label: 'Leave', value: num1(toD(e['approved_leave_days']) + toD(e['unpaid_leave_days'])), icon: Icons.beach_access, color: infoBlue, tip: 'Paid + unpaid leave'),
                  ]),
                  if (s != null) ...[
                    const SectionTitle('Saved payroll'),
                    Glass(
                        onTap: () => push(c, PayslipDetail(month: month, year: year)),
                        child: Row(children: [
                          Expanded(child: Text('${num1(s['payable_days'])} payable days')),
                          Text(inr(s['net_final']), style: const TextStyle(fontWeight: FontWeight.w800)),
                          const Icon(Icons.chevron_right),
                        ])),
                  ],
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                      icon: const Icon(Icons.calendar_month),
                      label: const Text('See day-by-day attendance'),
                      onPressed: () => push(c, const GlassPage(title: 'Attendance', body: AttendanceScreen()))),
                  OutlinedButton.icon(
                      icon: const Icon(Icons.flag_outlined),
                      label: const Text('Something looks wrong? Tell HR'),
                      onPressed: () => push(
                          c,
                          NewGrievance(
                              cats: const ['Salary & Payroll', 'Attendance Issue', 'Other'],
                              initialCategory: 'Salary & Payroll',
                              initialSubject: 'Salary issue - ${monthLong(month)} $year'))),
                ]);
              },
            ),
          ),
        ]),
      );
}

/* ====================================================== DOCUMENTS & LETTERS */

class DocumentsScreen extends StatefulWidget {
  const DocumentsScreen({super.key});
  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> {
  final key = GlobalKey<LoaderState>();
  String q = '';
  String? opening;

  Future<void> open(Map doc) async {
    setState(() => opening = '${doc['id']}');
    try {
      final bytes = await Api.i.getBytes('staff/document_file', {'id': '${doc['id']}'});
      if (!mounted) return;
      final ext = '${doc['ext'] ?? ''}';
      await openBytes(context, bytes, '${doc['name']}${ext.isNotEmpty && !'${doc['name']}'.toLowerCase().endsWith('.$ext') ? '.$ext' : ''}');
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    } finally {
      if (mounted) setState(() => opening = null);
    }
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 3,
        child: GlassPage(
          title: 'Documents',
          body: Column(children: [
            const TabBar(labelColor: evaDeep, indicatorColor: evaOrange, tabs: [Tab(text: 'My files'), Tab(text: 'Letters'), Tab(text: 'Requests')]),
            Expanded(
              child: TabBarView(children: [
                Column(children: [
                  ListControls(searchHint: 'Search documents', onSearch: (v) => setState(() => q = v.toLowerCase())),
                  Expanded(
                    child: Loader(
                      load: () => Api.i.get('staff/documents'),
                      builder: (c, d) {
                        final l = (d['documents'] as List).cast<Map>().where((x) => q.isEmpty || '${x['name']}'.toLowerCase().contains(q)).toList();
                        return ListView(padding: const EdgeInsets.all(12), children: [
                          if (l.isEmpty) const EmptyState('No documents on file yet. HR uploads them on the website.', icon: Icons.folder_open),
                          for (final x in l)
                            Glass(
                              onTap: opening != null ? null : () => open(x),
                              child: Row(children: [
                                Icon(x['ext'] == 'pdf' ? Icons.picture_as_pdf : (['jpg', 'jpeg', 'png', 'webp'].contains(x['ext']) ? Icons.image : Icons.description),
                                    color: evaOrange),
                                const SizedBox(width: 10),
                                Expanded(
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text('${x['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                                  Text('Uploaded ${fdt(x['uploaded_at'])}', style: const TextStyle(fontSize: 12, color: evaMuted)),
                                ])),
                                opening == '${x['id']}'
                                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                    : const Tooltip(message: 'Open', child: Icon(Icons.open_in_new)),
                              ]),
                            ),
                        ]);
                      },
                    ),
                  ),
                ]),
                Loader(
                  load: () => Api.i.get('staff/letters'),
                  builder: (c, d) {
                    final l = (d['letters'] as List).cast<Map>();
                    return ListView(padding: const EdgeInsets.all(12), children: [
                      if (l.isEmpty) const EmptyState('No letters issued to you yet.', icon: Icons.mail_outline),
                      for (final x in l)
                        Glass(
                          onTap: () => push(c, LetterView(id: x['id'] as int, title: '${x['label']}')),
                          child: Row(children: [
                            const Icon(Icons.mail_outline, color: evaOrange),
                            const SizedBox(width: 10),
                            Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('${x['label']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              Text('Issue date ${fd(x['issue_date'])}', style: const TextStyle(fontSize: 12, color: evaMuted)),
                            ])),
                            const Icon(Icons.chevron_right),
                          ]),
                        ),
                    ]);
                  },
                ),
                Stack(children: [
                  Loader(
                    key: key,
                    load: () => Api.i.get('staff/doc_requests'),
                    builder: (c, d) {
                      final l = (d['requests'] as List).cast<Map>();
                      return ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [
                        if (l.isEmpty) const EmptyState('Ask HR for a salary certificate or experience letter with the button below.', icon: Icons.request_page),
                        for (final x in l)
                          Glass(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Expanded(child: Text('${x['label']}', style: const TextStyle(fontWeight: FontWeight.w700))),
                              StatusPill('${x['status']}'),
                            ]),
                            if ('${x['reason'] ?? ''}'.isNotEmpty) Text('${x['reason']}', style: const TextStyle(color: evaMuted)),
                            if ('${x['admin_remarks'] ?? ''}'.isNotEmpty) Text('HR: ${x['admin_remarks']}', style: const TextStyle(color: evaDeep)),
                            Text('Requested ${fdt(x['requested_at'])}', style: const TextStyle(fontSize: 11, color: evaMuted)),
                          ])),
                      ]);
                    },
                  ),
                  Positioned(
                    right: 16,
                    bottom: 16,
                    child: FloatingActionButton.extended(
                      tooltip: 'Ask HR for a certificate or letter',
                      backgroundColor: evaOrange,
                      foregroundColor: Colors.white,
                      icon: const Icon(Icons.add),
                      label: const Text('Request'),
                      onPressed: () async {
                        final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const DocRequestForm()));
                        if (ok == true) key.currentState?.reload();
                      },
                    ),
                  ),
                ]),
              ]),
            ),
          ]),
        ),
      );
}

class LetterView extends StatelessWidget {
  final int id;
  final String title;
  const LetterView({super.key, required this.id, required this.title});
  @override
  Widget build(BuildContext context) => GlassPage(
        title: title,
        body: Loader(
          load: () => Api.i.get('staff/letter', {'id': '$id'}),
          builder: (c, d) => ListView(padding: const EdgeInsets.all(16), children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: evaBorder)),
              child: SelectableText('${d['letter']['content']}', style: const TextStyle(height: 1.7, fontSize: 14)),
            ),
            const SizedBox(height: 10),
            Text('Issue date ${fd(d['letter']['issue_date'])} · long-press to copy text. For a signed print, ask HR.',
                style: const TextStyle(fontSize: 12, color: evaMuted)),
          ]),
        ),
      );
}

class DocRequestForm extends StatefulWidget {
  const DocRequestForm({super.key});
  @override
  State<DocRequestForm> createState() => _DocRequestFormState();
}

class _DocRequestFormState extends State<DocRequestForm> {
  String type = 'salary_certificate';
  final reason = TextEditingController();
  bool busy = false;
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Request a document',
        body: ListView(padding: const EdgeInsets.all(16), children: [
          DropdownButtonFormField<String>(
            value: type,
            decoration: const InputDecoration(labelText: 'Document'),
            items: const [
              DropdownMenuItem(value: 'salary_certificate', child: Text('Salary Certificate')),
              DropdownMenuItem(value: 'experience_letter', child: Text('Experience Letter')),
            ],
            onChanged: (v) => setState(() => type = v!),
          ),
          const SizedBox(height: 10),
          TextField(controller: reason, maxLines: 3, decoration: const InputDecoration(labelText: 'Purpose (optional)', helperText: 'e.g. bank loan, visa, rent agreement')),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    setState(() => busy = true);
                    try {
                      await Api.i.post('staff/doc_requests', {'doc_type': type, 'reason': reason.text.trim()});
                      if (context.mounted) {
                        toast(context, 'Request sent to HR');
                        Navigator.pop(context, true);
                      }
                    } on ApiError catch (e) {
                      if (context.mounted) toast(context, e.message, err: true);
                    } finally {
                      if (mounted) setState(() => busy = false);
                    }
                  },
            child: const Text('Send request'),
          ),
        ]),
      );
}

/* ================================================================ ASSETS */

class AssetsScreen extends StatefulWidget {
  const AssetsScreen({super.key});
  @override
  State<AssetsScreen> createState() => _AssetsScreenState();
}

class _AssetsScreenState extends State<AssetsScreen> {
  final key = GlobalKey<LoaderState>();
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'My assets',
        body: Loader(
          key: key,
          load: () => Api.i.get('staff/assets'),
          builder: (c, d) {
            final assets = (d['assets'] as List).cast<Map>();
            final reqs = (d['requests'] as List).cast<Map>();
            return ListView(padding: const EdgeInsets.all(16), children: [
              const SectionTitle('Assigned to me', tip: 'Company equipment in your care'),
              if (assets.isEmpty) const EmptyState('No company assets are assigned to you.', icon: Icons.devices_other),
              for (final a in assets)
                Glass(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.devices_other, color: evaOrange),
                      const SizedBox(width: 8),
                      Expanded(child: Text('${a['name']}', style: const TextStyle(fontWeight: FontWeight.w800))),
                      StatusPill('${a['status']}'),
                    ]),
                    Text('${a['category'] ?? ''}${a['serial_number'] != null ? ' · S/N ${a['serial_number']}' : ''} · since ${fd(a['assigned_date'])}',
                        style: const TextStyle(fontSize: 12, color: evaMuted)),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton.icon(
                        icon: const Icon(Icons.build_outlined, size: 18),
                        label: const Text('Report a problem'),
                        onPressed: () async {
                          final issue = await askText(c, 'What is wrong with ${a['name']}?', hint: 'Describe the problem', required: true, ok: 'Report');
                          if (issue == null || issue.isEmpty) return;
                          try {
                            await Api.i.post('staff/assets/report', {'asset_id': a['id'], 'issue': issue});
                            if (c.mounted) toast(c, 'Reported — HR will follow up');
                            key.currentState?.reload();
                          } on ApiError catch (e) {
                            if (c.mounted) toast(c, e.message, err: true);
                          }
                        },
                      ),
                    ),
                  ]),
                ),
              if (reqs.isNotEmpty) const SectionTitle('My reports'),
              for (final r in reqs)
                Glass(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [Expanded(child: Text('${r['asset']}', style: const TextStyle(fontWeight: FontWeight.w700))), StatusPill('${r['status']}')]),
                  Text('${r['issue']}'),
                  if ('${r['admin_remarks'] ?? ''}'.isNotEmpty) Text('HR: ${r['admin_remarks']}', style: const TextStyle(color: evaDeep)),
                  Text(fdt(r['reported_at']), style: const TextStyle(fontSize: 11, color: evaMuted)),
                ])),
            ]);
          },
        ),
      );
}

/* ============================================================ TEAM LEAVE */

class TeamLeaveScreen extends StatelessWidget {
  const TeamLeaveScreen({super.key});
  @override
  Widget build(BuildContext context) => const GlassPage(title: 'Team on leave', body: TeamLeaveBody());
}

class TeamLeaveBody extends StatefulWidget {
  const TeamLeaveBody({super.key});
  @override
  State<TeamLeaveBody> createState() => _TeamLeaveBodyState();
}

class _TeamLeaveBodyState extends State<TeamLeaveBody> {
  int month = DateTime.now().month, year = DateTime.now().year;
  @override
  Widget build(BuildContext context) => Column(children: [
        MonthBar(month: month, year: year, onChanged: (m, y) => setState(() { month = m; year = y; })),
        Expanded(
          child: Loader(
            key: ValueKey('$month-$year'),
            load: () => Api.i.get('staff/team_leave', {'month': '$month', 'year': '$year'}),
            builder: (c, d) {
              final l = (d['leaves'] as List).cast<Map>();
              return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
                const Padding(
                    padding: EdgeInsets.only(bottom: 6),
                    child: Text('Approved leave only · names and dates (no reasons) — plan your own leave around it.',
                        style: TextStyle(fontSize: 12, color: evaMuted))),
                if (l.isEmpty) const EmptyState('Nobody is on approved leave this month.', icon: Icons.groups_2_outlined),
                for (final x in l)
                  Glass(
                      child: Row(children: [
                    CircleAvatar(
                        backgroundColor: infoBlue.withAlpha(40),
                        child: Text('${x['name']}'.substring(0, 1), style: const TextStyle(color: infoBlue, fontWeight: FontWeight.w800))),
                    const SizedBox(width: 10),
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${x['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text('${fd(x['from_date'])} → ${fd(x['to_date'])}${x['type'] != null ? ' · ${x['type']}' : ''}',
                          style: const TextStyle(fontSize: 12, color: evaMuted)),
                    ])),
                    Pill('${num1(x['days'])}d', infoBlue),
                  ])),
              ]);
            },
          ),
        ),
      ]);
}

/* ================================================== PROFILE CHANGE REQUESTS */

class ProfileRequestsScreen extends StatefulWidget {
  const ProfileRequestsScreen({super.key});
  @override
  State<ProfileRequestsScreen> createState() => _ProfileRequestsScreenState();
}

class _ProfileRequestsScreenState extends State<ProfileRequestsScreen> {
  final key = GlobalKey<LoaderState>();
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Profile change requests',
        body: Loader(
          key: key,
          load: () => Api.i.get('staff/profile_requests'),
          builder: (c, d) {
            final fields = (d['fields'] as List).cast<Map>();
            final reqs = (d['requests'] as List).cast<Map>();
            return ListView(padding: const EdgeInsets.all(16), children: [
              const Glass(child: Text('Changes need HR approval. Your current details stay until HR approves.')),
              const SectionTitle('Change a detail'),
              for (final f in fields)
                Glass(
                  onTap: () async {
                    final v = await askText(c, 'New ${f['label']}', hint: 'Current: ${'${f['current']}'.isEmpty ? '–' : f['current']}', required: true, ok: 'Next');
                    if (v == null || v.isEmpty || !c.mounted) return;
                    final why = await askText(c, 'Why? (optional)', hint: 'e.g. changed bank', ok: 'Send');
                    if (why == null) return;
                    try {
                      await Api.i.post('staff/profile_requests', {'field_name': f['value'], 'new_value': v, 'reason': why});
                      if (c.mounted) toast(c, 'Sent to HR for approval');
                      key.currentState?.reload();
                    } on ApiError catch (e) {
                      if (c.mounted) toast(c, e.message, err: true);
                    }
                  },
                  child: Row(children: [
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${f['label']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text('${f['current']}'.isEmpty ? '–' : '${f['current']}', style: const TextStyle(color: evaMuted)),
                    ])),
                    const Icon(Icons.edit_outlined, color: evaOrange),
                  ]),
                ),
              if (reqs.isNotEmpty) const SectionTitle('My requests'),
              for (final r in reqs)
                Glass(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [Expanded(child: Text('${r['field']}', style: const TextStyle(fontWeight: FontWeight.w700))), StatusPill('${r['status']}')]),
                  Text('${'${r['old_value'] ?? ''}'.isEmpty ? '–' : r['old_value']}  →  ${r['new_value']}'),
                  if ('${r['admin_remarks'] ?? ''}'.isNotEmpty) Text('HR: ${r['admin_remarks']}', style: const TextStyle(color: evaDeep)),
                  Text(fdt(r['requested_at']), style: const TextStyle(fontSize: 11, color: evaMuted)),
                ])),
            ]);
          },
        ),
      );
}

/* ========================================================= ANNOUNCEMENTS */

class AnnouncementsScreen extends StatelessWidget {
  const AnnouncementsScreen({super.key});
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Announcements',
        body: Loader(
          load: () => Api.i.get('announcements'),
          builder: (c, d) {
            final l = (d['announcements'] as List).cast<Map>();
            return ListView(padding: const EdgeInsets.all(16), children: [
              if (l.isEmpty) const EmptyState('No announcements right now.', icon: Icons.campaign_outlined),
              for (final a in l)
                Glass(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${a['title']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  Text(fdt(a['posted_at']), style: const TextStyle(fontSize: 11, color: evaMuted)),
                  const SizedBox(height: 6),
                  SelectableText('${a['body']}'),
                ])),
            ]);
          },
        ),
      );
}

/* =================================================== REQUESTS (tab body) */

class RequestsHub extends StatelessWidget {
  const RequestsHub({super.key});
  @override
  Widget build(BuildContext context) {
    Widget row(IconData i, String t, String sub, Widget page) => Glass(
          onTap: () => push(context, page),
          child: Row(children: [
            Icon(i, color: evaOrange),
            const SizedBox(width: 12),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(sub, style: const TextStyle(color: evaMuted, fontSize: 12)),
            ])),
            const Icon(Icons.chevron_right),
          ]),
        );
    return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
      const SectionTitle('Ask HR'),
      row(Icons.event_available, 'Apply for leave', 'Full or half day, with balance shown', const ApplyLeave()),
      row(Icons.currency_rupee, 'Advance or expense', 'Salary advance, purchase advance, expense claim', const AdvancesScreen()),
      row(Icons.request_page_outlined, 'Certificate or letter', 'Salary certificate, experience letter', const DocumentsScreen()),
      row(Icons.manage_accounts_outlined, 'Change my details', 'Phone, email, address, bank', const ProfileRequestsScreen()),
      row(Icons.build_outlined, 'Asset problem', 'Laptop, phone or other company equipment', const AssetsScreen()),
      row(Icons.report_problem_outlined, 'Grievance', 'Raise a concern — track HR\'s reply', const GrievancesScreen()),
    ]);
  }
}
