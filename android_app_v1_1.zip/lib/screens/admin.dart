import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';
import 'staff.dart' show push, PayslipDetail, GrievanceCard;

/* =========================================================== DASHBOARD */

class AdminDashboard extends StatefulWidget {
  final void Function(int tab)? goTab;
  const AdminDashboard({super.key, this.goTab});
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final key = GlobalKey<LoaderState>();

  @override
  Widget build(BuildContext context) => Loader(
        key: key,
        load: () => Api.i.get('admin/dashboard'),
        builder: (c, d) {
          final p = Map<String, dynamic>.from(d['pending'] ?? {});
          final trend = (d['trend'] as List).cast<Map>();
          final pay = (d['payroll'] as List).cast<Map>();
          final up = (d['upcoming'] as List).cast<Map>();
          final team = (d['team'] as List).cast<Map>();
          final late = team.where((t) => t['is_late'] == true).toList();
          final absent = team.where((t) => t['status'] == 'A').toList();
          return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
            Text('${d['greeting']}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: evaInk)),
            Text('${d['company']} · ${fd(d['date'])}', style: const TextStyle(color: evaMuted)),
            const SizedBox(height: 10),
            AskEvaBar(onOpenEmployee: (id) => push(c, EmployeeDetail(id: id)), onInbox: () => widget.goTab?.call(1)),
            const SizedBox(height: 4),
            TileGrid(children: [
              KpiTile(label: 'Present today', value: '${d['present']}/${d['working_today']}', icon: Icons.how_to_reg, color: okGreen,
                  tip: 'Present or half day, out of people scheduled to work today', onTap: () => widget.goTab?.call(2)),
              KpiTile(label: 'Absent', value: '${d['absent']}', icon: Icons.person_off_outlined, color: badRed, tip: 'No punch and no approved leave',
                  onTap: () => widget.goTab?.call(2)),
              KpiTile(label: 'Late', value: '${d['late']}', icon: Icons.alarm, color: warnAmber, tip: 'Came after shift start + grace', onTap: () => widget.goTab?.call(2)),
              KpiTile(label: 'On leave', value: '${d['on_leave']}', icon: Icons.beach_access_outlined, color: infoBlue, tip: 'Approved leave today'),
              KpiTile(label: 'Waiting for you', value: '${p['total'] ?? 0}', icon: Icons.inbox_outlined, color: evaOrange,
                  tip: 'Leaves, advances, expenses, grievances and requests to decide', onTap: () => widget.goTab?.call(1)),
              KpiTile(
                  label: 'Unpaid ${monthShort(d['unpaid_last_month']['month'] as int)} salaries',
                  value: '${d['unpaid_last_month']['count']}',
                  icon: Icons.payments_outlined,
                  color: (d['unpaid_last_month']['count'] as int) > 0 ? badRed : okGreen,
                  tip: 'Payroll rows of last month not yet marked paid',
                  onTap: () => push(c, PayrollScreen(month: d['unpaid_last_month']['month'] as int, year: d['unpaid_last_month']['year'] as int))),
            ]),
            if (d['attendance_rate'] != null) ...[
              const SizedBox(height: 4),
              Glass(
                child: Row(children: [
                  SizedBox(
                    width: 64,
                    height: 64,
                    child: Stack(alignment: Alignment.center, children: [
                      CircularProgressIndicator(
                          value: toD(d['attendance_rate']) / 100, strokeWidth: 7, color: okGreen, backgroundColor: okGreen.withAlpha(40)),
                      Text('${d['attendance_rate']}%', style: const TextStyle(fontWeight: FontWeight.w800)),
                    ]),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(child: Text('Attendance today\n(present ÷ people due to work)', style: TextStyle(color: evaMuted))),
                ]),
              ),
            ],
            const SectionTitle('Present per day · last 14 days', tip: 'From synced biometric + app punches'),
            Glass(
                child: MiniBars(
                    values: [for (final t in trend) toD(t['present'])],
                    labels: [for (final t in trend) '${t['date']}'.substring(8)],
                    color: okGreen)),
            if (pay.isNotEmpty) ...[
              const SectionTitle('Net payroll by month', tip: 'Total net pay incl. manual adjustments'),
              Glass(
                  child: MiniBars(
                      values: [for (final x in pay) toD(x['total'])],
                      labels: [for (final x in pay) '${x['label']}'],
                      color: evaOrange,
                      valueText: (v) => v >= 100000 ? '${(v / 100000).toStringAsFixed(1)}L' : '${(v / 1000).toStringAsFixed(0)}k')),
            ],
            if ((p['total'] ?? 0) > 0) ...[
              SectionTitle('Approvals', trailing: TextButton(onPressed: () => widget.goTab?.call(1), child: const Text('Open inbox'))),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final e in {
                  'leaves': 'Leaves', 'advances': 'Advances', 'expenses': 'Expenses', 'grievances': 'Grievances',
                  'profile': 'Profile changes', 'documents': 'Documents', 'assets': 'Assets'
                }.entries)
                  if ((p[e.key] ?? 0) > 0)
                    ActionChip(
                        tooltip: 'Open ${e.value} in the inbox',
                        avatar: CircleAvatar(backgroundColor: evaOrange, child: Text('${p[e.key]}', style: const TextStyle(color: Colors.white, fontSize: 11))),
                        label: Text(e.value),
                        onPressed: () => widget.goTab?.call(1)),
              ]),
            ],
            if (late.isNotEmpty || absent.isNotEmpty) ...[
              const SectionTitle('Today'),
              for (final t in [...late, ...absent].take(8))
                Glass(
                  onTap: () => push(c, EmployeeDetail(id: t['employee_id'] as int)),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(children: [
                    Expanded(child: Text('${t['name']}', style: const TextStyle(fontWeight: FontWeight.w600))),
                    if (t['is_late'] == true) Pill('Late · ${t['in_time']}', warnAmber) else const StatusPill('A'),
                  ]),
                ),
            ],
            if (up.isNotEmpty) ...[
              const SectionTitle('Coming up · 30 days'),
              for (final e in up)
                Glass(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(children: [
                    Icon(e['type'] == 'Birthday' ? Icons.cake_outlined : Icons.workspace_premium_outlined, color: evaOrange),
                    const SizedBox(width: 10),
                    Expanded(
                        child: Text('${e['name']} · ${e['type']}${e['years'] != null ? ' (${e['years']} yr)' : ''}',
                            style: const TextStyle(fontWeight: FontWeight.w600))),
                    Text(e['in_days'] == 0 ? 'Today' : (e['in_days'] == 1 ? 'Tomorrow' : fd(e['date'])), style: const TextStyle(color: evaMuted)),
                  ]),
                ),
            ],
          ]);
        },
      );
}

/// Ask Eva — same brain as the website (read-only questions about the team).
class AskEvaBar extends StatefulWidget {
  final void Function(int employeeId) onOpenEmployee;
  final VoidCallback onInbox;
  const AskEvaBar({super.key, required this.onOpenEmployee, required this.onInbox});
  @override
  State<AskEvaBar> createState() => _AskEvaBarState();
}

class _AskEvaBarState extends State<AskEvaBar> {
  final c = TextEditingController();
  Map<String, dynamic>? ans;
  bool busy = false;

  Future<void> ask(String q) async {
    c.text = q;
    setState(() => busy = true);
    try {
      final r = await Api.i.get('admin/ask_eva', {'q': q});
      if (mounted) setState(() => ans = r);
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Glass(
        tint: const Color(0xFF7C4DFF),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.auto_awesome, color: Color(0xFF7C4DFF)),
            const SizedBox(width: 8),
            const Text('Ask Eva', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(width: 4),
            const InfoTip('Ask about your team in plain words: who is late, absent, pending approvals, unpaid salaries, or type a name.'),
            const Spacer(),
            if (ans != null) IconButton(tooltip: 'Clear answer', icon: const Icon(Icons.close, size: 18), onPressed: () => setState(() => ans = null)),
          ]),
          TextField(
            controller: c,
            textInputAction: TextInputAction.search,
            onSubmitted: (v) => v.trim().isEmpty ? null : ask(v.trim()),
            decoration: InputDecoration(
              isDense: true,
              hintText: 'e.g. who is late today?',
              suffixIcon: busy
                  ? const Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)))
                  : IconButton(tooltip: 'Ask', icon: const Icon(Icons.send), onPressed: () => c.text.trim().isEmpty ? null : ask(c.text.trim())),
            ),
          ),
          if (ans == null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Wrap(spacing: 6, runSpacing: 0, children: [
                for (final s in ['Who is late today?', 'Who is absent today?', 'Pending approvals', 'Salary pending this month', 'Late 3+ times this month'])
                  ActionChip(label: Text(s, style: const TextStyle(fontSize: 12)), onPressed: () => ask(s)),
              ]),
            ),
          if (ans != null) ...[
            const SizedBox(height: 8),
            Text('${ans!['title']}', style: const TextStyle(fontWeight: FontWeight.w800)),
            if ('${ans!['text'] ?? ''}'.isNotEmpty) Text('${ans!['text']}'),
            for (final r in ((ans!['rows'] as List?) ?? []).cast<Map>())
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text('${r['label']}'),
                subtitle: '${r['sub'] ?? ''}'.isEmpty ? null : Text('${r['sub']}'),
                trailing: r['target'] == null ? null : const Icon(Icons.chevron_right),
                onTap: r['target'] == null
                    ? null
                    : () {
                        final t = '${r['target']}';
                        if (t.startsWith('employee:')) widget.onOpenEmployee(int.parse(t.substring(9)));
                        if (t == 'inbox') widget.onInbox();
                        if (t == 'payroll') push(context, PayrollScreen(month: DateTime.now().month, year: DateTime.now().year));
                        if (t.startsWith('ask:')) ask(t.substring(4));
                      },
              ),
            if ('${ans!['hint'] ?? ''}'.isNotEmpty) Text('${ans!['hint']}', style: const TextStyle(fontSize: 12, color: evaMuted)),
          ],
        ]),
      );
}

/* =============================================================== INBOX */

class InboxScreen extends StatefulWidget {
  const InboxScreen({super.key});
  @override
  State<InboxScreen> createState() => _InboxScreenState();
}

class _InboxScreenState extends State<InboxScreen> {
  final key = GlobalKey<LoaderState>();
  String kind = 'all';
  String sort = 'oldest';
  String q = '';
  final selected = <String>{};

  static const kinds = {
    'all': 'All', 'leave': 'Leaves', 'advance': 'Advances', 'expense': 'Expenses', 'grievance': 'Grievances',
    'profile': 'Profile', 'document': 'Documents', 'asset': 'Assets',
  };

  IconData icon(String k) => {
        'leave': Icons.beach_access_outlined, 'advance': Icons.currency_rupee, 'expense': Icons.receipt, 'grievance': Icons.report_problem_outlined,
        'profile': Icons.manage_accounts_outlined, 'document': Icons.request_page_outlined, 'asset': Icons.build_outlined,
      }[k] ??
      Icons.inbox;

  Future<bool> act(Map it, String what) async {
    String? remarks;
    final body = <String, dynamic>{};
    String ep;
    switch ('${it['kind']}') {
      case 'leave':
        ep = 'admin/leaves/decide';
        body['leave_id'] = it['id'];
        body['decision'] = what == 'approve' ? 'approved' : 'rejected';
        if (what == 'approve_unpaid') {
          body['decision'] = 'approved';
          body['pay_type'] = 'unpaid';
        }
        break;
      case 'advance':
        ep = 'admin/advances/decide';
        body['advance_id'] = it['id'];
        body['action'] = what;
        if (what == 'approve') {
          final amt = await askText(context, 'Approved amount (₹)', initial: num1(it['amount']), required: true, ok: 'Next');
          if (amt == null) return false;
          body['approved_amount'] = double.tryParse(amt) ?? it['amount'];
          if (it['advance_type'] == 'salary') {
            if (!mounted) return false;
            final m = await askText(context, 'Deduct per month (₹)', hint: 'Recovered from each salary', required: true, ok: 'Approve');
            if (m == null) return false;
            body['monthly_deduction'] = double.tryParse(m) ?? 0;
          }
        }
        break;
      case 'expense':
        ep = 'admin/expenses/decide';
        body['expense_id'] = it['id'];
        body['action'] = what;
        break;
      case 'grievance':
        ep = 'admin/grievances/update';
        body['grievance_id'] = it['id'];
        body['status'] = what;
        break;
      case 'profile':
        ep = 'admin/profile_requests/decide';
        body['request_id'] = it['id'];
        body['decision'] = what == 'approve' ? 'approved' : 'rejected';
        break;
      case 'document':
        ep = 'admin/doc_requests/decide';
        body['request_id'] = it['id'];
        body['decision'] = what == 'approve' ? 'issued' : 'rejected';
        break;
      default:
        ep = 'admin/asset_requests/update';
        body['request_id'] = it['id'];
        body['status'] = what;
    }
    if (!mounted) return false;
    final needReason = what == 'reject' || what == 'rejected';
    remarks = await askText(context, needReason ? 'Reason for rejecting (sent to employee)' : 'Note to employee (optional)',
        required: needReason, ok: needReason ? 'Reject' : 'Confirm');
    if (remarks == null) return false;
    body['remarks'] = remarks;
    try {
      final r = await Api.i.post(ep, body);
      if (mounted) toast(context, '${r['message'] ?? 'Done'}');
      return true;
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
      return false;
    }
  }

  List<(String, String)> actionsFor(Map it) {
    switch ('${it['kind']}') {
      case 'leave':
        return [('approve', 'Approve (paid)'), ('approve_unpaid', 'Approve unpaid'), ('reject', 'Reject')];
      case 'grievance':
        return [('in_review', 'In review'), ('resolved', 'Resolve'), ('rejected', 'Reject')];
      case 'asset':
        return [('in_progress', 'Working on it'), ('resolved', 'Resolved'), ('rejected', 'Reject')];
      case 'document':
        return [('approve', 'Mark issued'), ('reject', 'Reject')];
      default:
        return [('approve', 'Approve'), ('reject', 'Reject')];
    }
  }

  @override
  Widget build(BuildContext context) => Loader(
        key: key,
        load: () => Api.i.get('admin/inbox'),
        builder: (c, d) {
          final counts = Map<String, dynamic>.from(d['counts']);
          var items = (d['items'] as List).cast<Map>().where((x) => kind == 'all' || x['kind'] == kind).toList();
          if (q.isNotEmpty) items = items.where((x) => '${x['employee']} ${x['title']} ${x['detail']}'.toLowerCase().contains(q)).toList();
          if (sort == 'newest') items = items.reversed.toList();
          if (sort == 'name') items.sort((a, b) => '${a['employee']}'.compareTo('${b['employee']}'));
          final bulkable = items.where((x) => selected.contains('${x['kind']}${x['id']}')).toList();
          return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
            ListControls(
              searchHint: 'Search name or request',
              onSearch: (v) => setState(() => q = v.toLowerCase()),
              filters: kinds.keys.toList(),
              selected: kind,
              onFilter: (f) => setState(() => kind = f),
              filterLabel: (f) => f == 'all' ? 'All ${d['total']}' : '${kinds[f]} ${counts[f] ?? 0}',
              sorts: const {'oldest': 'Waiting longest', 'newest': 'Newest first', 'name': 'Employee name'},
              sort: sort,
              onSort: (v) => setState(() => sort = v),
              onExport: () => exportCsv(c, 'pending_approvals', ['Type', 'Employee', 'Code', 'Request', 'Details', 'Since'],
                  [for (final x in items) [kinds[x['kind']], x['employee'], x['emp_code'], x['title'], x['detail'], fdt(x['at'])]]),
            ),
            if (bulkable.isNotEmpty)
              Glass(
                tint: evaOrange,
                child: Row(children: [
                  Expanded(child: Text('${bulkable.length} selected', style: const TextStyle(fontWeight: FontWeight.w700))),
                  Tooltip(
                    message: 'Approve all selected leave and expense requests (paid leave). Others need individual review.',
                    child: FilledButton(
                      style: FilledButton.styleFrom(minimumSize: const Size(0, 40)),
                      onPressed: () async {
                        final ok = bulkable.where((x) => x['kind'] == 'leave' || x['kind'] == 'expense').toList();
                        if (ok.isEmpty) {
                          toast(c, 'Bulk approve works for leaves and expenses only.', err: true);
                          return;
                        }
                        if (!await confirm(c, 'Approve ${ok.length} request(s)?', 'Leaves are approved as paid. Each employee is notified.', ok: 'Approve all')) return;
                        var done = 0;
                        for (final x in ok) {
                          try {
                            if (x['kind'] == 'leave') {
                              await Api.i.post('admin/leaves/decide', {'leave_id': x['id'], 'decision': 'approved', 'pay_type': 'paid', 'remarks': ''});
                            } else {
                              await Api.i.post('admin/expenses/decide', {'expense_id': x['id'], 'action': 'approve', 'remarks': ''});
                            }
                            done++;
                          } catch (_) {}
                        }
                        if (c.mounted) toast(c, 'Approved $done of ${ok.length}');
                        setState(() => selected.clear());
                        key.currentState?.reload();
                      },
                      child: const Text('Approve selected'),
                    ),
                  ),
                  IconButton(tooltip: 'Clear selection', icon: const Icon(Icons.close), onPressed: () => setState(() => selected.clear())),
                ]),
              ),
            if (items.isEmpty) const EmptyState('Nothing waiting. You are all caught up 🎉', icon: Icons.task_alt),
            for (final it in items)
              Glass(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Checkbox(
                      value: selected.contains('${it['kind']}${it['id']}'),
                      visualDensity: VisualDensity.compact,
                      onChanged: (v) => setState(() {
                        if (v == true) {
                          selected.add('${it['kind']}${it['id']}');
                        } else {
                          selected.remove('${it['kind']}${it['id']}');
                        }
                      }),
                    ),
                    Icon(icon('${it['kind']}'), color: evaOrange, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${it['employee']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                      Text('${it['title']}', style: const TextStyle(color: evaDeep, fontWeight: FontWeight.w600)),
                    ])),
                    if (it['priority'] == 'urgent') const StatusPill('urgent'),
                  ]),
                  if (it['kind'] == 'leave') Text('${fd(it['from_date'])} → ${fd(it['to_date'])}${it['is_half_day'] == true ? ' (half day)' : ''}${it['sub'] != null ? ' · ${it['sub']}' : ''}'),
                  if (it['kind'] == 'profile') Text('${'${it['old_value']}'.isEmpty ? '–' : it['old_value']}  →  ${it['new_value']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  if (it['kind'] == 'advance' && it['sub'] != null) Text('Item: ${it['sub']}'),
                  if (it['kind'] == 'grievance' && it['sub'] != null) Text('${it['sub']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  if ('${it['detail'] ?? ''}'.isNotEmpty) Text('${it['detail']}', maxLines: 4, overflow: TextOverflow.ellipsis, style: const TextStyle(color: evaMuted)),
                  Text('Waiting since ${fdt(it['at'])}', style: const TextStyle(fontSize: 11, color: evaMuted)),
                  const SizedBox(height: 6),
                  Wrap(spacing: 8, runSpacing: 4, children: [
                    for (final a in actionsFor(it))
                      (a.$1.contains('reject'))
                          ? OutlinedButton(
                              style: OutlinedButton.styleFrom(foregroundColor: badRed, minimumSize: const Size(0, 36)),
                              onPressed: () async {
                                if (await act(it, a.$1)) key.currentState?.reload();
                              },
                              child: Text(a.$2))
                          : FilledButton(
                              style: FilledButton.styleFrom(minimumSize: const Size(0, 36)),
                              onPressed: () async {
                                if (await act(it, a.$1)) key.currentState?.reload();
                              },
                              child: Text(a.$2)),
                    TextButton(onPressed: () => push(c, EmployeeDetail(id: it['employee_id'] as int)), child: const Text('Profile')),
                  ]),
                ]),
              ),
            const SizedBox(height: 10),
            Wrap(spacing: 8, runSpacing: 8, children: [
              OutlinedButton.icon(icon: const Icon(Icons.history), label: const Text('Leave history'), onPressed: () => push(c, const LeavesHistory())),
              OutlinedButton.icon(icon: const Icon(Icons.history), label: const Text('Advances'), onPressed: () => push(c, const AdvancesHistory())),
              OutlinedButton.icon(icon: const Icon(Icons.history), label: const Text('Expenses'), onPressed: () => push(c, const ExpensesHistory())),
              OutlinedButton.icon(icon: const Icon(Icons.history), label: const Text('Grievances'), onPressed: () => push(c, const AdminGrievances())),
            ]),
          ]);
        },
      );
}

/* ============================================================== TEAM */

class TeamScreen extends StatefulWidget {
  const TeamScreen({super.key});
  @override
  State<TeamScreen> createState() => _TeamScreenState();
}

class _TeamScreenState extends State<TeamScreen> {
  DateTime date = DateTime.now();
  String filter = 'all';
  String sort = 'name';
  String q = '';
  @override
  Widget build(BuildContext context) => Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton(tooltip: 'Previous day', icon: const Icon(Icons.chevron_left), onPressed: () => setState(() => date = date.subtract(const Duration(days: 1)))),
          TextButton(
              onPressed: () async {
                final d = await showDatePicker(context: context, initialDate: date, firstDate: DateTime(2023), lastDate: DateTime.now());
                if (d != null) setState(() => date = d);
              },
              child: Text(fd(isoDate(date)), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          IconButton(
              tooltip: 'Next day',
              icon: const Icon(Icons.chevron_right),
              onPressed: isoDate(date) == isoDate(DateTime.now()) ? null : () => setState(() => date = date.add(const Duration(days: 1)))),
        ]),
        Expanded(
          child: Loader(
            key: ValueKey(isoDate(date)),
            load: () => Api.i.get('admin/team', {'date': isoDate(date)}),
            builder: (c, d) {
              final all = (d['team'] as List).cast<Map>();
              var l = all.where((t) => filter == 'all' || t['status'] == filter || (filter == 'late' && t['is_late'] == true)).toList();
              if (q.isNotEmpty) l = l.where((t) => '${t['name']} ${t['emp_code']}'.toLowerCase().contains(q)).toList();
              if (sort == 'in') l.sort((a, b) => '${a['in_time'] ?? '99'}'.compareTo('${b['in_time'] ?? '99'}'));
              if (sort == 'status') l.sort((a, b) => '${a['status']}'.compareTo('${b['status']}'));
              int n(String s) => all.where((t) => t['status'] == s).length;
              return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
                ListControls(
                  searchHint: 'Search name or code',
                  onSearch: (v) => setState(() => q = v.toLowerCase()),
                  filters: const ['all', 'P', 'HD', 'A', 'L', 'WO', 'late'],
                  selected: filter,
                  onFilter: (f) => setState(() => filter = f),
                  filterLabel: (f) => f == 'all'
                      ? 'All ${all.length}'
                      : (f == 'late' ? 'Late ${all.where((t) => t['is_late'] == true).length}' : '${statusLabel(f)} ${n(f)}'),
                  sorts: const {'name': 'Name', 'in': 'Earliest IN', 'status': 'Status'},
                  sort: sort,
                  onSort: (v) => setState(() => sort = v),
                  onExport: () => exportCsv(c, 'team_${d['date']}', ['Name', 'Code', 'Status', 'In', 'Out', 'Late'],
                      [for (final t in l) [t['name'], t['emp_code'], statusLabel('${t['status']}'), t['in_time'], t['out_time'], t['is_late'] == true ? 'Yes' : '']]),
                ),
                if (l.isEmpty) const EmptyState('Nobody matches.'),
                for (final t in l)
                  Glass(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    onTap: () => push(c, EmployeeDetail(id: t['employee_id'] as int)),
                    child: Row(children: [
                      Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${t['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text('${t['emp_code']} · ${t['in_time'] ?? '--:--'} → ${t['out_time'] ?? '--:--'}', style: const TextStyle(fontSize: 12, color: evaMuted)),
                      ])),
                      if (t['is_late'] == true) ...[const Pill('Late', warnAmber), const SizedBox(width: 6)],
                      StatusPill('${t['status']}'),
                    ]),
                  ),
              ]);
            },
          ),
        ),
      ]);
}

/* ========================================================= EMPLOYEES */

class EmployeesScreen extends StatefulWidget {
  const EmployeesScreen({super.key});
  @override
  State<EmployeesScreen> createState() => _EmployeesScreenState();
}

class _EmployeesScreenState extends State<EmployeesScreen> {
  String q = '', status = 'active', sort = 'name';
  int dept = 0;
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Employees',
        body: Loader(
          key: ValueKey('$q|$status|$sort|$dept'),
          load: () => Api.i.get('admin/employees2', {'q': q, 'status': status, 'sort': sort, 'department_id': '$dept'}),
          builder: (c, d) {
            final l = (d['employees'] as List).cast<Map>();
            final deps = (d['departments'] as List).cast<Map>();
            return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
              ListControls(
                searchHint: 'Name, code, phone, designation',
                onSearch: (v) => setState(() => q = v),
                filters: const ['active', 'inactive', 'all'],
                selected: status,
                onFilter: (f) => setState(() => status = f),
                sorts: const {'name': 'Name', 'code': 'Employee code', 'doj': 'Newest joiners', 'designation': 'Designation'},
                sort: sort,
                onSort: (v) => setState(() => sort = v),
                onExport: () => exportCsv(c, 'employees', ['Name', 'Code', 'Designation', 'Department', 'Shift', 'Phone', 'Joined', 'Status'],
                    [for (final e in l) [e['name'], e['emp_code'], e['designation'], e['department'], e['shift'], e['phone'], fd(e['doj']), e['status']]]),
              ),
              if (deps.isNotEmpty)
                SizedBox(
                  height: 44,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: ChoiceChip(label: const Text('All departments'), selected: dept == 0, onSelected: (_) => setState(() => dept = 0))),
                    for (final x in deps)
                      Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: ChoiceChip(label: Text('${x['name']}'), selected: dept == x['id'], onSelected: (_) => setState(() => dept = x['id'] as int))),
                  ]),
                ),
              Padding(padding: const EdgeInsets.all(4), child: Text('${l.length} employee(s)', style: const TextStyle(color: evaMuted, fontSize: 12))),
              if (l.isEmpty) const EmptyState('No employees match.', icon: Icons.people_outline),
              for (final e in l)
                Glass(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  onTap: () => push(c, EmployeeDetail(id: e['id'] as int)),
                  child: Row(children: [
                    CircleAvatar(
                      backgroundColor: evaOrange.withAlpha(40),
                      backgroundImage: e['photo_url'] != null ? NetworkImage('${e['photo_url']}') : null,
                      child: e['photo_url'] == null ? Text('${e['name']}'.substring(0, 1), style: const TextStyle(color: evaDeep, fontWeight: FontWeight.w800)) : null,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${e['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text('${e['emp_code']} · ${e['designation'] ?? '–'}${e['department'] != null ? ' · ${e['department']}' : ''}',
                          style: const TextStyle(fontSize: 12, color: evaMuted)),
                    ])),
                    if (e['status'] != 'active') StatusPill('${e['status']}'),
                    const Icon(Icons.chevron_right),
                  ]),
                ),
            ]);
          },
        ),
      );
}

class EmployeeDetail extends StatelessWidget {
  final int id;
  const EmployeeDetail({super.key, required this.id});
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Employee',
        body: Loader(
          load: () => Api.i.get('admin/employee', {'id': '$id'}),
          builder: (c, d) {
            final e = Map<String, dynamic>.from(d['employee']);
            final s = Map<String, dynamic>.from(d['salary_structure'] ?? {});
            final m = Map<String, dynamic>.from(d['month_summary'] ?? {});
            final gross = s.values.fold<double>(0, (a, b) => a + toD(b));
            final loc = d['last_location'];
            return ListView(padding: const EdgeInsets.all(16), children: [
              Row(children: [
                CircleAvatar(
                  radius: 32,
                  backgroundColor: evaOrange,
                  backgroundImage: e['photo_url'] != null ? NetworkImage('${e['photo_url']}') : null,
                  child: e['photo_url'] == null ? Text('${e['name']}'.substring(0, 1), style: const TextStyle(fontSize: 24, color: Colors.white)) : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${e['name']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  Text('${e['designation'] ?? ''} · ${e['emp_code']}', style: const TextStyle(color: evaMuted)),
                  StatusPill('${e['status']}'),
                ])),
              ]),
              const SectionTitle('This month'),
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final k in ['P', 'HD', 'A', 'L', 'UL', 'WO', 'H'])
                  if (toD(m[k]) > 0) Pill('${statusLabel(k)} ${num1(m[k])}', statusColor(k)),
              ]),
              const SizedBox(height: 6),
              Row(children: [
                Expanded(
                    child: OutlinedButton.icon(
                        icon: const Icon(Icons.calendar_month),
                        label: const Text('Attendance'),
                        onPressed: () => push(c, EmployeeAttendance(id: id, name: '${e['name']}')))),
                const SizedBox(width: 8),
                Expanded(
                    child: OutlinedButton.icon(
                        icon: const Icon(Icons.receipt_long),
                        label: const Text('Payslip'),
                        onPressed: () {
                          final now = DateTime.now();
                          final prev = DateTime(now.year, now.month - 1, 1);
                          push(c, PayslipDetail(month: prev.month, year: prev.year, endpoint: 'admin/payslip', extra: {'id': '$id'}));
                        })),
              ]),
              const SectionTitle('Job'),
              Glass(
                  child: Column(children: [
                KVRow('Department', '${e['department'] ?? ''}'),
                KVRow('Reporting to', '${e['reporting_manager'] ?? ''}'),
                KVRow('Shift', '${e['shift'] ?? 'Not set'}'),
                KVRow('Week offs / month', e['monthly_week_off_quota'] == null ? 'Fixed weekly off' : '${e['monthly_week_off_quota']}'),
                KVRow('Joined', fd(e['doj'])),
                KVRow('App punching', e['app_punch_allowed'] == true ? 'Allowed' : 'Off'),
              ])),
              const SectionTitle('Contact'),
              Glass(
                  child: Column(children: [
                KVRow('Phone', '${e['phone'] ?? ''}'),
                KVRow('Email', '${e['email'] ?? ''}'),
                KVRow('Address', '${e['address'] ?? ''}'),
                KVRow('Date of birth', fd(e['dob'])),
                KVRow('Father mobile', '${e['father_mobile'] ?? ''}'),
                KVRow('Mother mobile', '${e['mother_mobile'] ?? ''}'),
                KVRow('Spouse mobile', '${e['spouse_mobile'] ?? ''}'),
              ])),
              const SectionTitle('Salary structure', tip: 'Monthly, before attendance-based calculation'),
              Glass(
                  child: Column(children: [
                KVRow('Basic', inr(s['basic'])),
                KVRow('HRA', inr(s['hra'])),
                KVRow('Conveyance', inr(s['conveyance'])),
                KVRow('Medical', inr(s['medical_allowance'])),
                KVRow('Other', inr(s['other_allowance'])),
                KVRow('Gross / month', inr(gross), bold: true),
              ])),
              if (d['latest_performance'] != null) ...[
                const SectionTitle('Latest performance'),
                Glass(
                    child: Text(
                        '${d['latest_performance']['rating']} / 5 · ${monthShort(int.tryParse('${d['latest_performance']['month']}') ?? 1)} ${d['latest_performance']['year']}\n${d['latest_performance']['remarks'] ?? ''}')),
              ],
              if (loc != null) ...[
                const SectionTitle('Last known location'),
                Glass(child: Text('${loc['source']} · ${fdt(loc['at'])}\n${loc['lat']}, ${loc['lng']}')),
              ],
            ]);
          },
        ),
      );
}

class EmployeeAttendance extends StatefulWidget {
  final int id;
  final String name;
  const EmployeeAttendance({super.key, required this.id, required this.name});
  @override
  State<EmployeeAttendance> createState() => _EmployeeAttendanceState();
}

class _EmployeeAttendanceState extends State<EmployeeAttendance> {
  int month = DateTime.now().month, year = DateTime.now().year;
  @override
  Widget build(BuildContext context) => GlassPage(
        title: widget.name,
        body: Column(children: [
          MonthBar(month: month, year: year, onChanged: (m, y) => setState(() { month = m; year = y; })),
          Expanded(
            child: Loader(
              key: ValueKey('$month-$year'),
              load: () => Api.i.get('admin/employee_attendance', {'id': '${widget.id}', 'month': '$month', 'year': '$year'}),
              builder: (c, d) {
                final rows = (d['rows'] as List).cast<Map>();
                return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
                  Align(
                      alignment: Alignment.centerRight,
                      child: IconButton(
                          tooltip: 'Export as CSV',
                          icon: const Icon(Icons.file_download_outlined),
                          onPressed: () => exportCsv(c, 'attendance_${widget.name}_$year-$month', ['Date', 'Day', 'Status', 'In', 'Out', 'Hours', 'Late', 'Why'],
                              [for (final r in rows) [fd(r['date']), r['day'], statusLabel('${r['status']}'), r['in_time'], r['out_time'], r['worked_text'], r['is_late'] == true ? 'Yes' : '', r['reason']]]))),
                  for (final r in rows)
                    Glass(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      child: Row(children: [
                        SizedBox(width: 70, child: Text('${'${r['date']}'.substring(8)} ${r['day']}', style: const TextStyle(fontWeight: FontWeight.w700))),
                        StatusPill('${r['status']}'),
                        if (r['is_late'] == true) ...[const SizedBox(width: 4), const Pill('Late', warnAmber)],
                        const Spacer(),
                        Text('${r['in_time'] ?? '--'} → ${r['out_time'] ?? '--'}', style: const TextStyle(fontSize: 12, color: evaMuted)),
                      ]),
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

/* ===================================================== ATTENDANCE SHEET */

class AttendanceSheetScreen extends StatefulWidget {
  const AttendanceSheetScreen({super.key});
  @override
  State<AttendanceSheetScreen> createState() => _AttendanceSheetScreenState();
}

class _AttendanceSheetScreenState extends State<AttendanceSheetScreen> {
  int month = DateTime.now().month, year = DateTime.now().year;
  String sort = 'name';
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Attendance sheet',
        body: Column(children: [
          MonthBar(month: month, year: year, onChanged: (m, y) => setState(() { month = m; year = y; })),
          Expanded(
            child: Loader(
              key: ValueKey('$month-$year'),
              load: () => Api.i.get('admin/attendance_sheet', {'month': '$month', 'year': '$year'}),
              builder: (c, d) {
                final l = (d['employees'] as List).cast<Map>().toList();
                double s(Map e, String k) => toD(e['summary'][k]);
                if (sort == 'absent') l.sort((a, b) => s(b, 'A').compareTo(s(a, 'A')));
                if (sort == 'present') l.sort((a, b) => s(b, 'P').compareTo(s(a, 'P')));
                if (sort == 'late') l.sort((a, b) => toD(b['late_days']).compareTo(toD(a['late_days'])));
                final days = d['days_in_month'] as int;
                return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
                  ListControls(
                    sorts: const {'name': 'Name', 'absent': 'Most absent', 'present': 'Most present', 'late': 'Most late'},
                    sort: sort,
                    onSort: (v) => setState(() => sort = v),
                    onExport: () => exportCsv(c, 'attendance_sheet_$year-$month', [
                      'Name', 'Code', for (var i = 1; i <= days; i++) '$i', 'P', 'HD', 'A', 'L', 'UL', 'WO', 'H', 'Late'
                    ], [
                      for (final e in l)
                        [e['name'], e['emp_code'], ...(e['days'] as List), for (final k in ['P', 'HD', 'A', 'L', 'UL', 'WO', 'H']) e['summary'][k], e['late_days']]
                    ]),
                  ),
                  const Padding(
                      padding: EdgeInsets.only(bottom: 6),
                      child: Text('Each square is a day: green present, amber half day, red absent, blue leave, grey off. Tap a person for details.',
                          style: TextStyle(fontSize: 12, color: evaMuted))),
                  for (final e in l)
                    Glass(
                      onTap: () => push(c, EmployeeAttendance(id: e['employee_id'] as int, name: '${e['name']}')),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(child: Text('${e['name']}', style: const TextStyle(fontWeight: FontWeight.w700))),
                          Text('P ${num1(s(e, 'P'))} · A ${num1(s(e, 'A'))} · Late ${e['late_days']}', style: const TextStyle(fontSize: 12, color: evaMuted)),
                        ]),
                        const SizedBox(height: 6),
                        Wrap(spacing: 2, runSpacing: 2, children: [
                          for (var i = 0; i < (e['days'] as List).length; i++)
                            Tooltip(
                              message: '${i + 1} ${monthShort(month)}: ${statusLabel('${e['days'][i]}')}',
                              child: Container(
                                width: 14,
                                height: 14,
                                decoration: BoxDecoration(
                                  color: e['days'][i] == 'PENDING' ? Colors.white.withAlpha(120) : statusColor('${e['days'][i]}').withAlpha(200),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                              ),
                            ),
                        ]),
                      ]),
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

/* ====================================================== LEAVE CALENDAR */

class LeaveCalendarScreen extends StatefulWidget {
  const LeaveCalendarScreen({super.key});
  @override
  State<LeaveCalendarScreen> createState() => _LeaveCalendarScreenState();
}

class _LeaveCalendarScreenState extends State<LeaveCalendarScreen> {
  int month = DateTime.now().month, year = DateTime.now().year;
  String filter = 'all';
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Leave calendar',
        body: Column(children: [
          MonthBar(month: month, year: year, onChanged: (m, y) => setState(() { month = m; year = y; })),
          Expanded(
            child: Loader(
              key: ValueKey('$month-$year'),
              load: () => Api.i.get('admin/leave_calendar', {'month': '$month', 'year': '$year'}),
              builder: (c, d) {
                final l = (d['leaves'] as List).cast<Map>().where((x) => filter == 'all' || x['status'] == filter).toList();
                final hol = (d['holidays'] as List).cast<Map>();
                return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
                  ListControls(filters: const ['all', 'approved', 'pending'], selected: filter, onFilter: (f) => setState(() => filter = f)),
                  if (hol.isNotEmpty) ...[
                    const SectionTitle('Holidays'),
                    for (final h in hol)
                      Glass(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          child: Row(children: [
                            const Icon(Icons.celebration_outlined, color: evaOrange),
                            const SizedBox(width: 8),
                            Expanded(child: Text('${h['name']}')),
                            Text(fd(h['date'])),
                          ])),
                  ],
                  const SectionTitle('Leave'),
                  if (l.isEmpty) const EmptyState('No leave this month.', icon: Icons.beach_access_outlined),
                  for (final x in l)
                    Glass(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      child: Row(children: [
                        Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${x['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text('${fd(x['from_date'])} → ${fd(x['to_date'])} · ${num1(x['days'])}d${x['type'] != null ? ' · ${x['type']}' : ''}',
                              style: const TextStyle(fontSize: 12, color: evaMuted)),
                        ])),
                        StatusPill('${x['status']}'),
                      ]),
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

/* ============================================================= PAYROLL */

class PayrollScreen extends StatefulWidget {
  final int month, year;
  const PayrollScreen({super.key, required this.month, required this.year});
  @override
  State<PayrollScreen> createState() => _PayrollScreenState();
}

class _PayrollScreenState extends State<PayrollScreen> {
  late int month = widget.month, year = widget.year;
  String filter = 'all', sort = 'name', q = '';
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Payroll',
        body: Column(children: [
          MonthBar(month: month, year: year, onChanged: (m, y) => setState(() { month = m; year = y; })),
          Expanded(
            child: Loader(
              key: ValueKey('$month-$year'),
              load: () => Api.i.get('admin/payroll', {'month': '$month', 'year': '$year'}),
              builder: (c, d) {
                final all = (d['payroll'] as List).cast<Map>();
                var l = all.where((p) => filter == 'all' || (filter == 'paid' ? p['paid_status'] == 'paid' : p['paid_status'] != 'paid')).toList();
                if (q.isNotEmpty) l = l.where((p) => '${p['name']} ${p['emp_code']}'.toLowerCase().contains(q)).toList();
                if (sort == 'net') l.sort((a, b) => toD(b['net_final']).compareTo(toD(a['net_final'])));
                if (sort == 'days') l.sort((a, b) => toD(a['payable_days']).compareTo(toD(b['payable_days'])));
                final unpaid = all.where((p) => p['paid_status'] != 'paid').fold<double>(0, (a, p) => a + toD(p['net_final']));
                return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
                  TileGrid(children: [
                    KpiTile(label: 'Total net', value: inr(d['total_net']), icon: Icons.payments_outlined, color: evaDeep, tip: 'Net pay incl. adjustments'),
                    KpiTile(label: 'Still to pay', value: inr(unpaid), icon: Icons.hourglass_bottom, color: unpaid > 0 ? badRed : okGreen, tip: 'Rows not marked paid'),
                  ]),
                  ListControls(
                    searchHint: 'Search name or code',
                    onSearch: (v) => setState(() => q = v.toLowerCase()),
                    filters: const ['all', 'unpaid', 'paid'],
                    selected: filter,
                    onFilter: (f) => setState(() => filter = f),
                    sorts: const {'name': 'Name', 'net': 'Highest net pay', 'days': 'Fewest payable days'},
                    sort: sort,
                    onSort: (v) => setState(() => sort = v),
                    onExport: () => exportCsv(c, 'payroll_$year-$month', ['Name', 'Code', 'Payable days', 'Net pay', 'Status', 'Paid'],
                        [for (final p in l) [p['name'], p['emp_code'], p['payable_days'], p['net_final'], p['status'], p['paid_status']]]),
                  ),
                  if (all.isEmpty) const EmptyState('Payroll is not generated for this month yet. Generate it on the website (Payroll page).', icon: Icons.payments_outlined),
                  for (final p in l)
                    Glass(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      onTap: () => push(c, PayslipDetail(month: month, year: year, endpoint: 'admin/payslip', extra: {'id': '${p['employee_id']}'})),
                      child: Row(children: [
                        Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text('${p['emp_code']} · ${num1(p['payable_days'])} days · ${statusLabel('${p['status']}')}', style: const TextStyle(fontSize: 12, color: evaMuted)),
                        ])),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text(inr(p['net_final']), style: const TextStyle(fontWeight: FontWeight.w800)),
                          StatusPill('${p['paid_status'] ?? 'unpaid'}'),
                        ]),
                      ]),
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

/* ============================================================= REPORTS */

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  int month = DateTime.now().month, year = DateTime.now().year;
  String sort = 'rate';
  @override
  Widget build(BuildContext context) => Column(children: [
        MonthBar(month: month, year: year, onChanged: (m, y) => setState(() { month = m; year = y; })),
        Expanded(
          child: Loader(
            key: ValueKey('$month-$year'),
            load: () => Api.i.get('admin/reports', {'month': '$month', 'year': '$year'}),
            builder: (c, d) {
              final t = Map<String, dynamic>.from(d['attendance_totals']);
              final pay = Map<String, dynamic>.from(d['payroll']);
              final deps = (d['departments'] as List).cast<Map>();
              final people = (d['employees'] as List).cast<Map>().toList();
              if (sort == 'rate') people.sort((a, b) => toD(a['attendance_rate'] ?? 101).compareTo(toD(b['attendance_rate'] ?? 101)));
              if (sort == 'late') people.sort((a, b) => toD(b['late']).compareTo(toD(a['late'])));
              if (sort == 'absent') people.sort((a, b) => toD(b['absent']).compareTo(toD(a['absent'])));
              if (sort == 'name') people.sort((a, b) => '${a['name']}'.compareTo('${b['name']}'));
              return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
                TileGrid(children: [
                  KpiTile(label: 'Headcount', value: '${d['headcount']}', icon: Icons.groups_outlined, tip: 'Active employees'),
                  KpiTile(label: 'Present days', value: num1(toD(t['P']) + toD(t['HD']) / 2), icon: Icons.check_circle_outline, color: okGreen, tip: 'Full days + half of half days'),
                  KpiTile(label: 'Absent days', value: num1(t['A']), icon: Icons.cancel_outlined, color: badRed, tip: 'Unapproved absences'),
                  KpiTile(label: 'Late arrivals', value: '${d['late_total']}', icon: Icons.alarm, color: warnAmber, tip: 'After shift start + grace'),
                  KpiTile(label: 'Leave days', value: num1(toD(t['L']) + toD(t['UL'])), icon: Icons.beach_access_outlined, color: infoBlue, tip: 'Paid + unpaid'),
                  KpiTile(label: 'Net payroll', value: inr(pay['net']), icon: Icons.payments_outlined, color: evaDeep,
                      tip: '${pay['generated_for']} payslip(s) · ${pay['paid']} paid', onTap: () => push(c, PayrollScreen(month: month, year: year))),
                ]),
                if (pay['generated_for'] > 0) ...[
                  const SectionTitle('Payroll breakup'),
                  Glass(
                      child: Column(children: [
                    KVRow('Gross', inr(pay['gross'])),
                    KVRow('PF', inr(pay['pf'])),
                    KVRow('ESI', inr(pay['esi'])),
                    KVRow('Advance recovered', inr(pay['advance_deducted'])),
                    KVRow('Overtime paid', inr(pay['overtime'])),
                    KVRow('Net', inr(pay['net']), bold: true),
                  ])),
                ],
                if (deps.isNotEmpty) ...[
                  const SectionTitle('By department'),
                  for (final x in deps)
                    Glass(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        child: Row(children: [
                          Expanded(child: Text('${x['department']}', style: const TextStyle(fontWeight: FontWeight.w700))),
                          Text('${x['headcount']} ppl · present ${num1(x['present'])} · absent ${num1(x['absent'])} · late ${x['late']}',
                              style: const TextStyle(fontSize: 12, color: evaMuted)),
                        ])),
                ],
                SectionTitle('People',
                    tip: 'Attendance rate = days worked ÷ days due (excludes week offs and holidays)',
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      PopupMenuButton<String>(
                        tooltip: 'Sort people',
                        icon: const Icon(Icons.sort),
                        initialValue: sort,
                        onSelected: (v) => setState(() => sort = v),
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'rate', child: Text('Lowest attendance')),
                          PopupMenuItem(value: 'late', child: Text('Most late')),
                          PopupMenuItem(value: 'absent', child: Text('Most absent')),
                          PopupMenuItem(value: 'name', child: Text('Name')),
                        ],
                      ),
                      IconButton(
                          tooltip: 'Export the report as CSV',
                          icon: const Icon(Icons.file_download_outlined),
                          onPressed: () => exportCsv(c, 'report_$year-$month', ['Name', 'Code', 'Department', 'Present', 'Half days', 'Absent', 'Leave', 'Late', 'Attendance %'],
                              [for (final p in people) [p['name'], p['emp_code'], p['department'], p['present'], p['half_days'], p['absent'], p['leave'], p['late'], p['attendance_rate']]])),
                    ])),
                for (final p in people)
                  Glass(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    onTap: () => push(c, EmployeeAttendance(id: p['employee_id'] as int, name: '${p['name']}')),
                    child: Row(children: [
                      Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text('P ${num1(p['present'])} · HD ${num1(p['half_days'])} · A ${num1(p['absent'])} · L ${num1(p['leave'])} · late ${p['late']}',
                            style: const TextStyle(fontSize: 12, color: evaMuted)),
                      ])),
                      if (p['attendance_rate'] != null)
                        Pill('${p['attendance_rate']}%', toD(p['attendance_rate']) >= 90 ? okGreen : (toD(p['attendance_rate']) >= 75 ? warnAmber : badRed)),
                    ]),
                  ),
              ]);
            },
          ),
        ),
      ]);
}

/* ===================================================== HISTORY LISTS */

class LeavesHistory extends StatefulWidget {
  const LeavesHistory({super.key});
  @override
  State<LeavesHistory> createState() => _LeavesHistoryState();
}

class _LeavesHistoryState extends State<LeavesHistory> {
  String status = 'all', q = '';
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Leave history',
        body: Loader(
          key: ValueKey(status),
          load: () => Api.i.get('admin/leaves', {'status': status}),
          builder: (c, d) {
            final l = (d['leaves'] as List).cast<Map>().where((x) => q.isEmpty || '${x['employee']}'.toLowerCase().contains(q)).toList();
            return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
              ListControls(
                searchHint: 'Employee name',
                onSearch: (v) => setState(() => q = v.toLowerCase()),
                filters: const ['all', 'pending', 'approved', 'rejected', 'cancelled'],
                selected: status,
                onFilter: (f) => setState(() => status = f),
                onExport: () => exportCsv(c, 'leaves_$status', ['Employee', 'Code', 'From', 'To', 'Days', 'Type', 'Pay', 'Status', 'Reason', 'Applied'],
                    [for (final x in l) [x['employee'], x['emp_code'], fd(x['from_date']), fd(x['to_date']), x['days'], x['leave_type'], x['pay_type'], x['status'], x['reason'], fdt(x['applied_at'])]]),
              ),
              if (l.isEmpty) const EmptyState('No leave records.'),
              for (final x in l)
                Glass(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(children: [
                    Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${x['employee']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text('${fd(x['from_date'])} → ${fd(x['to_date'])} · ${num1(x['days'])}d${x['pay_type'] != null && x['status'] == 'approved' ? ' · ${x['pay_type']}' : ''}',
                          style: const TextStyle(fontSize: 12, color: evaMuted)),
                      if ('${x['reason'] ?? ''}'.isNotEmpty) Text('${x['reason']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                    ])),
                    StatusPill('${x['status']}'),
                  ]),
                ),
            ]);
          },
        ),
      );
}

class AdvancesHistory extends StatefulWidget {
  const AdvancesHistory({super.key});
  @override
  State<AdvancesHistory> createState() => _AdvancesHistoryState();
}

class _AdvancesHistoryState extends State<AdvancesHistory> {
  String status = 'all', type = '';
  int bump = 0;
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Advances',
        body: Loader(
          key: ValueKey('$status$type$bump'),
          load: () => Api.i.get('admin/advances', {'status': status, 'type': type}),
          builder: (c, d) {
            final l = (d['advances'] as List).cast<Map>();
            final outstanding = l.where((x) => x['status'] == 'approved').fold<double>(0, (a, x) => a + toD(x['outstanding_balance']));
            return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
              Glass(child: Text('Outstanding to recover (shown rows): ${inr(outstanding)}', style: const TextStyle(fontWeight: FontWeight.w700))),
              ListControls(
                filters: const ['all', 'pending', 'approved', 'rejected', 'closed'],
                selected: status,
                onFilter: (f) => setState(() => status = f),
                sorts: const {'': 'All types', 'salary': 'Salary only', 'purchase': 'Purchase only'},
                sort: type,
                onSort: (v) => setState(() => type = v),
                onExport: () => exportCsv(c, 'advances', ['Employee', 'Code', 'Type', 'Requested', 'Approved', 'Monthly', 'Outstanding', 'Status', 'Disbursed', 'UTR'],
                    [for (final x in l) [x['employee'], x['emp_code'], x['type'], x['requested_amount'], x['approved_amount'], x['monthly_deduction'], x['outstanding_balance'], x['status'], fdt(x['disbursed_at']), x['utr_number']]]),
              ),
              if (l.isEmpty) const EmptyState('No advances.'),
              for (final x in l)
                Glass(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text('${x['employee']} · ${x['type']}', style: const TextStyle(fontWeight: FontWeight.w700))),
                      StatusPill('${x['status']}'),
                    ]),
                    Text('Asked ${inr(x['requested_amount'])}${x['approved_amount'] != null ? ' · approved ${inr(x['approved_amount'])}' : ''}${x['outstanding_balance'] != null && x['status'] == 'approved' ? ' · due ${inr(x['outstanding_balance'])}' : ''}',
                        style: const TextStyle(fontSize: 12, color: evaMuted)),
                    if (x['status'] == 'approved')
                      Wrap(spacing: 8, children: [
                        if (x['disbursed_at'] == null)
                          TextButton(
                              onPressed: () async {
                                final utr = await askText(c, 'Mark as paid to employee', hint: 'UTR / reference number', ok: 'Mark disbursed');
                                if (utr == null) return;
                                try {
                                  await Api.i.post('admin/advances/decide', {'advance_id': x['id'], 'action': 'disburse', 'utr_number': utr});
                                  setState(() => bump++);
                                  if (c.mounted) toast(c, 'Marked as disbursed');
                                } on ApiError catch (e) {
                                  if (c.mounted) toast(c, e.message, err: true);
                                }
                              },
                              child: const Text('Mark disbursed')),
                        if (x['type'] == 'purchase')
                          TextButton(
                              onPressed: () async {
                                final r = await askText(c, 'Verify purchase bill', hint: 'Amount to refund to company (₹, 0 if none)', initial: '0', ok: 'Verify & close');
                                if (r == null) return;
                                try {
                                  await Api.i.post('admin/advances/decide', {'advance_id': x['id'], 'action': 'verify_purchase', 'refund_amount': double.tryParse(r) ?? 0});
                                  setState(() => bump++);
                                  if (c.mounted) toast(c, 'Purchase verified');
                                } on ApiError catch (e) {
                                  if (c.mounted) toast(c, e.message, err: true);
                                }
                              },
                              child: const Text('Verify bill')),
                      ]),
                  ]),
                ),
            ]);
          },
        ),
      );
}

class ExpensesHistory extends StatefulWidget {
  const ExpensesHistory({super.key});
  @override
  State<ExpensesHistory> createState() => _ExpensesHistoryState();
}

class _ExpensesHistoryState extends State<ExpensesHistory> {
  String status = 'all';
  int bump = 0;
  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Expense claims',
        body: Loader(
          key: ValueKey('$status$bump'),
          load: () => Api.i.get('admin/expenses', {'status': status}),
          builder: (c, d) {
            final l = (d['expenses'] as List).cast<Map>();
            return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
              ListControls(
                filters: const ['all', 'pending', 'approved', 'paid', 'rejected'],
                selected: status,
                onFilter: (f) => setState(() => status = f),
                onExport: () => exportCsv(c, 'expenses', ['Employee', 'Code', 'Amount', 'Reason', 'Status', 'Submitted', 'Paid', 'Mode'],
                    [for (final x in l) [x['employee'], x['emp_code'], x['amount'], x['reason'], x['status'], fdt(x['submitted_at']), fdt(x['paid_at']), x['payment_mode']]]),
              ),
              if (l.isEmpty) const EmptyState('No expense claims.'),
              for (final x in l)
                Glass(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text('${x['employee']} · ${inr(x['amount'], decimals: true)}', style: const TextStyle(fontWeight: FontWeight.w700))),
                      StatusPill('${x['status']}'),
                    ]),
                    Text('${x['reason']}', style: const TextStyle(color: evaMuted)),
                    if (x['status'] == 'approved')
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                            onPressed: () async {
                              final mode = await askText(c, 'Mark as paid', hint: 'Payment mode (Cash / UPI / Bank)', initial: 'UPI', ok: 'Mark paid');
                              if (mode == null) return;
                              try {
                                await Api.i.post('admin/expenses/decide', {'expense_id': x['id'], 'action': 'mark_paid', 'payment_mode': mode});
                                setState(() => bump++);
                              } on ApiError catch (e) {
                                if (c.mounted) toast(c, e.message, err: true);
                              }
                            },
                            child: const Text('Mark paid')),
                      ),
                  ]),
                ),
            ]);
          },
        ),
      );
}

/* ========================================================== GRIEVANCES */

class AdminGrievances extends StatefulWidget {
  const AdminGrievances({super.key});
  @override
  State<AdminGrievances> createState() => _AdminGrievancesState();
}

class _AdminGrievancesState extends State<AdminGrievances> {
  String status = 'all';
  String q = '';
  int bump = 0;

  Future<void> reply(Map g) async {
    final remarks = TextEditingController(text: '${g['hr_reply'] ?? ''}');
    String st = g['status'] == 'pending' ? 'in_review' : '${g['status']}';
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => StatefulBuilder(
            builder: (_, set) => AlertDialog(
                  title: Text('${g['subject']}'),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${g['employee']} · ${g['category']}'),
                    const SizedBox(height: 6),
                    Text('${g['description']}'),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                        value: st,
                        decoration: const InputDecoration(labelText: 'Status'),
                        items: [for (final s in ['pending', 'in_review', 'resolved', 'rejected']) DropdownMenuItem(value: s, child: Text(statusLabel(s)))],
                        onChanged: (v) => set(() => st = v!)),
                    const SizedBox(height: 8),
                    TextField(controller: remarks, maxLines: 3, decoration: const InputDecoration(labelText: 'Reply to employee')),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save & notify')),
                  ],
                )));
    if (ok != true) return;
    try {
      await Api.i.post('admin/grievances/update', {'grievance_id': g['id'], 'status': st, 'remarks': remarks.text});
      setState(() => bump++);
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    }
  }

  @override
  Widget build(BuildContext context) => GlassPage(
        title: 'Grievances',
        body: Loader(
          key: ValueKey('$status$bump'),
          load: () => Api.i.get('admin/grievances', {'status': status, 'q': q}),
          builder: (c, d) {
            final l = (d['grievances'] as List).cast<Map>();
            return ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 24), children: [
              ListControls(
                searchHint: 'Search subject or name',
                onSearch: (v) => setState(() => q = v),
                filters: const ['all', 'pending', 'in_review', 'resolved', 'rejected'],
                selected: status,
                onFilter: (f) => setState(() => status = f),
                onExport: () => exportCsv(c, 'grievances', ['Employee', 'Category', 'Subject', 'Priority', 'Status', 'Submitted', 'HR reply'],
                    [for (final g in l) [g['employee'], g['category'], g['subject'], g['priority'], g['status'], fdt(g['submitted_at']), g['hr_reply']]]),
              ),
              if (l.isEmpty) const EmptyState('Nothing here.'),
              for (final g in l) GrievanceCard(g: g, showEmployee: true, onTap: () => reply(g)),
            ]);
          },
        ),
      );
}
