import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';
import 'shell.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final u = TextEditingController(), p = TextEditingController();
  bool busy = false, hide = true;

  Future<void> go() async {
    if (u.text.trim().isEmpty || p.text.isEmpty) return toast(context, 'Enter username and password', err: true);
    setState(() => busy = true);
    try {
      await Api.i.login(u.text.trim(), p.text);
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const Shell()), (_) => false);
    } on ApiError catch (e) {
      if (mounted) toast(context, e.message, err: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> server() async {
    final c = TextEditingController(text: Api.i.base);
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('Server address'),
              content: TextField(controller: c, keyboardType: TextInputType.url),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save')),
              ],
            ));
    if (ok == true) await Api.i.setBase(c.text);
  }

  @override
  Widget build(BuildContext context) => GlassBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                Image.asset('assets/logo.png', width: 132, height: 132),
                const SizedBox(height: 12),
                const Text('VleBazaar EMS', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: evaDeep)),
                const SizedBox(height: 4),
                const Text('Sign in to continue'),
                const SizedBox(height: 28),
                TextField(controller: u, decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.person_outline)),
                    autocorrect: false, textInputAction: TextInputAction.next),
                const SizedBox(height: 12),
                TextField(
                  controller: p, obscureText: hide, onSubmitted: (_) => go(),
                  decoration: InputDecoration(
                      labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => hide = !hide))),
                ),
                const SizedBox(height: 20),
                FilledButton(onPressed: busy ? null : go,
                    child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Sign in')),
                TextButton(onPressed: server, child: const Text('Server settings')),
              ]),
            ),
          ),
        ),
      ));
}
