import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class ApiError implements Exception {
  final String message;
  final int status;
  final String? code;
  final Map<String, dynamic>? data;
  ApiError(this.message, this.status, {this.code, this.data});
  @override
  String toString() => message;
}

/// Talks to https://<host>/ems/api/index.php/<endpoint> (see API.md).
class Api {
  static const defaultBase = 'https://texvns.com/ems/api/index.php';
  static final Api i = Api._();
  Api._();
  final _store = const FlutterSecureStorage();
  String base = defaultBase;
  String? token;
  Map<String, dynamic>? user;
  void Function()? onUnauthorized;

  bool get isAdmin => user != null && (user!['role'] == 'admin' || user!['role'] == 'superadmin');

  Future<void> load() async {
    base = await _store.read(key: 'base') ?? defaultBase;
    token = await _store.read(key: 'token');
    final u = await _store.read(key: 'user');
    if (u != null) user = jsonDecode(u);
  }

  Future<void> setBase(String b) async {
    base = b.trim().replaceAll(RegExp(r'/+$'), '');
    await _store.write(key: 'base', value: base);
  }

  Future<Map<String, dynamic>> _go(String method, String path,
      {Map<String, String>? q, Map<String, dynamic>? body}) async {
    var uri = Uri.parse('$base/$path');
    if (q != null && q.isNotEmpty) uri = uri.replace(queryParameters: q);
    final h = {'Content-Type': 'application/json', 'Accept': 'application/json'};
    if (token != null) h['Authorization'] = 'Bearer $token';
    http.Response r;
    try {
      r = method == 'GET'
          ? await http.get(uri, headers: h).timeout(const Duration(seconds: 30))
          : await http.post(uri, headers: h, body: jsonEncode(body ?? {})).timeout(const Duration(seconds: 60));
    } catch (e) {
      throw ApiError('No connection. Check your internet and try again.', 0);
    }
    Map<String, dynamic> j;
    try {
      j = jsonDecode(r.body) as Map<String, dynamic>;
    } catch (_) {
      throw ApiError('Unexpected server response (${r.statusCode}).', r.statusCode);
    }
    if (r.statusCode == 401 && path != 'auth/login') {
      await clearSession();
      onUnauthorized?.call();
    }
    if (j['ok'] != true) {
      throw ApiError((j['error'] ?? 'Something went wrong').toString(), r.statusCode,
          code: j['code']?.toString(), data: j);
    }
    return j;
  }

  Future<Map<String, dynamic>> get(String p, [Map<String, String>? q]) => _go('GET', p, q: q);
  Future<Map<String, dynamic>> post(String p, [Map<String, dynamic>? b]) => _go('POST', p, body: b);

  /// Raw file download (documents). Throws ApiError with the server's message on failure.
  Future<List<int>> getBytes(String p, [Map<String, String>? q]) async {
    var uri = Uri.parse('$base/$p');
    if (q != null && q.isNotEmpty) uri = uri.replace(queryParameters: q);
    final h = <String, String>{};
    if (token != null) h['Authorization'] = 'Bearer $token';
    http.Response r;
    try {
      r = await http.get(uri, headers: h).timeout(const Duration(seconds: 90));
    } catch (e) {
      throw ApiError('No connection. Check your internet and try again.', 0);
    }
    final ct = r.headers['content-type'] ?? '';
    if (r.statusCode != 200 || ct.contains('application/json')) {
      String msg = 'Download failed (${r.statusCode}).';
      try {
        msg = (jsonDecode(r.body)['error'] ?? msg).toString();
      } catch (_) {}
      if (r.statusCode == 401) {
        await clearSession();
        onUnauthorized?.call();
      }
      throw ApiError(msg, r.statusCode);
    }
    return r.bodyBytes;
  }

  String get firstName => ((user?['full_name'] ?? '') as String).split(' ').first;

  Future<void> login(String username, String password) async {
    final j = await _go('POST', 'auth/login',
        body: {'username': username, 'password': password, 'device_name': 'Android app'});
    token = j['token'];
    user = Map<String, dynamic>.from(j['user']);
    await _store.write(key: 'token', value: token);
    await _store.write(key: 'user', value: jsonEncode(user));
  }

  Future<void> clearSession() async {
    token = null;
    user = null;
    await _store.delete(key: 'token');
    await _store.delete(key: 'user');
  }

  Future<void> logout() async {
    try {
      await _go('POST', 'auth/logout');
    } catch (_) {}
    await clearSession();
  }
}
