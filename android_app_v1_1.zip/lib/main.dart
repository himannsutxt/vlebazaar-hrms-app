import 'package:flutter/material.dart';
import 'api.dart';
import 'screens/login.dart';
import 'screens/shell.dart';
import 'theme.dart';

final navKey = GlobalKey<NavigatorState>();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Api.i.onUnauthorized = () => navKey.currentState?.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  runApp(const HrmsApp());
}

class HrmsApp extends StatelessWidget {
  const HrmsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'VleBazaar EMS',
        navigatorKey: navKey,
        debugShowCheckedModeBanner: false,
        theme: evaTheme(),
        home: const SplashScreen(),
      );
}

/// Branded loading screen: shown while the saved session is read,
/// for at least [minShow] so it never just flashes.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  static const splashBg = Color(0xFFDCE6FE);
  static const minShow = Duration(milliseconds: 1800);
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    await Future.wait([
      Api.i.load().catchError((_) {}),
      Future.delayed(SplashScreen.minShow),
    ]);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (_, __, ___) => Api.i.token == null ? const LoginScreen() : const Shell(),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
    ));
  }

  @override
  Widget build(BuildContext context) => const Scaffold(
        backgroundColor: SplashScreen.splashBg,
        body: SizedBox.expand(
          child: Image(
            image: AssetImage('assets/splash.jpg'),
            fit: BoxFit.fitWidth,
            alignment: Alignment.bottomCenter,
            semanticLabel: 'VleBazaar EMS — Employee Management System. Loading',
          ),
        ),
      );
}
