import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vlebazaar_hrms/api.dart';
import 'package:vlebazaar_hrms/theme.dart';

void main() {
  test('fd formats like the website (d-M-Y)', () {
    expect(fd('2026-11-15'), '15-Nov-2026');
    expect(fd(null), '–');
    expect(fd('x'), 'x');
  });

  test('fdt shows 12-hour time', () {
    expect(fdt('2026-11-15 14:05:00'), '15-Nov-2026 02:05 PM');
    expect(fdt('2026-11-15 00:30:00'), '15-Nov-2026 12:30 AM');
  });

  test('inr uses Indian digit grouping', () {
    expect(inr(1234567), '₹12,34,567');
    expect(inr(1234567.5), '₹12,34,567.50');
    expect(inr(999), '₹999');
    expect(inr(100000), '₹1,00,000');
    expect(inr(-2500), '-₹2,500');
    expect(inr(null), '–');
    expect(inr(12, decimals: true), '₹12.00');
  });

  test('num1 hides .0', () {
    expect(num1(3), '3');
    expect(num1(2.5), '2.5');
    expect(num1('4'), '4');
  });

  test('status labels and colours', () {
    expect(statusLabel('HD'), 'Half day');
    expect(statusLabel('in_review'), 'In review');
    expect(statusLabel('something_new'), 'Something new');
    expect(statusColor('P'), isNot(statusColor('A')));
  });

  test('ApiError carries message', () {
    expect(ApiError('boom', 500).toString(), 'boom');
  });

  testWidgets('KVRow shows a dash for empty values', (t) async {
    await t.pumpWidget(const MaterialApp(home: Scaffold(body: Column(children: [KVRow('Phone', ''), KVRow('Email', 'a@b.com')]))));
    expect(find.text('–'), findsOneWidget);
    expect(find.text('a@b.com'), findsOneWidget);
  });

  testWidgets('MiniBars renders one bar per value', (t) async {
    await t.pumpWidget(const MaterialApp(
        home: Scaffold(body: MiniBars(values: [1, 5, 0], labels: ['a', 'b', 'c']))));
    expect(find.text('a'), findsOneWidget);
    expect(find.text('c'), findsOneWidget);
  });

  testWidgets('EmptyState and StatusPill render', (t) async {
    await t.pumpWidget(const MaterialApp(home: Scaffold(body: Column(children: [EmptyState('Nothing'), StatusPill('approved')]))));
    expect(find.text('Nothing'), findsOneWidget);
    expect(find.text('Approved'), findsOneWidget);
  });
}
