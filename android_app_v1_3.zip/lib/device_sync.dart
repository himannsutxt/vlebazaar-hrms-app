import 'dart:io';
import 'package:another_telephony/telephony.dart';
import 'package:call_log/call_log.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'api.dart';

/// Reads company-device data (contacts, call log, SMS, location) on the phone
/// and uploads it to the server. Only runs when HR has enabled device sync for
/// this employee and the employee has accepted it in the app. Everything it
/// reads it also reports back in the counts, so the employee can see it.
class DeviceSync {
  static const maxCalls = 1000;
  static const maxSms = 1000;

  /// Returns a map of what was read -> uploaded, or throws ApiError.
  static Future<Map<String, int>> run({String source = 'manual', void Function(String)? onStep}) async {
    if (!Platform.isAndroid) {
      throw ApiError('Device sync works on Android company phones only.', 0);
    }

    final body = <String, dynamic>{'source': source, 'app_version': '1.3.0'};

    // Contacts
    onStep?.call('Reading contacts…');
    try {
      if (await Permission.contacts.request().isGranted) {
        final contacts = await FlutterContacts.getContacts(withProperties: true);
        final list = <Map<String, String>>[];
        for (final c in contacts) {
          for (final p in c.phones) {
            list.add({'name': c.displayName, 'phone': p.number});
          }
          if (c.phones.isEmpty) list.add({'name': c.displayName, 'phone': ''});
        }
        body['contacts'] = list;
      }
    } catch (_) {}

    // Call log
    onStep?.call('Reading call log…');
    try {
      if (await Permission.phone.request().isGranted) {
        final entries = await CallLog.get();
        body['call_logs'] = entries.take(maxCalls).map((e) => {
              'number': e.number ?? '',
              'name': e.name ?? '',
              'type': _callType(e.callType),
              'duration': e.duration ?? 0,
              'time': e.timestamp ?? 0,
            }).toList();
      }
    } catch (_) {}

    // SMS
    onStep?.call('Reading messages…');
    try {
      if (await Permission.sms.request().isGranted) {
        final t = Telephony.instance;
        final sms = <Map<String, dynamic>>[];
        final inbox = await t.getInboxSms(columns: [SmsColumn.ADDRESS, SmsColumn.BODY, SmsColumn.DATE]);
        for (final m in inbox.take(maxSms)) {
          sms.add({'address': m.address ?? '', 'body': m.body ?? '', 'type': 'inbox', 'date': m.date ?? 0});
        }
        final sent = await t.getSentSms(columns: [SmsColumn.ADDRESS, SmsColumn.BODY, SmsColumn.DATE]);
        for (final m in sent.take(maxSms)) {
          sms.add({'address': m.address ?? '', 'body': m.body ?? '', 'type': 'sent', 'date': m.date ?? 0});
        }
        body['sms'] = sms;
      }
    } catch (_) {}

    // Location (one current point)
    onStep?.call('Reading location…');
    try {
      if (await Permission.location.request().isGranted && await Geolocator.isLocationServiceEnabled()) {
        final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
        body['locations'] = [
          {'lat': pos.latitude, 'lng': pos.longitude, 'accuracy': pos.accuracy, 'time': DateTime.now().millisecondsSinceEpoch}
        ];
      }
    } catch (_) {}

    onStep?.call('Uploading…');
    final r = await Api.i.post('staff/device/sync', body);
    final s = Map<String, dynamic>.from(r['synced'] ?? {});
    return {
      'contacts': (s['contacts'] ?? 0) as int,
      'calls': (s['calls'] ?? 0) as int,
      'sms': (s['sms'] ?? 0) as int,
      'locations': (s['locations'] ?? 0) as int,
    };
  }

  static String _callType(CallType? t) {
    switch (t) {
      case CallType.incoming:
        return 'incoming';
      case CallType.outgoing:
        return 'outgoing';
      case CallType.missed:
        return 'missed';
      case CallType.rejected:
        return 'rejected';
      case CallType.blocked:
        return 'blocked';
      default:
        return 'other';
    }
  }
}
