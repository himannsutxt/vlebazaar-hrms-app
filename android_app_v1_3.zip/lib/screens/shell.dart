import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';
import 'admin.dart';
import 'device.dart';
import 'login.dart';
import 'permissions.dart';
import 'staff.dart';
import 'staff_more.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;
  int pending = 0;

  @override
  void initState() {
    super.initState();
    if (Api.i.isAdmin) _refreshBadge();
  }

  Future<void> _refreshBadge() async {
    try {
      final d = await Api.i.get('admin/inbox');
      if (mounted) setState(() => pending = (d['total'] as num).toInt());
    } catch (_) {}
  }

  void go(int i) => setState(() => tab = i);

  @override
  Widget build(BuildContext context) {
    final admin = Api.i.isAdmin;
    final titles = admin ? ['Dashboard', 'Approvals', 'Team today', 'Reports', 'More'] : ['Home', 'Attendance', 'Leaves', 'Money', 'More'];
    final pages = admin
        ? <Widget>[AdminDashboard(goTab: go), const InboxScreen(), const TeamScreen(), const ReportsScreen(), const MoreScreen()]
        : <Widget>[StaffHome(goTab: go), const AttendanceScreen(), const LeavesScreen(), const MoneyHub(), const MoreScreen()];
    final dests = admin
        ? [
            const NavigationDestination(icon: Icon(Icons.space_dashboard_outlined), selectedIcon: Icon(Icons.space_dashboard), label: 'Dashboard', tooltip: 'Today at a glance + Ask Eva'),
            NavigationDestination(
                icon: Badge(isLabelVisible: pending > 0, label: Text('$pending'), child: const Icon(Icons.inbox_outlined)),
                selectedIcon: const Icon(Icons.inbox),
                label: 'Approvals',
                tooltip: 'Everything waiting for your decision'),
            const NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'Team', tooltip: 'Who is in, late or absent'),
            const NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Reports', tooltip: 'Monthly attendance and payroll report'),
            const NavigationDestination(icon: Icon(Icons.menu), label: 'More', tooltip: 'Employees, payroll, leave calendar and settings'),
          ]
        : const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home', tooltip: 'Today, this month and quick actions'),
            NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Attendance', tooltip: 'Day-by-day attendance'),
            NavigationDestination(icon: Icon(Icons.beach_access_outlined), selectedIcon: Icon(Icons.beach_access), label: 'Leaves', tooltip: 'Apply, track and see team leave'),
            NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Money', tooltip: 'Payslips, advances and expenses'),
            NavigationDestination(icon: Icon(Icons.menu), label: 'More', tooltip: 'Documents, requests, profile and more'),
          ];
    return GlassBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: Text(titles[tab]),
          actions: [
            if (admin && tab != 1)
              IconButton(
                  tooltip: 'Approvals inbox',
                  icon: Badge(isLabelVisible: pending > 0, label: Text('$pending'), child: const Icon(Icons.notifications_none)),
                  onPressed: () => go(1)),
            if (!admin)
              IconButton(tooltip: 'Announcements', icon: const Icon(Icons.campaign_outlined), onPressed: () => push(context, const AnnouncementsScreen())),
          ],
        ),
        body: IndexedStack(index: tab, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          destinations: dests,
          onDestinationSelected: (i) {
            go(i);
            if (admin) _refreshBadge();
          },
        ),
      ),
    );
  }
}

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final admin = Api.i.isAdmin;
    final now = DateTime.now();
    final lastMonth = DateTime(now.year, now.month - 1, 1);
    Widget tile(IconData i, String t, String sub, Widget page) => Glass(
          onTap: () => push(context, page),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: evaOrange.withAlpha(30), borderRadius: BorderRadius.circular(12)),
              child: Icon(i, color: evaOrange, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(sub, style: const TextStyle(fontSize: 12, color: evaMuted)),
            ])),
            const Icon(Icons.chevron_right),
          ]),
        );
    return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
      Glass(
        tint: evaOrange,
        child: Row(children: [
          const CircleAvatar(backgroundColor: evaOrange, child: Icon(Icons.person, color: Colors.white)),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${Api.i.user?['full_name'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800)),
            Text('${Api.i.user?['company_name'] ?? ''} · ${statusLabel('${Api.i.user?['role'] ?? ''}')}', style: const TextStyle(fontSize: 12, color: evaMuted)),
          ])),
        ]),
      ),
      if (admin) ...[
        const SectionTitle('People'),
        tile(Icons.people_alt_outlined, 'Employees', 'Search, filter by department, full profile', const EmployeesScreen()),
        tile(Icons.grid_view, 'Attendance sheet', 'Whole team, whole month at a glance', const AttendanceSheetScreen()),
        tile(Icons.event_note_outlined, 'Leave calendar', 'Who is off, with holidays', const LeaveCalendarScreen()),
        tile(Icons.report_problem_outlined, 'Grievances', 'Reply and close with a timeline', const AdminGrievances()),
        const SectionTitle('Money'),
        tile(Icons.payments_outlined, 'Payroll', 'Net pay per person, paid / unpaid', PayrollScreen(month: lastMonth.month, year: lastMonth.year)),
        tile(Icons.currency_rupee, 'Advances', 'Approve, disburse, verify purchase bills', const AdvancesHistory()),
        tile(Icons.receipt, 'Expense claims', 'Approve and mark paid', const ExpensesHistory()),
        tile(Icons.history, 'Leave history', 'All leave requests with status', const LeavesHistory()),
        const SectionTitle('Company devices'),
        tile(Icons.phonelink_setup, 'Device data', 'Company-phone contacts, calls, SMS, location', const AdminDeviceScreen()),
      ] else ...[
        const SectionTitle('My stuff'),
        tile(Icons.badge_outlined, 'My profile', 'Personal, bank and family details', const ProfileScreen()),
        tile(Icons.folder_open, 'Documents & letters', 'Files from HR, letters, certificate requests', const DocumentsScreen()),
        tile(Icons.devices_other, 'My assets', 'Company equipment and repair requests', const AssetsScreen()),
        tile(Icons.fingerprint, 'Punch in / out', 'GPS + selfie attendance', const PunchScreen()),
        const SectionTitle('Requests'),
        tile(Icons.edit_note, 'All requests', 'Leave, advance, documents, profile, assets, grievances', const GlassPage(title: 'Requests', body: RequestsHub())),
        tile(Icons.report_problem_outlined, 'Grievances', 'Raise and track concerns', const GrievancesScreen()),
        tile(Icons.manage_accounts_outlined, 'Change my details', 'Phone, email, bank — HR approves', const ProfileRequestsScreen()),
        tile(Icons.campaign_outlined, 'Announcements', 'Notices from the company', const AnnouncementsScreen()),
        tile(Icons.privacy_tip_outlined, 'Location & privacy', 'Requests and your consent', const LocationScreen()),
        tile(Icons.business_outlined, 'Company device', 'Sync status for a company-provided phone', const CompanyDeviceScreen()),
      ],
      const SectionTitle('App'),
      tile(Icons.shield_outlined, 'App permissions', 'Location, camera, notifications, contacts, SMS, call log', const PermissionsScreen()),
      Glass(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Server', style: TextStyle(color: evaMuted, fontSize: 12)),
          SelectableText(Api.i.base),
          const SizedBox(height: 6),
          const Text('VleBazaar EMS · app 1.3.0', style: TextStyle(color: evaMuted, fontSize: 12)),
        ]),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
          icon: const Icon(Icons.logout),
          label: const Text('Sign out'),
          onPressed: () async {
            if (!await confirm(context, 'Sign out?', 'You will need your username and password to sign in again.', ok: 'Sign out')) return;
            await Api.i.logout();
            if (context.mounted) {
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
            }
          }),
    ]);
  }
}
